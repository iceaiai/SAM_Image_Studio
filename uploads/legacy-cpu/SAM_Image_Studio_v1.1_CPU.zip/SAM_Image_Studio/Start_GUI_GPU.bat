@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv-gpu\Scripts\python.exe" (
    echo Follow the optional CUDA installation in INSTALL_UNINSTALL.md first.
    pause
    exit /b 1
)
".venv-gpu\Scripts\python.exe" -m samstudio %*
if errorlevel 1 pause
