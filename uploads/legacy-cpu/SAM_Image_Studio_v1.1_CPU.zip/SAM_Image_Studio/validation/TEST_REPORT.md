# SAM Image Studio 1.1.0 validation report

Complete recorded run: **159 passed, 0 failures, 0 errors, 0 skipped**.

The run includes genuine SAM1 ViT-B, SAM2.1 Tiny and LaMa CPU weights, real Qt
widgets and native paint/resize events, microscopy reader fixtures, and exact
COCO decoding with the official API. Four fresh GUI subprocesses passed genuine
model loading, preexisting prompts followed by new clicks, accepted-object
recovery and histogram painting. Windows, CUDA and SAM3 were not executed.

## Reported regressions

| Issue | Reproduction or coverage | Result |
| --- | --- | --- |
| Whole-image prompt selects all objects | Original v1.0 made 64 native predictions for one point. The corrected scopes retain points/boxes and predict one object. | Passed |
| Dot treated as an enclosed region | Positive/negative points work in both prompted scopes. Point-only input never uses a one-pixel clipping mask. | Passed |
| New dots after model loading stop the program | Real SAM1/SAM2.1 Qt tests, queued live clicks and four independent cold GUI processes. CPU native pools initialize before model workers. | Passed |
| Histogram crashes with QComboBox not callable | Reproduced the exact old QWidget.metric collision. Corrected dialog paints, resizes, filters, exports and closes. | Passed |
| Vertex deletion is slow or affects wrong objects | Cached source display and mask encoding, exact repeated-radius checks and neighbor identity/mask comparisons. | Passed |
| Smooth Edges is still jagged | Periodic cubic curves retain continuous tangents, reduce synthetic boundary noise, persist and support batch undo. | Passed |
| Moving a vertex generates points | Original move changed four handles to 22. Corrected moves retain the same controls and persist through reopen and undo/redo. | Passed |
| Missing Python or wrong version | English Start-search/PowerShell instructions, correct WinGet user-scope command, and a helper batch file supplied. Native Windows execution remains unverified. | Instructions updated |

## Functional coverage

- Manual shapes, prompt signs, groups, lock/visibility and undo/redo.
- Existing-object protection, native point/box masks, ROI clipping, explicit grid,
  canceled/failed operations and failed-model rollback.
- Native project codec, atomic writes, backup recovery, corrupt-state rejection,
  source/frame identity and saved curve geometry.
- OME/ImageJ TIFF, compressed TIFF, actual DM3/DM4 and EMD fixtures, anisotropic
  calibration, units, physical area and calibration-free pixel measurements.
- Fill Holes, true curve smoothing, batch refinements and exact undo.
- Neighbor/patch/LaMa cleaning, explicit preview/application, source preservation.
- BMP24, PNG/TIFF, RGBA transparency, integer ID mappings, exact COCO and reviewed
  YOLO conversion, live histograms, object CSV and plot export.

## Observed editing performance

A 1536 by 1536 image with 16 masks and six completed vertex edits had a median
elapsed time of 203 ms in v1.0 and 162 ms in v1.1, including autosave. The new
version retained four handles across all six edits. These are local observations,
not Windows performance guarantees. See benchmark_v10.json and benchmark_v11.json.

## Model evidence

Official checkpoint SHA256 values are retained in real_models.json. No dummy
checkpoints substitute for real model compatibility tests. The four cold-process
records report 1998 combined Qt heartbeat
ticks while loading, inferring and painting. Separate GUI contract tests use
clearly identified test doubles to exercise routing and queued inputs.

The installed 1.1.0 wheel also passed an independent SAM2.1 real-weight self-test
from outside the source directory. The final ZIP is unpacked and checked before
handoff. Details are in installed_package_model.json and release_verification.json.

## Reproduction

From a Python 3.12 environment installed with the release:

```text
python -m pip install -r requirements-dev.txt
python scripts/fetch_validation_assets.py --models
python scripts/run_full_validation.py
```

A smaller fresh-process check is available through scripts/cold_start_smoke.py
with --family SAM1 or SAM2.1 and --checkpoint pointing to genuine local weights.

## Boundaries

Verified environment: Linux x86-64, Python 3.12, PySide6 6.8.3 and CPU PyTorch
2.7.1. No native Windows/EXE, macOS, NVIDIA CUDA, SAM3 or larger-model acceptance
is claimed. The Windows portable build recipe is included; no prebuilt EXE is
included. The suite validates the listed scenarios and does not prove the absence
of every possible defect. One upstream pycocotools/NumPy deprecation warning was
emitted; all assertions passed.
