# SAM Image Studio 1.1.0

This release fixes the reported inference, plotting and vertex-editing behavior
and incorporates the accepted design recommendations into the formal manual.

| Reported issue | Released behavior |
| --- | --- |
| Python is missing or is another version | English Start-search and PowerShell instructions, exact WinGet command and optional Install_Python_3_12.bat helper. Existing Python versions can remain installed. |
| Whole-image scope segments all objects after a shape prompt | Prompted object, whole image uses normal native SAM prediction with the supplied shape or points. Automatic grid is a separate explicit option. |
| Point prompts interpreted as enclosed areas | A point alone always uses normal prompted inference. It never defines a one-pixel ROI. |
| Adding points after model loading stops the program | Native PyTorch CPU pools initialize once before Qt model workers. New clicks during prompted inference are queued and stale previews are discarded. Four fresh real-model GUI processes passed this workflow. |
| Histogram error and program closure | Statistics controls no longer shadow QWidget.metric. Native painting, resizing, filter changes and close events are covered by Qt and fresh-process checks. |
| Slow vertex deletion and deletion radius | Original display pixels and unchanged mask encodings are reused. Repeated Delete removes nearest remaining vertices within the configured radius, in the selected object only. Default radius: 20 image pixels. |
| Smooth Edges leaves zigzag outlines | Smoothing retains editable periodic cubic curves with antialiased display. Preview and batch undo remain available. Raster masks determine measured and exported area. |
| Moving a vertex adds points | Editable contours persist rather than being regenerated from the pixel staircase after every edit. Moves keep the vertex count fixed. |

The complete validation run passed **159 tests, 0 failures, 0 skips**. Real SAM1
ViT-B, SAM2.1 Tiny and LaMa CPU weights were exercised. Native Windows desktop,
prebuilt Windows EXE, CUDA, SAM3 and larger variants remain outside this Linux CPU
validation. No prebuilt EXE is included.

The updated Word file is the combined functional specification and user manual.
The 17-slide PPT retains editable control IDs and adds the corrected prompt modes,
vertex-radius behavior and English PowerShell installation steps.

Install this version in a new folder. Reuse original images and their existing
SAM_Annotations projects. Cached model files remain available. Before editing,
keep a backup if you need to reopen the projects with version 1.0, which does not
understand the new persistent contour field.
