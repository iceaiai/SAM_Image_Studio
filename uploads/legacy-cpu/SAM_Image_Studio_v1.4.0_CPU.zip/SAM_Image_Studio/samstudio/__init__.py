"""SAM Image Studio: microscopy annotation and image segmentation."""
__version__ = "1.5.0"

