"""COCO review metadata, non-destructive annotation import and calibration tables."""
from __future__ import annotations
import copy
import json
import math
import re
from pathlib import Path
import numpy as np
from .domain import Calibration, atomic_write

ARTIFACT_LOCATIONS = (
    'outside_edge', 'outer_attached_edge', 'inner_attached_edge',
    'both_sides_attached_edge', 'both_sides_closely_attached_edge', 'inner', 'across_boundary',
)
EDGE_LOCATIONS = set(ARTIFACT_LOCATIONS) - {'outside_edge', 'inner'}
DEFAULT_ARTIFACT = {'pattern': None, 'edge_scope': None, 'severity': None, 'notes': None}
DEFAULT_ATTRIBUTES = {
    'shape': 'square', 'structure': 'solid', 'mask_mode': 'visible', 'overlap_level': 0,
    'overlap_subtype': None, 'fusion': 0,
    'artifacts': {name: [copy.deepcopy(DEFAULT_ARTIFACT)] for name in ARTIFACT_LOCATIONS},
    'touches_image_border': False, 'truncated': False, 'review_status': 'accepted',
    'exclude_from_training': False, 'notes': None,
}
FIELD_HELP = {
    'id': ('Positive annotation number; 0 is reserved for background.', 'IDs 2, 7, 12 remain unchanged unless Normalize number of object is selected.'),
    'image_id': ('Links an annotation to an images entry.', 'image_id 1 refers to images[0] when that entry has id 1.'),
    'category_id': ('Links an annotation to an object group/category.', 'category_id 2 can represent Core in categories.'),
    'segmentation': ('Exact object geometry, encoded as polygons or COCO run-length encoding.', 'A mask with a hole uses RLE so the hole is preserved.'),
    'bbox': ('Axis-aligned box [left, top, width, height], in image pixels.', '[10, 20, 30, 40] starts at x=10, y=20.'),
    'area': ('Number of foreground mask pixels; physical area is recorded separately.', '100 pixels at 0.2 nm/pixel gives 4 nm^2.'),
    'iscrowd': ('COCO crowd annotation flag.', '0 is an ordinary object; 1 indicates a crowd region.'),
    'shape': ('User-assigned morphology, independent of the drawing tool.', 'square, circle, rod, polygon or irregular.'),
    'structure': ('Visible internal structure.', 'solid, core_shell or hollow.'),
    'mask_mode': ('Interpretation of the annotation footprint.', 'visible uses only the visible outline; amodal can describe an inferred full object.'),
    'overlap_level': ('User-assigned overlap degree; 0 means no overlap.', 'Use 1 for a confirmed overlap under your project convention.'),
    'overlap_subtype': ('Optional description of the overlap.', 'partial_overlap; leave null when no overlap is established.'),
    'fusion': ('User-assigned fusion indicator or level; 0 means absent.', 'Set 1 only when the image supports your fusion criterion.'),
    'touches_image_border': ('Whether the object reaches an image boundary.', 'true for an object touching the left image edge.'),
    'truncated': ('Whether part of an object is cut off.', 'true when the complete particle extends beyond the acquired field.'),
    'review_status': ('Human review state.', 'accepted, needs_review, uncertain or rejected.'),
    'exclude_from_training': ('Whether training-data preparation should omit this annotation.', 'true for an uncertain particle that should remain available for review.'),
    'outside_edge': ('Artifact outside the object edge; edge_scope is disabled.', 'A background contamination spot next to a particle; no attachment classification.'),
    'outer_attached_edge': ('Artifact attached to the outer side of an object edge.', 'A dark rim outside part of the boundary; partial_edge.'),
    'inner_attached_edge': ('Artifact attached to the inner side of an object edge.', 'An interior rim following part of the boundary; partial_edge.'),
    'both_sides_attached_edge': ('Artifact attached on both sides of a boundary.', 'A broad boundary band affecting its inner and outer sides.'),
    'both_sides_closely_attached_edge': ('Closely attached contrast on both sides of an edge.', 'Fresnel contrast can appear as closely attached bright/dark fringes on both sides, often along the whole edge. This alone does not establish overlap.'),
    'inner': ('Artifact within an object; edge_scope is disabled and attachment patterns are not allowed.', 'An interior contrast spot that does not follow or attach to the boundary.'),
    'across_boundary': ('Artifact crossing the object/background boundary.', 'A stripe that crosses a particle boundary; partial_edge.'),
    'pattern': ('Observed contrast pattern; location is stored separately.', 'fresnel_contrast, stripe, spot or contamination. Do not infer a physical cause from contrast alone.'),
    'edge_scope': ('Extent along the edge, available only for edge-associated locations.', 'whole_edge or partial_edge; null when unknown.'),
    'severity': ('Optional project-defined severity.', 'minor, moderate or severe; null when not assessed.'),
    'notes': ('Optional free-text observations.', 'The upper-right boundary is ambiguous; null means no note.'),
    'physical_measurements': ('Measurements derived from calibration.', 'Area in nm^2; missing calibration gives null physical values.'),
    'microscopy_calibration': ('Physical coordinate scale and optional basis/origin.', 'pixel_size_x=0.2, pixel_size_y=0.2, length_unit=nm.'),
}

FIELD_HELP.update({
    'attributes': ('Project review and morphology fields inherited from the source or template.', 'shape=square, structure=solid and notes=null for a new object.'),
    'artifacts': ('Separate lists of observed artifacts by their location relative to the object.', 'Two interior spots can be two records under inner.'),
    'source_annotation_id': ('Original positive object ID retained for traceability when exported IDs are normalized.', 'Original ID 12 can export as id 3 while source_annotation_id remains 12.'),
    'samstudio_id': ('Persistent internal UUID; independent of display numbers and export numbering.', 'The same object keeps this UUID after a group change or explicit refinement.'),
    'name': ('Human-readable object name.', 'Object 003 or a specimen-specific identifier.'),
    'group_id': ('Persistent internal group identifier; category_id links the exported category.', 'All Particle objects can share one group UUID.'),
    'editable_shape': ('Drawing geometry retained in addition to the exact raster mask.', 'A polygon retains its vertex points for later editing.'),
    'kind': ('Geometry/drawing type.', 'polygon, rectangle, ellipse, circle, point or mask.'),
    'points': ('Image-coordinate vertices or prompts, with x first and y second.', '[[10, 20], [30, 40]] describes two coordinate pairs.'),
    'contours': ('Editable boundary records, including hole flags and smooth-curve information.', 'An outer loop and an inner hole remain distinct contours.'),
    'provenance': ('How this annotation was created or last refined.', 'SAM2.1 on CPU, effective text big dots and the input image version.'),
    'method': ('Operation used to generate an annotation or image edit.', 'manual, SAM, Gaussian smooth or a named plugin processor.'),
    'model': ('Selected model family and variant.', 'SAM2.1 / Tiny.'),
    'device': ('Actual execution device recorded by the operation.', 'cpu or cuda:0 inside Conda.'),
    'input': ('Image version used by inference.', 'original uncleaned pixels or cleaned/processed pixels.'),
    'normalization': ('Recorded conversion from acquired intensity values to model input.', 'A non-uint8 image can use the recorded percentile-to-RGB display stretch.'),
    'confidence_score': ('Model mask-quality estimate, not calibrated accuracy; absent for manual masks.', 'A SAM quality score of 0.9 does not establish 90% scientific accuracy.'),
    'role': ('Whether the record is an annotation or a reversible image edit.', 'object versus cleaning.'),
    'color': ('Display RGB color, separate from mask pixels and numeric IDs.', '#148374 is a hexadecimal RGB color.'),
    'opacity': ('Mask display opacity between zero and one.', '0.42 is 42% opacity; mask geometry is unchanged.'),
    'visible': ('Display visibility; hidden foreground objects still protect accepted masks.', 'false hides the overlay without deleting an annotation.'),
    'cleaning': ('Reversible removal/fill/processing record attached to an image-edit object.', 'A removed spot stores a footprint, replacement pixels and restoration steps.'),
    'sequence': ('Replay order for image edits.', 'Edit 2 is replayed after edit 1.'),
    'restoration': ('Rule for recovering pixels when an image-edit record is removed.', 'Replay remaining image edits over the uncleaned base.'),
    'values': ('Losslessly packed replacement pixel values for an image-edit region.', 'Filled pixel intensities are retained so replay does not rerun a model.'),
    'pending': ('Exact packed mask of pixels still awaiting fill/restoration.', 'A newly removed spot remains pending until filled.'),
    'steps': ('Recorded operations and parameters associated with an image edit.', 'remove followed by neighbor fill.'),
    'area_unit': ('Unit of a physical area value.', 'nm^2; standard COCO area separately remains pixel^2.'),
    'prompt_mode': ('The inference workflow that generated the masks.', 'whole-image exemplars versus ordinary single-object prompting.'),
    'example_backend': ('Native concept prompting or the application candidate-retrieval layer.', 'SAM3 native concepts; SAM candidates + feature/intensity retrieval for SAM1/2.'),
    'examples': ('Shape exemplars used to search the image.', 'A positive rectangle and a negative ellipse.'),
    'point_examples': ('Point exemplar coordinates and positive/negative labels.', '[50, 60, 1] is a positive point; label 0 is negative.'),
    'label': ('Positive/negative example label when part of prompt metadata.', '1 means positive; 0 means negative.'),
    'text_prompt': ('Original user-entered phrase before alias resolution.', 'nanoparticle.'),
    'effective_text_prompt': ('Resolved phrase actually sent to the text model.', 'big dots after resolving the nanoparticle alias.'),
    'text_backend': ('Text-to-mask implementation.', 'Grounding DINO Tiny detections followed by SAM2 masks.'),
    'size': ('Mask array dimensions in height, width order.', '[512, 768].'),
    'counts': ('COCO RLE run lengths in column-major order, starting with background.', 'Initial background runs precede alternating foreground/background runs.'),
})

def field_help(path, value=None):
    if isinstance(path,(list,tuple)):
        path=[part for part in path if not isinstance(part,int)]
        key=str(path[-1]) if path else ''
    else:key=str(path)
    title, example = FIELD_HELP.get(key, ('Custom or unrecognized metadata; its interpretation is defined by the source annotation or project template.', f'Current value: {str(value)[:500]}'))
    return title + '\n\nExample: ' + example

def merge_defaults(value=None, defaults=None):
    result = copy.deepcopy(DEFAULT_ATTRIBUTES if defaults is None else defaults)
    if value is not None:
        if not isinstance(value, dict): raise ValueError('Attributes must be a JSON object.')
        def merge(a,b):
            for k,v in b.items():
                if isinstance(v,dict) and isinstance(a.get(k),dict):merge(a[k],v)
                else:a[k]=copy.deepcopy(v)
        merge(result,value)
    return result

def validate_attributes(value):
    if not isinstance(value,dict):raise ValueError('Attributes must be a JSON object.')
    result=merge_defaults(value)
    json.dumps(result,allow_nan=False)
    for name in ('touches_image_border','truncated','exclude_from_training'):
        if not isinstance(result[name],bool):raise ValueError(f'{name} must be true or false.')
    for name in ('overlap_level','fusion'):
        if isinstance(result[name],bool) or not isinstance(result[name],(int,float)) or result[name]<0:raise ValueError(f'{name} must be a nonnegative number.')
    if not isinstance(result['artifacts'],dict):raise ValueError('artifacts must contain location lists.')
    for name,records in result['artifacts'].items():
        if not isinstance(records,list):raise ValueError(f'artifacts.{name} must be a list.')
        for record in records:
            if not isinstance(record,dict):raise ValueError('Each artifact must be an object.')
            if record.get('edge_scope') not in (None,'whole_edge','partial_edge'):raise ValueError('edge_scope must be null, whole_edge or partial_edge.')
            if name in ('outside_edge','inner'):
                record['edge_scope']=None
                if record.get('pattern') and 'attach' in str(record['pattern']).casefold():raise ValueError(f'Attachment patterns are unavailable for {name}. Choose a location separately.')
    return result

def template(value=None):
    value=copy.deepcopy(value or {})
    if 'attributes' not in value and any(k in value for k in DEFAULT_ATTRIBUTES):value={'attributes':value}
    value.setdefault('schema','samstudio.coco-template.v1')
    value.setdefault('annotation_defaults',{'iscrowd':0})
    value['attributes']=validate_attributes(value.get('attributes',{}))
    if not isinstance(value['annotation_defaults'],dict):raise ValueError('annotation_defaults must be an object.')
    forbidden={'id','image_id','segmentation','bbox','area','samstudio_id','editable_shape'} & value['annotation_defaults'].keys()
    if forbidden:raise ValueError('Templates cannot override derived/identity fields: '+', '.join(sorted(forbidden)))
    json.dumps(value,allow_nan=False)
    return value

def load_template(path):return template(json.loads(Path(path).read_text('utf-8')))
def save_template(path,value):atomic_write(Path(path),json.dumps(template(value),indent=2,allow_nan=False).encode())

def assign_annotation_ids(documents, normalize=False):
    objects=[o for d in documents for o in d.objects if o.mask is not None]
    if normalize:objects=[o for d in documents for o in d.foreground_objects() if o.mask is not None]+[o for d in documents for o in d.objects if o.mask is not None and (o.role!="object" or o.group_id==d.background_group_id)]
    used=set();mapping={}
    reserve={o.coco_id for o in objects if isinstance(o.coco_id,int) and not isinstance(o.coco_id,bool) and o.coco_id>0}
    next_id=1
    for i,obj in enumerate(objects,1):
        ident=obj.coco_id
        if normalize:ident=i
        elif not isinstance(ident,int) or isinstance(ident,bool) or ident<=0 or ident in used:
            while next_id in used or next_id in reserve:next_id+=1
            ident=next_id;next_id+=1
        used.add(ident);mapping[id(obj)]=ident
    return mapping

def base_filename(value):
    return Path(str(value).replace('\\','/')).name

def image_stem(value):return Path(base_filename(value)).stem.casefold()

def decode_segmentation(value,shape):
    import cv2
    if isinstance(value,dict):
        from .exports import decode_coco_rle
        if isinstance(value.get('counts'),list):mask=decode_coco_rle(value)
        else:
            try:from pycocotools import mask as codec
            except ImportError as e:raise ValueError('Compressed COCO masks require pycocotools.') from e
            mask=codec.decode(value).astype(bool)
    elif isinstance(value,list):
        mask=np.zeros(shape,np.uint8)
        for polygon in value:
            points=np.asarray(polygon,float).reshape(-1,2)
            if len(points)<3 or not np.isfinite(points).all():raise ValueError('Invalid COCO polygon.')
            cv2.fillPoly(mask,[np.rint(points).astype(np.int32)],1)
        mask=mask.astype(bool)
    else:raise ValueError('Expected COCO polygons or RLE.')
    if mask.shape!=shape:raise ValueError('Annotation dimensions do not match the image.')
    return mask

def import_annotations(document,path):
    """Import into a detached document before the caller commits live state."""
    from .processing import shape_mask
    data=json.loads(Path(path).read_text('utf-8'));doc=document
    if doc.rotation:raise ValueError('Import annotations before rotating the image.')
    imported=0
    if 'shapes' in data:
        name=data.get('imagePath')
        if name and image_stem(name)!=image_stem(doc.frame.source_path):raise ValueError('The AnyLabeling image name does not match.')
        if (data.get('imageWidth',doc.frame.shape[1]),data.get('imageHeight',doc.frame.shape[0]))!=(doc.frame.shape[1],doc.frame.shape[0]):raise ValueError('AnyLabeling image dimensions do not match.')
        grouped={}
        for index,s in enumerate(data['shapes']):
            kind=s.get('shape_type','polygon');points=copy.deepcopy(s.get('points',[]))
            # AnyLabeling circles store center + radius point; this app edits
            # circles by their bounding corners. Four-corner rectangles/rotated
            # boxes must also retain their actual geometry when imported.
            if kind=='circle' and len(points)==2:
                cx,cy=points[0];radius=math.dist(points[0],points[1])
                points=[[cx-radius,cy-radius],[cx+radius,cy+radius]]
            if kind in ('rectangle','rotation') and len(points)>=3:
                coordinates=np.asarray(points,float)
                if coordinates.ndim!=2 or coordinates.shape[1:]!=(2,) or not np.isfinite(coordinates).all():raise ValueError('Invalid AnyLabeling rectangle coordinates.')
                lo,hi=coordinates.min(0),coordinates.max(0)
                axis_aligned=bool(np.all(np.isclose(coordinates,lo)|np.isclose(coordinates,hi)))
                if axis_aligned:kind='rectangle';points=[lo.tolist(),hi.tolist()]
                else:kind='polygon'
            if kind not in ('point','polygon','rectangle','circle','ellipse'):continue
            label=str(s.get('label') or 'Object');doc.ensure_group(label)
            ident=s.get('group_id',s.get('id'))
            ident=ident if isinstance(ident,int) and not isinstance(ident,bool) and ident>0 else None
            key=(label,ident) if ident is not None and kind!='point' else (label,'shape',index)
            mask=None if kind=='point' else shape_mask(kind,points,doc.frame.shape)
            if key in grouped and mask is not None:
                obj=grouped[key];obj.mask|=mask;obj.kind='mask';obj.points=[];obj.contours=None
                continue
            obj=doc.add_object(kind,points,mask,{'method':'AnyLabeling import','source':str(Path(path).resolve())})
            obj.coco_id=ident or obj.coco_id
            inherited=s.get('attributes') or (s.get('flags') if isinstance(s.get('flags'),dict) else {})
            obj.attributes=validate_attributes(merge_defaults(inherited,doc.coco_template['attributes']))
            obj.coco_fields={'anylabeling':copy.deepcopy(s)}
            grouped[key]=obj;imported+=1
        doc.coco_image_fields={'anylabeling':{k:v for k,v in data.items() if k not in ('shapes','imageData')}}
    elif 'annotations' in data and 'images' in data:
        matches=[im for im in data['images'] if base_filename(im.get('source_file',im.get('file_name','')))==base_filename(doc.frame.source_path)]
        if not matches:matches=[im for im in data['images'] if image_stem(im.get('source_file',im.get('file_name','')))==image_stem(doc.frame.source_path)]
        if len(matches)!=1:raise ValueError('COCO image match is missing or ambiguous.')
        image=matches[0]
        if (image.get('width'),image.get('height'))!=(doc.frame.shape[1],doc.frame.shape[0]):raise ValueError('COCO image dimensions do not match.')
        categories={c['id']:c for c in data.get('categories',[])}
        for a in data['annotations']:
            if a.get('image_id')!=image['id'] or a.get('id')==0:continue
            category=categories.get(a.get('category_id'),{'name':'Object'})
            doc.ensure_group(str(category.get('name','Object')))
            mask=decode_segmentation(a['segmentation'],doc.frame.shape)
            if not mask.any():continue
            geometry=a.get('editable_shape',{})
            obj=doc.add_object(geometry.get('kind','mask'),geometry.get('points',[]),mask,{'method':'COCO import','source':str(Path(path).resolve()),'source_annotation_id':a.get('id')})
            obj.coco_id=a.get('id') if isinstance(a.get('id'),int) and a['id']>0 else obj.coco_id
            obj.name=a.get('name',obj.name);obj.contours=geometry.get('contours')
            obj.attributes=validate_attributes(merge_defaults(a.get('attributes',{}),doc.coco_template['attributes']))
            for key in ('exclude_from_training','review_status','touches_image_border'):
                if key in a and key not in a.get('attributes',{}):obj.attributes[key]=a[key]
            obj.coco_fields={k:copy.deepcopy(v) for k,v in a.items() if k not in ('id','image_id','category_id','segmentation','bbox','area','attributes','editable_shape','samstudio_id')}
            imported+=1
        doc.coco_image_fields=copy.deepcopy(image)
        cal=image.get('microscopy_calibration')
        if cal:
            calibration=Calibration(**cal)
            if calibration.valid:calibration.matrix();doc.calibration=calibration
    else:raise ValueError('Expected AnyLabeling shapes or a COCO images/annotations dataset.')
    ids=[o.coco_id for o in doc.objects]
    if len(ids)!=len(set(ids)):raise ValueError('Duplicate object IDs in this image. Resolve them before importing.')
    doc.annotation_source=str(Path(path).resolve())
    return imported

def sidecar_path(doc,directory=None):
    source=Path(doc.frame.source_path)
    suffix='' if doc.frame.dataset=='image' and doc.frame.frame_index==0 else '.'+re.sub(r'[^\w-]','_',doc.frame.dataset)+'.'+str(doc.frame.frame_index+1)
    if directory and Path(directory).resolve()!=source.parent.resolve():suffix+='.'+doc.frame.key[:12]
    return Path(directory or source.parent)/(source.name+suffix+'.samstudio.coco.json')

def save_review_sidecar(doc,directory=None):
    from .exports import coco_payload
    result=coco_payload([doc],include_images=False,normalize_number_of_object=doc.normalize_object_ids)
    result['images'][0]['file_name']=Path(doc.frame.source_path).name
    result['info']['annotation_source']=doc.annotation_source
    result['info']['coco_template']=copy.deepcopy(doc.coco_template)
    target=sidecar_path(doc,directory)
    atomic_write(target,json.dumps(result,indent=2,allow_nan=False,ensure_ascii=False).encode('utf-8'),True)
    return target

class PixelSizeTable:
    def __init__(self,entries,source,unit='nm'):
        self.entries,self.source,self.unit=entries,str(source),unit
    @classmethod
    def read(cls,path,sheet=None,unit='nm'):
        from openpyxl import load_workbook
        from .domain import LENGTH_UNITS
        if unit not in LENGTH_UNITS:raise ValueError('Select a supported length unit.')
        book=load_workbook(path,read_only=True,data_only=True)
        try:
            ws=book[sheet] if sheet else book.active
            rows=iter(ws.iter_rows(values_only=True));headers=next(rows,None)
            if not headers:raise ValueError('The workbook is empty.')
            columns={str(v).strip().casefold():i for i,v in enumerate(headers) if v is not None}
            if not {'converted_image_name','converted_size'}<=columns.keys():raise ValueError('Required columns: converted_image_name and converted_size.')
            entries={}
            for number,row in enumerate(rows,2):
                name=row[columns['converted_image_name']];value=row[columns['converted_size']]
                if name is None:continue
                key=image_stem(name)
                if key in entries:raise ValueError(f'Duplicate image stem at Excel row {number}: {name}')
                if isinstance(value,bool) or not isinstance(value,(int,float)) or not math.isfinite(value) or value<=0:raise ValueError(f'converted_size must be positive at Excel row {number}; formulas need cached numeric values.')
                entries[key]=float(value)
            return cls(entries,Path(path).resolve(),unit)
        finally:book.close()
    def calibration(self,name):
        value=self.entries.get(image_stem(name))
        return Calibration(value,value,self.unit,f'Excel converted_size: {self.source}',True) if value is not None else None
