"""Immediate-save COCO property editor and collapsible review panels."""
from __future__ import annotations
import copy,json
from pathlib import Path
from PySide6.QtCore import Qt,QTimer,QEvent,Signal
from PySide6.QtWidgets import (QWidget,QVBoxLayout,QHBoxLayout,QTreeWidget,QTreeWidgetItem,
    QPushButton,QLabel,QLineEdit,QComboBox,QCheckBox,QSpinBox,QDoubleSpinBox,QFileDialog,
    QMessageBox,QDialog,QDialogButtonBox,QPlainTextEdit,QInputDialog,QFormLayout,QApplication)
from .coco_review import (DEFAULT_ATTRIBUTES,EDGE_LOCATIONS,field_help,merge_defaults,
    validate_attributes,template,load_template,save_template,PixelSizeTable,import_annotations)
from .inference import data_directory

OPTIONS={
 'shape':['square','circle','ellipse','rod','polygon','irregular'],
 'structure':['solid','core_shell','hollow'], 'mask_mode':['visible','amodal'],
 'review_status':['accepted','needs_review','uncertain','rejected'],
 'edge_scope':[None,'whole_edge','partial_edge'], 'severity':[None,'minor','moderate','severe'],
 'pattern':[None,'spot','stripe','contamination','thickness_fringes','fresnel_contrast','scan_line','diffraction_contrast','other'],
}

class CocoEditor(QWidget):
    active=Signal()
    def __init__(self,save,parent=None):
        super().__init__(parent);self.save_callback=save;self.identity=None;self.value=None;self.pending=False;self.loading=False
        layout=QVBoxLayout(self);layout.setContentsMargins(3,3,3,3)
        self.hint=QLabel('Select one object. Changes save automatically.');self.hint.setWordWrap(True);layout.addWidget(self.hint)
        self.tree=QTreeWidget();self.tree.setObjectName('cocoProperties');self.tree.setHeaderLabels(['COCO field','Value','?']);self.tree.setColumnWidth(0,240);self.tree.setColumnWidth(1,220);self.tree.setColumnWidth(2,28);layout.addWidget(self.tree)
        self.tree.itemClicked.connect(lambda *a:self.active.emit())
        row=QHBoxLayout()
        self.raw_button=QPushButton('View JSON');self.raw_button.clicked.connect(self.show_json);row.addWidget(self.raw_button)
        self.add_button=QPushButton('Add artifact');self.add_button.clicked.connect(self.add_artifact);row.addWidget(self.add_button)
        self.remove_button=QPushButton('Remove artifact');self.remove_button.clicked.connect(self.remove_artifact);row.addWidget(self.remove_button)
        layout.addLayout(row)
        self.status=QLabel('');self.status.setWordWrap(True);layout.addWidget(self.status)
        self.timer=QTimer(self);self.timer.setSingleShot(True);self.timer.setInterval(180);self.timer.timeout.connect(self.flush)
        self.controls={}
    def install_control(self,w):w.installEventFilter(self);return w
    def eventFilter(self,obj,event):
        if event.type()==QEvent.Type.FocusIn and not self.loading:self.active.emit()
        return super().eventFilter(obj,event)
    def set_value(self,path,value):
        if self.loading or self.value is None:return
        target=self.value
        for key in path[:-1]:target=target[key]
        target[path[-1]]=value;self.pending=True;self.status.setText('Saving changes…');self.timer.start()
    def flush(self):
        self.timer.stop()
        if not self.pending:return True
        try:
            self.value['attributes']=validate_attributes(self.value['attributes'])
            self.save_callback(self.identity,copy.deepcopy(self.value));self.pending=False;self.status.setText('Saved automatically.');return True
        except Exception as error:self.status.setText('Not saved: '+str(error));return False
    def load(self,identity,value,force=False):
        if self.identity==identity and not force:return
        if not self.flush():return False
        self.identity=identity;self.value=copy.deepcopy(value);self.loading=True;self.tree.clear();self.controls={}
        self.hint.setText('Select one object. Changes save automatically.' if value is None else 'Edit attributes directly. No Enter key is required. Geometry follows the mask.')
        if value is not None:self._rows(self.tree.invisibleRootItem(),self.value,[])
        self.loading=False
        for i in range(self.tree.topLevelItemCount()):
            item=self.tree.topLevelItem(i)
            if item.text(0)=='attributes':item.setExpanded(True)
        return True
    def _rows(self,parent,value,path):
        pairs=value.items() if isinstance(value,dict) else enumerate(value)
        for key,current in pairs:
            here=path+[key];item=QTreeWidgetItem([str(key),'','']);parent.addChild(item);item.setData(0,Qt.ItemDataRole.UserRole,here);item.setToolTip(0,str(key))
            editable=here[0]=='attributes' or here==['id'] or here==['name'] or here==['iscrowd']
            disabled=key=='edge_scope' and len(here)>2 and here[2] not in EDGE_LOCATIONS
            help_button=QPushButton('?');help_button.setFixedWidth(24);help_button.clicked.connect(lambda checked=False,p=here,v=current:QMessageBox.information(self,'COCO field: '+str(p[-1]),field_help(p,v)));self.tree.setItemWidget(item,2,help_button)
            if isinstance(current,(dict,list)) and (here[0]=='attributes' or len(str(current))<500):
                if not current:item.setText(1,'[]' if isinstance(current,list) else '{}')
                else:self._rows(item,current,here)
                continue
            if not editable or isinstance(current,(dict,list)):
                item.setText(1,str(current)[:180] if current is not None else 'null');continue
            if isinstance(current,bool):
                control=QCheckBox();control.setChecked(current);control.toggled.connect(lambda v,p=here:self.set_value(p,v))
            elif key in ('id','iscrowd') or isinstance(current,int):
                control=QSpinBox();control.setRange(1 if key=='id' else 0 if key in ('iscrowd','overlap_level','fusion') else -2_147_483_647,2_147_483_647);control.setValue(current if current is not None else (1 if key=="id" else 0));control.valueChanged.connect(lambda v,p=here:self.set_value(p,v))
            elif isinstance(current,float):
                control=QDoubleSpinBox();control.setRange(-1e12,1e12);control.setDecimals(6);control.setValue(current);control.valueChanged.connect(lambda v,p=here:self.set_value(p,v))
            elif key in OPTIONS:
                control=QComboBox();control.setEditable(key!='edge_scope')
                for v in OPTIONS[key]:control.addItem('null' if v is None else v,v)
                if current not in OPTIONS[key]:control.addItem(str(current),current)
                control.setCurrentText('null' if current is None else str(current))
                control.currentTextChanged.connect(lambda v,p=here:self.set_value(p,None if v=='null' or not v else v))
            else:
                control=QLineEdit('' if current is None else str(current));control.setPlaceholderText('null');control.textChanged.connect(lambda v,p=here:self.set_value(p,v or None))
            control.setEnabled(not disabled);self.install_control(control);self.controls[tuple(here)]=control;self.tree.setItemWidget(item,1,control)
    def artifact_location(self):
        item=self.tree.currentItem()
        if item:
            p=item.data(0,Qt.ItemDataRole.UserRole)
            if len(p)>=3 and p[:2]==['attributes','artifacts']:return p[2],p
        return None,None
    def add_artifact(self):
        if self.value is None:return
        location,_=self.artifact_location()
        if location is None:
            location,ok=QInputDialog.getItem(self,'Artifact location','Location',list(self.value['attributes']['artifacts']),editable=False)
            if not ok:return
        from .coco_review import DEFAULT_ARTIFACT
        self.value['attributes']['artifacts'][location].append(copy.deepcopy(DEFAULT_ARTIFACT));self.pending=True
        if self.flush():self.load(self.identity,self.value,True)
    def remove_artifact(self):
        if self.value is None:return
        location,p=self.artifact_location()
        if location is None or len(p)<4 or not isinstance(p[3],int):return
        del self.value['attributes']['artifacts'][location][p[3]];self.pending=True
        if self.flush():self.load(self.identity,self.value,True)
    def show_json(self):
        if self.value is None:return
        dialog=QDialog(self);dialog.setWindowTitle('Current COCO annotation');dialog.resize(720,650);layout=QVBoxLayout(dialog)
        edit=QPlainTextEdit(json.dumps(self.value,indent=2));edit.setReadOnly(True);layout.addWidget(edit);dialog.exec()

class ReviewWorkflowMixin:
    def _init_review_ui(self):
        self.coco_editor=CocoEditor(self._save_coco_fields,self);self.coco_editor.active.connect(lambda:self._review_panel_focus('properties'))
        box=QWidget();layout=QVBoxLayout(box);layout.setContentsMargins(0,0,0,0)
        self.normalize_ids=QCheckBox('Normalize number of object');self.normalize_ids.setObjectName('normalizeObjectNumbers');self.normalize_ids.setToolTip('Export IDs 1 through n. 0 is reserved for background. Original IDs remain recorded.')
        self.normalize_ids.toggled.connect(self._normalize_changed);layout.addWidget(self.normalize_ids);layout.addWidget(self.coco_editor)
        row=QHBoxLayout()
        for title,callback in [('Template…',self.template_dialog),('Import annotations…',self.import_annotation_dialog)]:
            b=QPushButton(title);b.clicked.connect(callback);row.addWidget(b)
        layout.addLayout(row)
        self.coco_dock=self._dock('COCO properties','cocoPropertiesDock',box)
        self.coco_dock.setMinimumWidth(500)
        # A tabbed first dock causes Qt.splitDockWidget to add another tab.
        # Rebuild an explicit three-panel stack; Groups is an optional window.
        for dock in (self.objects_dock,self.groups_dock,self.coco_dock,self.files_dock):
            self.removeDockWidget(dock);dock.hide()
        self.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea,self.objects_dock)
        self.splitDockWidget(self.objects_dock,self.coco_dock,Qt.Orientation.Vertical)
        self.splitDockWidget(self.coco_dock,self.files_dock,Qt.Orientation.Vertical)
        for dock in (self.objects_dock,self.coco_dock,self.files_dock):dock.show()
        self.groups_dock.setFloating(True);self.groups_dock.hide()
        self._collapsed={};self._collapse_buttons={}
        for dock in (self.objects_dock,self.coco_dock,self.files_dock):
            title=QWidget();r=QHBoxLayout(title);r.setContentsMargins(5,1,3,1);r.addWidget(QLabel(dock.windowTitle()));r.addStretch()
            button=QPushButton('−');button.setFixedSize(25,24);button.clicked.connect(lambda checked=False,d=dock:self._toggle_review_panel(d));r.addWidget(button);dock.setTitleBarWidget(title);self._collapse_buttons[dock]=button
        self.files_tree.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu);self.files_tree.customContextMenuRequested.connect(self._image_context_menu)
        self.files_tree.itemClicked.connect(lambda *a:self._review_panel_focus('files'))
        self.objects_tree.itemClicked.connect(lambda *a:self._review_panel_focus('objects'))
        menu=self.menuBar().addMenu('COCO review')
        for name,cb in [('Import AnyLabeling / COCO annotations…',self.import_annotation_dialog),('Edit / save / open default template…',self.template_dialog),('Read pixel size from Excel…',self.pixel_table_dialog),('Remove selected images (keep annotations)',self.remove_workspace_images)]:menu.addAction(self._action(name,cb))
        self.pixel_size_table=None
        default=data_directory()/'default-coco-template.json'
        try:self.default_coco_template=load_template(default) if default.exists() else template()
        except (OSError,ValueError):self.default_coco_template=template()
        path=self.settings.value('pixel_size_table','')
        if path:
            try:self.pixel_size_table=PixelSizeTable.read(path,self.settings.value('pixel_size_sheet','') or None,self.settings.value('pixel_size_unit','nm'))
            except Exception as e:self.statusBar().showMessage('Pixel-size table was not loaded: '+str(e),15000)
        self._review_panel_focus('objects')
    def _toggle_review_panel(self,dock):
        collapsed=not self._collapsed.get(dock,False);self._set_panel_collapsed(dock,collapsed)
        if not collapsed:self.resizeDocks([dock],[320],Qt.Orientation.Vertical)
    def _set_panel_collapsed(self,dock,collapsed):
        self._collapsed[dock]=collapsed;dock.widget().setVisible(not collapsed);dock.setMinimumHeight(26 if collapsed else 100);dock.setMaximumHeight(28 if collapsed else 16_777_215);self._collapse_buttons[dock].setText('+' if collapsed else '−')
    def _review_panel_focus(self,kind):
        if not hasattr(self,'_collapsed'):return
        for dock in (self.objects_dock,self.coco_dock,self.files_dock):self._set_panel_collapsed(dock,kind=='properties' and dock is not self.coco_dock)
        self.resizeDocks([self.objects_dock,self.coco_dock,self.files_dock],[28,600,28] if kind=='properties' else [300,300,300],Qt.Orientation.Vertical)
    def _sync_review_editor(self):
        if not hasattr(self,'coco_editor'):return
        doc=self.document;objects=self.selected_objects() if doc else []
        obj=objects[0] if len(objects)==1 else None
        identity=(self.current_key,obj.id) if obj else None
        focus=QApplication.focusWidget()
        refresh_same=bool(doc and obj and getattr(self.coco_editor,'_loaded_revision',None)!=doc.revision and not self.coco_editor.pending and not (focus and self.coco_editor.isAncestorOf(focus)))
        if identity!=self.coco_editor.identity or refresh_same:
            from .exports import coco_payload
            values=None
            if obj:
                payload=coco_payload([doc],include_images=False)
                values=next((a for k in ('annotations','cleaning_annotations','background_annotations') for a in payload[k] if a['samstudio_id']==obj.id),None)
                if values is None:values={'id':obj.coco_id or 1,'name':obj.name,'attributes':merge_defaults(obj.attributes),'note':'Point annotations have no area segmentation.'}
            if self.coco_editor.load(identity,values,refresh_same):self.coco_editor._loaded_revision=doc.revision if doc else None
        self.normalize_ids.blockSignals(True);self.normalize_ids.setChecked(bool(doc and doc.normalize_object_ids));self.normalize_ids.blockSignals(False)
        self.coco_editor.setEnabled(bool(doc and not self.busy))
    def _save_coco_fields(self,identity,values):
        if identity is None:return
        key,ident=identity;doc=self.documents.get(key)
        if doc is None:raise ValueError('This image is no longer open.')
        obj=next((o for o in doc.objects if o.id==ident),None)
        if obj is None:raise ValueError('This object was removed.')
        if obj.locked:raise ValueError('Unlock the object before editing its properties.')
        ident_value=values['id']
        if any(o is not obj and o.coco_id==ident_value for o in doc.objects):raise ValueError('This object ID is already in use in the image.')
        def apply():
            obj.attributes=validate_attributes(values['attributes']);obj.coco_id=ident_value;obj.name=values.get('name',obj.name)
            obj.coco_fields['iscrowd']=values.get('iscrowd',0)
        self.histories[key].apply('Edit COCO fields',apply)
        self.coco_editor._loaded_revision=doc.revision
        blocked=self.objects_tree.blockSignals(True)
        try:
            for i in range(self.objects_tree.topLevelItemCount()):
                item=self.objects_tree.topLevelItem(i)
                if item.data(0,Qt.ItemDataRole.UserRole)==obj.id:item.setText(0,('[Cleaning] ' if obj.role=='cleaning' else '')+obj.name)
        finally:self.objects_tree.blockSignals(blocked)
    def _normalize_changed(self,value):
        if self.document and not self._updating:self._commit('COCO number normalization',lambda:setattr(self.document,'normalize_object_ids',bool(value)))
    def _flush_coco_editor(self):return not hasattr(self,'coco_editor') or self.coco_editor.flush()
    def _image_context_menu(self,position):
        from PySide6.QtWidgets import QMenu
        menu=QMenu(self);menu.addAction('Remove selected images (keep annotations)',self.remove_workspace_images);menu.exec(self.files_tree.viewport().mapToGlobal(position))
    def remove_workspace_images(self,keys=None):
        if self.busy or not self._flush_coco_editor():return
        keys=keys if isinstance(keys,set) else self.selected_images() or ({self.current_key} if self.current_key else set())
        try:
            for key in keys:
                if key in self.documents:self._persist(self.documents[key])
        except Exception as e:self.notify('Image removal blocked',str(e));return
        self.coco_editor.load(None,None)
        for key in keys:
            self.documents.pop(key,None);self.histories.pop(key,None);self.stores.pop(key,None);self.mask_savepoints.pop(key,None)
        self.current_key=None;self.canvas.set_document(None);self._rebuild_file_tree()
        if self.documents:self.select_document(next(iter(self.documents)))
        else:self._refresh()
        self.settings.setValue('last_files',list(dict.fromkeys(d.frame.source_path for d in self.documents.values())));self.settings.sync()
    def _offer_session_restore(self,paths):
        answer=QMessageBox.question(self,'Reopen previous images?','Reopen the images from the previous session? Saved annotations remain available even if you choose No.',QMessageBox.StandardButton.Yes|QMessageBox.StandardButton.No,QMessageBox.StandardButton.No)
        if answer==QMessageBox.StandardButton.Yes:self.open_paths(paths)
        else:self.settings.setValue('last_files',[]);self.settings.sync()
    def import_annotation_dialog(self):
        if not self.document or self.busy:return
        path,_=QFileDialog.getOpenFileName(self,'Import matching AnyLabeling / COCO JSON','','Annotations (*.json)')
        if not path:return
        try:
            if self.document.objects:raise ValueError('Import into an image with no objects to avoid duplicate annotations. Existing annotations are preserved.')
            from .domain import Document
            candidate=Document(self.document.frame);candidate.coco_template=copy.deepcopy(self.document.coco_template)
            count=import_annotations(candidate,path)
            self._commit('Import annotations',lambda:self.document.restore(candidate.state()))
            self.statusBar().showMessage(f'Imported {count} objects. Source JSON was preserved.',12000)
        except Exception as e:self.notify('Annotation import',str(e))
    def template_dialog(self):
        if self.busy:return
        dialog=QDialog(self);dialog.setWindowTitle('Default COCO template');dialog.resize(750,700);layout=QVBoxLayout(dialog)
        layout.addWidget(QLabel('Defaults apply to new objects. Existing values are preserved. Save/open a template as JSON.'))
        edit=QPlainTextEdit(json.dumps(self.document.coco_template if self.document else self.default_coco_template,indent=2));layout.addWidget(edit)
        row=QHBoxLayout()
        def open_file():
            path,_=QFileDialog.getOpenFileName(dialog,'Open COCO template','','JSON (*.json)')
            if path:
                try:edit.setPlainText(json.dumps(load_template(path),indent=2))
                except Exception as e:QMessageBox.warning(dialog,'Template',str(e))
        def save_file():
            path,_=QFileDialog.getSaveFileName(dialog,'Save COCO template','coco_template.json','JSON (*.json)')
            if path:
                try:save_template(path,template(json.loads(edit.toPlainText())))
                except Exception as e:QMessageBox.warning(dialog,'Template',str(e))
        for title,cb in [('Open…',open_file),('Save as…',save_file),('Reset defaults',lambda:edit.setPlainText(json.dumps(template(),indent=2)))]:
            button=QPushButton(title);button.clicked.connect(cb);row.addWidget(button)
        layout.addLayout(row);buttons=QDialogButtonBox(QDialogButtonBox.StandardButton.Ok|QDialogButtonBox.StandardButton.Cancel);layout.addWidget(buttons);buttons.rejected.connect(dialog.reject)
        def apply():
            try:
                value=template(json.loads(edit.toPlainText()));save_template(data_directory()/'default-coco-template.json',value);self.default_coco_template=value
                if self.document:self._commit('Change COCO template',lambda:setattr(self.document,'coco_template',copy.deepcopy(value)))
                dialog.accept()
            except Exception as e:QMessageBox.warning(dialog,'Template',str(e))
        buttons.accepted.connect(apply);dialog.exec()
    def pixel_table_dialog(self):
        path,_=QFileDialog.getOpenFileName(self,'Read converted_size from Excel','','Excel workbook (*.xlsx *.xlsm)')
        if not path:return
        try:
            from openpyxl import load_workbook
            book=load_workbook(path,read_only=True);names=book.sheetnames;book.close()
            sheet,ok=QInputDialog.getItem(self,'Pixel-size table','Worksheet',names,editable=False)
            if not ok:return
            unit,ok=QInputDialog.getItem(self,'Pixel-size unit','Physical unit per pixel (converted_size)', ['nm','µm','pm','Å','mm','m'],editable=False)
            if not ok:return
            lookup=PixelSizeTable.read(path,sheet,unit);self.pixel_size_table=lookup;matched=0
            for key,doc in self.documents.items():
                cal=lookup.calibration(doc.frame.source_path)
                if cal:
                    if doc.rotation:continue
                    self.histories[key].apply('Excel pixel size',lambda d=doc,c=cal:setattr(d,'calibration',c));matched+=1
            self.settings.setValue('pixel_size_table',str(Path(path).resolve()));self.settings.setValue('pixel_size_sheet',sheet);self.settings.setValue('pixel_size_unit',unit)
            self._refresh();self.statusBar().showMessage(f'Pixel sizes applied to {matched} images. Unmatched and rotated images were preserved.',15000)
        except Exception as e:self.notify('Pixel-size table',str(e))
