import copy,json,os,threading
from pathlib import Path
from types import SimpleNamespace
import numpy as np
import pytest
from PySide6.QtCore import Qt
from samstudio.domain import Document,ImageFrame,History,unpack_array
from samstudio.coco_review import (DEFAULT_ATTRIBUTES,ARTIFACT_LOCATIONS,EDGE_LOCATIONS,validate_attributes,
    template,save_template,load_template,import_annotations,PixelSizeTable,save_review_sidecar)
from samstudio.exports import coco_payload,decode_coco_rle
from samstudio.image_processing import METHODS,parameters,process_pixels,retain_crop,paste_crop,processing_target,apply_processing


def mount(window,doc):
    from samstudio.domain import ProjectStore
    key=doc.frame.key;window.documents[key]=doc;window.stores[key]=ProjectStore(Path(doc.frame.source_path).parent/'SAM_Annotations');window.histories[key]=History(doc,lambda:window._persist(doc));window._rebuild_file_tree();window.select_document(key);return doc


def test_defaults_template_roundtrip_and_independence(document,tmp_path):
    attrs=document.objects[0].attributes
    assert attrs==DEFAULT_ATTRIBUTES
    assert set(attrs['artifacts'])==set(ARTIFACT_LOCATIONS)
    attrs['artifacts']['inner'][0]['notes']='spot'
    other=document.add_object('point',[[1,1]])
    assert other.attributes['artifacts']['inner'][0]['notes'] is None
    t=template({'attributes':{'shape':'rod','custom_quality':None},'annotation_defaults':{'iscrowd':0,'source_lab':'A'}})
    save_template(tmp_path/'template.json',t);document.coco_template=load_template(tmp_path/'template.json')
    obj=document.add_object('point',[[2,2]])
    assert obj.attributes['shape']=='rod' and 'custom_quality' in obj.attributes and obj.coco_fields['source_lab']=='A'
    restored=Document(document.frame);restored.restore(document.state());assert restored.coco_template==t

@pytest.mark.parametrize('location',list(ARTIFACT_LOCATIONS))
def test_artifact_scope_rules(document,location):
    a=copy.deepcopy(document.objects[0].attributes);a['artifacts'][location][0]['edge_scope']='whole_edge'
    a=validate_attributes(a);assert a['artifacts'][location][0]['edge_scope']==('whole_edge' if location in EDGE_LOCATIONS else None)

@pytest.mark.parametrize('location',['inner','outside_edge'])
def test_attachment_patterns_rejected_for_non_edge_scope(document,location):
    a=copy.deepcopy(document.objects[0].attributes);a['artifacts'][location][0]['pattern']='attached_band'
    with pytest.raises(ValueError,match='Attachment'):validate_attributes(a)

@pytest.mark.parametrize('bad',[{'segmentation':[]},{'id':4},{'bbox':[1,2,3,4]}])
def test_template_cannot_override_geometry_or_identity(bad):
    with pytest.raises(ValueError):template({'annotation_defaults':bad})


def test_coco_id_normalization_optional_and_source_ids_retained(document):
    document.objects[0].coco_id=7
    m=np.zeros(document.frame.shape,bool);m[60:70,80:90]=True
    document.add_object('mask',mask=m).coco_id=21
    ordinary=coco_payload([document]);normalized=coco_payload([document],normalize_number_of_object=True)
    assert [a['id'] for a in ordinary['annotations']]==[7,21]
    assert [a['id'] for a in normalized['annotations']]==[1,2]
    assert [a['source_annotation_id'] for a in normalized['annotations']]==[7,21]
    assert [o.coco_id for o in document.objects]==[7,21]
    assert normalized['annotations'][0]['attributes']['shape']=='square'


def test_normalized_training_annotations_start_at_one_with_background(document):
    first=document.objects[0];document.background_group_id=first.group_id
    document.ensure_group('Particle2');mask=np.zeros(document.frame.shape,bool);mask[70:80,60:70]=True;document.add_object('mask',mask=mask)
    value=coco_payload([document],normalize_number_of_object=True)
    assert value['annotations'][0]['id']==1 and value['background_annotations'][0]['id']==2


def test_anylabeling_import_groups_components_and_keeps_attributes(document,tmp_path):
    doc=Document(document.frame)
    source={'imagePath':'source.png','imageWidth':160,'imageHeight':128,'shapes':[
        {'label':'Particle','shape_type':'rectangle','group_id':7,'points':[[10,10],[20,20]],'attributes':{'shape':'rod','notes':'inherited'}},
        {'label':'Particle','shape_type':'rectangle','group_id':7,'points':[[30,10],[40,20]]},
        {'label':'Particle','shape_type':'point','group_id':12,'points':[[70,50]]}]}
    p=tmp_path/'source.json';p.write_text(json.dumps(source));before=p.read_bytes()
    assert import_annotations(doc,p)==2
    assert doc.objects[0].coco_id==7 and doc.objects[0].attributes['shape']=='rod' and doc.objects[0].mask[15,35]
    assert doc.objects[1].coco_id==12 and doc.objects[1].mask is None
    assert p.read_bytes()==before


def test_coco_roundtrip_preserves_masks_holes_ids_and_attributes(document,tmp_path):
    document.objects[0].coco_id=19;document.objects[0].attributes['notes']='boundary ambiguous'
    payload=coco_payload([document]);p=tmp_path/'in.coco.json';p.write_text(json.dumps(payload));restored=Document(document.frame)
    assert import_annotations(restored,p)==1
    assert restored.objects[0].coco_id==19 and np.array_equal(restored.objects[0].mask,document.objects[0].mask)
    assert restored.objects[0].attributes['notes']=='boundary ambiguous'


def test_sidecar_distinct_from_anylabeling_and_readable(document,tmp_path):
    original=tmp_path/'source.json';original.write_text('{"shapes":[]}');before=original.read_bytes()
    path=save_review_sidecar(document)
    assert path.name.startswith('source.tif') and path.name.endswith('.samstudio.coco.json')
    value=json.loads(path.read_text());assert value['images'][0]['file_name']=='source.tif'
    assert np.array_equal(decode_coco_rle(value['annotations'][0]['segmentation']),document.objects[0].mask)
    assert original.read_bytes()==before


def test_excel_stem_matching_and_units(tmp_path):
    from openpyxl import Workbook
    book=Workbook();ws=book.active;ws.append(['converted_image_name','converted_size']);ws.append(['particle.a.png',.24]);ws.append(['other.tiff',.6]);p=tmp_path/'sizes.xlsx';book.save(p)
    lookup=PixelSizeTable.read(p,unit='nm');assert lookup.calibration('C:/images/particle.a.tiff').pixel_size_x==.24
    assert lookup.calibration('other.emd').pixel_size_y==.6 and lookup.calibration('missing.png') is None

@pytest.mark.parametrize('bad',[0,-.2,'0.2',True,None])
def test_excel_invalid_pixel_size_does_not_load(tmp_path,bad):
    from openpyxl import Workbook
    book=Workbook();book.active.append(['converted_image_name','converted_size']);book.active.append(['a.png',bad]);p=tmp_path/'invalid.xlsx';book.save(p)
    with pytest.raises(ValueError):PixelSizeTable.read(p)


def test_excel_ambiguous_stems_rejected(tmp_path):
    from openpyxl import Workbook
    book=Workbook();book.active.append(['converted_image_name','converted_size']);book.active.append(['a.png',.2]);book.active.append(['a.tiff',.3]);p=tmp_path/'duplicate.xlsx';book.save(p)
    with pytest.raises(ValueError,match='Duplicate'):PixelSizeTable.read(p)


def test_coco_editor_saves_without_enter_and_on_selection_change(window,document,qtbot):
    doc=mount(window,document);obj=doc.objects[0];other=doc.add_object('point',[[80,80]]);window._refresh();window.canvas.set_selected({obj.id});window._canvas_selected({obj.id})
    control=window.coco_editor.controls[('attributes','notes')];control.setText('saved without Enter');qtbot.waitUntil(lambda:obj.attributes['notes']=='saved without Enter',timeout=3000)
    control.setText('saved on switch');window.canvas.set_selected({other.id});window._canvas_selected({other.id})
    assert obj.attributes['notes']=='saved on switch' and other.attributes['notes'] is None
    raw=json.loads(window.stores[doc.frame.key].path(doc).read_text());assert raw['objects'][0]['attributes']['notes']=='saved on switch'


def test_coco_scope_fields_disabled_and_help_every_field(window,document):
    mount(window,document);window.canvas.set_selected({document.objects[0].id});window._canvas_selected(window.canvas.selected)
    assert not window.coco_editor.controls[('attributes','artifacts','inner',0,'edge_scope')].isEnabled()
    assert window.coco_editor.controls[('attributes','artifacts','across_boundary',0,'edge_scope')].isEnabled()
    root=window.coco_editor.tree.invisibleRootItem()
    def visit(item):
        for i in range(item.childCount()):
            child=item.child(i);assert window.coco_editor.tree.itemWidget(child,2).text()=='?';visit(child)
    visit(root)


def test_panels_collapse_and_expand(window,document):
    mount(window,document);window._review_panel_focus('properties')
    assert window._collapsed[window.objects_dock] and window._collapse_buttons[window.objects_dock].text()=='+'
    window._toggle_review_panel(window.objects_dock);assert not window._collapsed[window.objects_dock]
    window._review_panel_focus('files');assert not any(window._collapsed.values())


def test_remove_workspace_images_keeps_annotations(window,document):
    mount(window,document);window._persist(document);native=window.stores[document.frame.key].path(document)
    from samstudio.coco_review import sidecar_path
    sidecar=sidecar_path(document);window.remove_workspace_images({document.frame.key})
    assert not window.documents and native.exists() and sidecar.exists()

@pytest.mark.parametrize('answer',['Yes','No'])
def test_startup_restore_asks_before_opening(window,monkeypatch,answer):
    from PySide6.QtWidgets import QMessageBox
    calls=[];monkeypatch.setattr(QMessageBox,'question',lambda *a,**k:getattr(QMessageBox.StandardButton,answer));window.open_paths=lambda paths:calls.extend(paths)
    window._offer_session_restore(['a.png']);assert calls==(['a.png'] if answer=='Yes' else [])
    if answer=='No':assert not window.settings.value('last_files',[])

@pytest.mark.parametrize('method',list(METHODS))
@pytest.mark.parametrize('dtype',[np.uint16,np.float32])
def test_processing_methods_preserve_dtype_outside_region_and_restore(method,dtype):
    rng=np.random.default_rng(9);raw=rng.uniform(0,1,(40,48));raw=(raw*65535).astype(dtype) if dtype==np.uint16 else raw.astype(dtype)
    target=np.zeros(raw.shape,bool);target[5:35,6:42]=True
    result=process_pixels(raw,method,target=target)
    assert result.dtype==raw.dtype and result.shape==raw.shape and np.isfinite(result).all()
    assert np.array_equal(result[~target],raw[~target])


def test_noise_seed_reproducible_and_rgba_alpha_preserved():
    raw=np.full((20,30,4),120,np.uint8);raw[...,3]=np.arange(30)
    a=process_pixels(raw,'Gaussian noise',{'sigma':.1,'seed':5});b=process_pixels(raw,'Gaussian noise',{'sigma':.1,'seed':5})
    assert np.array_equal(a,b) and np.array_equal(a[...,3],raw[...,3]) and not np.array_equal(a[...,:3],raw[...,:3])

@pytest.mark.parametrize('method,p',[('Gaussian smooth',{'kernel_size':4}),('Median denoise',{'kernel_size':2}),('TV restoration',{'weight':float('nan')}),('Poisson noise',{'peak_counts':0})])
def test_invalid_processing_parameters_rejected(method,p):
    with pytest.raises(ValueError):parameters(method,p)


def test_crop_real_background_padding_protection_paste_and_recovery(document):
    doc=document;mask=np.zeros(doc.frame.shape,bool);mask[20:40,30:50]=True;mask[20:25,30:35]=False
    crop=retain_crop(doc,mask,'sample',True,3);x,y,w,h=crop['bbox'];assert [x,y,w,h]==[27,17,26,26]
    assert np.array_equal(unpack_array(crop['pixels']),doc.frame.raw[y:y+h,x:x+w])
    target=processing_target(doc);assert not target[y:y+h,x:x+w].any()
    modified=doc.frame.raw.copy();modified[target]=0;apply_processing(doc,modified,target,'Test rest',{})
    crop['protected']=False;target2=np.ones(doc.frame.shape,bool);modified[:]=0;apply_processing(doc,modified,target2,'Test all',{})
    paste_crop(doc,crop['id']);assert np.array_equal(doc.working[y:y+h,x:x+w],doc.frame.raw[y:y+h,x:x+w])
    state=doc.state();restored=Document(doc.frame);restored.restore(state);assert restored.detached_crops[0]['name']=='sample' and np.array_equal(restored.working,doc.working)


def test_processing_apply_undo_exact(document):
    before=document.state();history=History(document);target=processing_target(document);result=process_pixels(document.frame.raw,'Gaussian smooth',target=target)
    history.apply('Smooth',lambda:apply_processing(document,result,target,'Gaussian smooth',{}));assert document.working is not None
    history.undo();assert document.working is None and document.state()['objects']==before['objects']


def test_processing_dialog_resets_defaults_on_reopen(window):
    from samstudio.processing_ui import ProcessingDialog
    first=ProcessingDialog(['Gaussian smooth'],window);first.controls['kernel_size'].setValue(9)
    second=ProcessingDialog(['Gaussian smooth'],window);assert second.controls['kernel_size'].value()==5
    first.deleteLater();second.deleteLater()


def test_review_panels_are_three_distinct_vertical_docks(window,document,qtbot):
    mount(window,document);window._review_panel_focus('objects');qtbot.wait(30)
    assert not window.tabifiedDockWidgets(window.objects_dock)
    assert window.objects_dock.y()<window.coco_dock.y()<window.files_dock.y()
    assert all(d.isVisible() for d in (window.objects_dock,window.coco_dock,window.files_dock))
    window._review_panel_focus('properties');qtbot.wait(30)
    assert window.objects_dock.height()<=30 and window.files_dock.height()<=30
    assert window.coco_dock.height()>window.objects_dock.height()*3


def test_property_panel_updates_geometry_after_edit_and_undo(window,document):
    mount(window,document);obj=document.objects[0];window.canvas.set_selected({obj.id});window._canvas_selected(window.canvas.selected)
    before=window.coco_editor.value['area']
    window._commit('Change mask',lambda:setattr(obj,'mask',np.ones(document.frame.shape,bool)))
    assert window.coco_editor.value['area']>before
    window.undo();assert window.coco_editor.value['area']==before


def test_native_pdf_help_has_real_rendered_page(window,qtbot):
    from PySide6.QtCore import QSize
    dialog=window.open_pdf_help();assert dialog is not None and dialog.document.pageCount()>10
    image=dialog.document.render(0,QSize(600,800));assert not image.isNull()
    array=np.frombuffer(image.bits(),np.uint8,count=image.sizeInBytes()).reshape(image.height(),image.bytesPerLine())
    assert np.count_nonzero(array[:,:image.width()*4].reshape(image.height(),image.width(),4)[...,:3]<150)>1000
    dialog.close()


def test_zero_numeric_defaults_are_displayed_as_zero(window,document):
    mount(window,document);window.canvas.set_selected({document.objects[0].id});window._canvas_selected(window.canvas.selected)
    for path in [('iscrowd',),('attributes','overlap_level'),('attributes','fusion')]:
        assert window.coco_editor.controls[path].value()==0


def test_invalid_duplicate_id_blocks_selection_without_saving_wrong_object(window,document):
    doc=mount(window,document);other=doc.add_object('point',[[80,80]]);window._refresh();first=doc.objects[0]
    window.canvas.set_selected({first.id});window._canvas_selected({first.id})
    field=window.coco_editor.controls[('id',)];field.setValue(other.coco_id)
    window.canvas.set_selected({other.id});window._canvas_selected({other.id})
    assert window.canvas.selected=={first.id} and first.coco_id!=other.coco_id
    field.setValue(first.coco_id);assert window.coco_editor.flush()


def test_pasted_crop_remains_exportable_after_rotation_and_recovery(document):
    from samstudio.transforms import rotate_document
    mask=np.zeros(document.frame.shape,bool);mask[70:110,110:150]=True
    crop=retain_crop(document,mask,'retain',True,3);pixels=unpack_array(crop['pixels']).copy();paste_crop(document,crop['id'])
    rotate_document(document,90,'rectangle')
    restored=Document(document.frame);restored.source_raw=document.source_raw;restored.restore(document.state())
    assert np.array_equal(unpack_array(restored.detached_crops[0]['pixels']),pixels)
    with pytest.raises(ValueError,match='coordinates'):paste_crop(restored,crop['id'])


@pytest.mark.parametrize('kind,points,expected_kind,inside,outside',[
    ('circle',[[30,40],[40,40]],'circle',[40,30],[55,30]),
    ('rectangle',[[10,20],[30,20],[30,40],[10,40]],'rectangle',[30,20],[45,35]),
    ('rotation',[[30,10],[50,30],[30,50],[10,30]],'polygon',[30,30],[10,10]),
])
def test_anylabeling_circle_and_four_corner_boxes_keep_geometry(document,tmp_path,kind,points,expected_kind,inside,outside):
    doc=Document(document.frame);path=tmp_path/'shapes.json'
    path.write_text(json.dumps({'imagePath':'source.tif','imageWidth':160,'imageHeight':128,'shapes':[{'label':'Particle','shape_type':kind,'points':points}]}))
    assert import_annotations(doc,path)==1
    obj=doc.objects[0];assert obj.kind==expected_kind and obj.mask[inside[0],inside[1]] and not obj.mask[outside[0],outside[1]]
    assert obj.coco_fields['anylabeling']['points']==points
