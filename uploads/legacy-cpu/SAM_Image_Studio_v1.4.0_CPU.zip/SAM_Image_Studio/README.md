# SAM Image Studio 1.5.0

Desktop microscopy annotation, exemplar segmentation, COCO review, calibrated
statistics and reversible processing in Python 3.12 / PySide6.

Extract the complete archive. On Windows run Install_CPU.bat and Start_GUI.bat.
On Linux run `bash install_cpu.sh` and `bash start_gui.sh`. For NVIDIA GPUs use
Install_GPU_Conda.bat or GPU_CONDA_GUIDE.md; GPU execution requires Conda.

## New workflows

- Open one/many images; source filenames and stack frames stay selectable in
  Image files. Objects occupy the top-right panel, COCO properties the middle,
  and Image files the bottom. Property editing collapses the other two title
  rows; + reopens them. All three panels can be resized.
- Import matching AnyLabeling/COCO JSON, inherit attributes and retain original
  source JSON. Edit review fields with per-field explanations/examples, no
  Enter requirement and automatic save before object/image changes.
- Keep original positive object IDs and gaps or select Normalize number of
  object to export 1 through n. Zero stays reserved for background.
- Save/open reusable default COCO templates. Seven independent artifact-location
  lists retain pattern, edge scope, severity and notes, with scope restrictions.
- Read physical pixel size from Excel using converted_image_name stems and
  numeric converted_size. Choose units explicitly; ambiguous stems are rejected.
- Whole-image exemplar previews use multiple positive/negative points and
  shapes. SAM1/2 use an explicit candidate/feature-retrieval layer; optional
  native SAM3 uses concept prompts. Single object retains native SAM refinement.
- Point hides ROI-only selection. Text has a dedicated Run button. Selecting
  Automatic grid starts it after prerequisites and reports progress/counts.
- Denoise with TV, TV Bregman, sparse wavelets, non-local means, bilateral or
  median methods. Gaussian smoothing has selectable odd kernel and sigma.
  Add Gaussian/Poisson/impulse noise with explicit strength and seed.
- Retain mask bounding rectangles expanded by 3 pixels, including real
  background. Protect them while processing the rest, export or paste them back.
- Startup asks before restoring previous images. Remove selected workspace
  images while preserving all saved annotation files.
- Help opens the English PDF User Manual. Plugin has a separate English
  For Developer PDF, API v1 and an executable TorchScript U-Net example.

## Existing workflows retained

Manual/Segment/Clean/Edit modes, pixel-region inversion, group/LUT20 colors,
real model downloads, microscopy readers/calibration, live prompts, native
projects/backups, exact COCO masks, reviewed YOLO conversion, transparent and
overlap-weighted exports, original/processed TIFFs, cleaning objects/restoration,
editable smooth contours, rotation/padding/fill, 32 metrics with at most nine
plot choices, configurable axes, mask scaling and temporary/local savepoints.

Native schema 5 reads schemas 1-4. Native projects preserve full editing state.
The separate per-image `.samstudio.coco.json` files are review/export sidecars.
Older applications may not read schema 5; back up projects before upgrading.

## Documents and validation

- docs/USER_MANUAL.md and samstudio/resources/SAM_Image_Studio_User_Manual.pdf
- docs/FOR_DEVELOPER.md and samstudio/resources/SAM_Image_Studio_For_Developer.pdf
- INSTALL_UNINSTALL.md and GPU_CONDA_GUIDE.md
- TEST_REPORT.md and validation/ machine-readable evidence

The release is tested on Linux x86-64 CPU with real SAM1, SAM2.1, Grounding DINO
and LaMa checkpoints. The actual U-Net interface test uses untrained test
weights and makes no denoising-quality claim. Native Windows/macOS, CUDA and
real SAM3 weights require target-hardware acceptance. SAM3 CPU is not enabled
as a verified backend. No weights or Windows executable are bundled.

Application source: MIT. Upstream notices: third_party/NOTICE.md.
