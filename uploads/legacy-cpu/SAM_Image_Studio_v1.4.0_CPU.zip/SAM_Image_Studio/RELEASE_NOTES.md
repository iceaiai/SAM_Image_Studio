# SAM Image Studio 1.5.0

Released October 21, 2026.

The update adds immediate-save COCO review and separates whole-image example
retrieval from ordinary single-object prompts. It also adds image processing,
retained crops, English PDF help and a local plugin API.

## COCO and image sessions

Three vertically stacked right panels hold Objects, COCO properties and Image
files. Attributes inherit matching AnyLabeling/COCO values and otherwise use
an editable template. Each field has help/examples. Numeric zero defaults are
displayed as zero. Property edits save without Enter; changing selection flushes
the prior object, and invalid duplicate IDs block a misleading selection switch.

Per-image sidecars use `.samstudio.coco.json`, preserving AnyLabeling originals.
Original IDs/gaps are kept unless normalization is selected. Foreground IDs
then become 1-n; background zero is never used as an annotation ID. Templates
and explicit artifact lists persist. Excel filename stems map converted_size
to a user-selected physical unit. Startup asks before reopening old images;
workspace removal preserves images and annotation files.

## Segmentation

Whole-image positive/negative point and shape examples update before acceptance.
SAM1/2 propose masks and retrieve similar candidates with pooled SAM features,
intensity/shape descriptors and additional small-object correlation seeds.
SAM3 uses its native concept processor when its optional backend is available.
The application retrieval layer is recorded in accepted provenance and is not
presented as native SAM3 or a validated nanoparticle classifier.

Single object preserves native SAM prompting. Point disables ROI-only selection.
Text has a dedicated Run button/Enter action; Automatic grid starts on selection
or after prerequisites and ignores unrelated text input. Newer live examples
supersede older background results. Accepted masks remain protected.

## Processing and extensions

TV/TV Bregman, sparse wavelet, non-local means, bilateral and median restoration;
Gaussian smoothing with odd kernel/sigma; Gaussian, Poisson and impulse noise.
Parameters reset on each new dialog/method. Preview/Apply preserves dtype,
alpha and outside-target pixels. Retained crop rectangles contain real pixels
plus 3 pixels of context, can protect the rest-processing workflow, and can be
exported or pasted back. Native state keeps crop snapshots and coordinates.

PDF help covers functions and examples. The separate For Developer guide covers
all-source access, plugin API v1, transactional actions, worker processors,
relative modules, output validation and a real TorchScript U-Net interface test.
No trained U-Net denoising weights are included.

## Environment and migration

The default CPU environment stays separate. CUDA loading requires Conda. The
setup detects NVIDIA devices/drivers and chooses a supported wheel index.
Optional native SAM3 targets Linux/WSL2 Conda; its NumPy/TIFF/codec dependencies
are kept compatible. SAM3 CPU, native Windows/macOS and actual CUDA/SAM3 weights
are not claimed as tested by a CPU-only validation machine.

Schema 5 reads earlier schemas 1-4. Keep native projects for exact editable
recovery. See TEST_REPORT.md for actual tests and limitations.
