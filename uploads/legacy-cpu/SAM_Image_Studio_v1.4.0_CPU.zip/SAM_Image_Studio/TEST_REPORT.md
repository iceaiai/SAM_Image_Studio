# SAM Image Studio 1.5.0 - validation report

Date: October 21, 2026

## Result

The complete run passed **431 tests**, with **0 failures, 0 errors and 0 skipped tests**, in 275.573 seconds. This includes **100 v1.5 feature cases**. v15_features.xml is the new-feature subset extracted from that same complete run, not an additional independent run.

The run emitted one NumPy deprecation warning inside pycocotools; exact compressed-RLE decoding and round-trip assertions passed.

## Environment

Linux x86-64, Python 3.12.14, PySide6 6.8.3 and the Qt offscreen platform. Models ran on CPU with PyTorch 2.7.1+cpu / torchvision 0.22.1+cpu. NumPy 2.3.5, SciPy 1.17.0, scikit-image 0.26.0, Transformers 4.53.3, openpyxl 3.1.5 and PyWavelets 1.10.0 were installed. Full packages are recorded in installed_cpu_freeze_v15.txt.

## Test inventory

| Module | Passed |
| --- | ---: |
| test_core | 27 |
| test_exports_io | 40 |
| test_extra_regressions | 8 |
| test_gui | 18 |
| test_gui_fill_and_export | 5 |
| test_install_safety | 3 |
| test_microscopy_readers | 5 |
| test_real_models | 28 |
| test_recovery_download | 8 |
| test_v11_regressions | 28 |
| test_v12_regressions | 51 |
| test_v13_features | 52 |
| test_v14_features | 58 |
| test_v15_review_processing | 68 |
| test_v15_segmentation_plugins_gpu | 32 |
| **Total** | **431** |

## COCO review and sessions

- Matching AnyLabeling shapes and COCO masks import with inherited attributes. Same-label grouped components remain one object; exact RLE holes survive round trips. Circle, four-corner rectangle and rotated-box imports are checked. Original annotation inputs remain byte-for-byte unchanged.
- Default review attributes and seven independent artifact-location lists are retained. Outside-edge/interior edge scope is disabled, inappropriate attachment patterns are rejected, and numeric zero defaults display as zero.
- Object IDs/gaps remain unless normalization is chosen. Normalized foreground IDs start at 1; background/cleaning collections do not consume those foreground numbers. Source IDs remain recorded.
- Templates save/open, apply to new objects and preserve custom fields. Templates cannot override mask geometry or identity.
- Notes save without Enter. Switching objects flushes the prior edit; duplicate-ID validation blocks an incorrect selection switch. Native/COCO sidecars save, workspace removal retains files, and startup Yes/No is exercised.
- Three actual vertical docks are checked by their geometry, including collapsed title-row sizes and expansion. The COCO panel follows committed geometry and Undo.
- Excel matches case-insensitive filename stems across image extensions, uses explicit physical units and rejects ambiguous/invalid rows before applying a lookup.

## Segmentation

Whole-image example retrieval is separate from Single object and Inside ROI only. Tests cover positive/negative points and rectangle/polygon/ellipse/circle examples, protected accepted masks, cached candidate reuse, cancellation and coalescing newer shapes during a running job. Point hides/disables ROI-only selection. A dedicated text Run button works without drawing, and automatic-grid selection starts inference and ignores text input.

Genuine SAM1 ViT-B and SAM2.1 Tiny tests each found **3 particles** in a four-particle synthetic image from one positive rectangle and one negative point. They verified matches outside the prompt, exclusion of the negative instance and actual pooled SAM features. These validate the implemented candidate/retrieval workflow, not universal microscopy concept accuracy. The SAM3 normalized positive/negative-box contract uses a test double; real SAM3 weights were not available.

After the complete run, two focused whole-image checks passed again after isolating candidate caches by model, including a newly loaded backend. Their separate evidence is v15_candidate_cache_recheck.xml.

Existing native single-object regressions now explicitly choose Single object. Their point/box inference, zoomed input, stale-result handling and accepted-mask protection remain tested. This is an intentional workflow change from the old whole-image label, not a claim that SAM1/2 natively implement SAM3 concepts.

## Processing and plugins

All ten restoration/smoothing/noise methods run on uint16 and float32 data. Tests verify shape/type, finite output and exact outside-target pixels. RGBA alpha and seeded-noise reproducibility are checked. Invalid kernels/parameters are rejected. Dialog defaults reset.

Retained crops preserve actual background in the bounding rectangle plus 3 pixels, protect those pixels during processing, paste back exactly, support Undo and survive native recovery. A pasted snapshot remains exportable after rotation; pasting it into changed coordinates is rejected.

Plugin tests install/register/run/remove local code, support relative helper modules, isolate registration failures, honor cancellation and reject wrong shapes/types/nonfinite output. The supplied TinyUNet is actually scripted with PyTorch, loaded through torch.jit.load and run with overlapping tiles on a non-tile-sized uint16 image. The checkpoint is untrained and only validates the interface; it does not establish denoising quality.

## Genuine assets

The complete run uses official SAM1 ViT-B and SAM2.1 Tiny weights, a genuine LaMa TorchScript checkpoint, pinned Grounding DINO Tiny assets and public DM3/DM4/EMD/TIFF fixtures. Checkpoint hashes and real-model results accompany the release. Text tests use a public vehicle image and do not establish nanoparticle detector accuracy. Manual/legacy objects without model scores remain distinct from model-derived confidence.

## Installed wheel

All **29 Python modules** match exactly between source, the built wheel and the installed package. Both PDF help resources also match. pip/uv dependency checking reported compatible packages. Imports and acceptance checks run outside the source directory:

- CPU installation self-test: native imports, PyTorch/torchvision operations, project/COCO recovery and Qt construction.
- Fresh SAM1 and SAM2.1 GUI processes: prompts before model loading, later live clicks, acceptance, autosave recovery and histogram paint/resize, with zero reported errors.
- Dedicated text button: alias sample vehicle -> truck, genuine Grounding DINO -> SAM2.1 inference, 1 accepted mask(s), 1466 heartbeat ticks during background work, immediate COCO notes, three vertical panels and native rendering of the 23-page bundled help PDF.

## Documents and package

The English User Manual is 23 pages and covers functions, examples, COCO defaults, image processing and all 32 metric definitions. For Developer is a separate 10-page PDF with API/source access and executable U-Net code. Both are rendered and visually inspected; native QPdfDocument rendering is tested. The source archive includes editable Markdown manuals, examples, templates, tests, a wheel, install/removal scripts and a Conda GPU guide. Models, environments and temporary private work are excluded.

## GPU and platform boundary

The validation machine reports **no NVIDIA GPU**. Hardware reports, runtime/architecture decisions, rejection paths and Conda command planning were tested using clearly synthetic GPU fixtures. Windows dependency metadata resolves, and optional Linux SAM3 dependencies resolve with a NumPy 1.26-compatible TIFF/codec set and PyTorch 2.7.1 constraints.

These are not native Windows execution, Conda installation on every machine, CUDA kernel tests or full SAM3 inference. Native Windows/macOS, Windows EXE construction, actual GPU execution, original SAM2 checkpoints, larger SAM variants and real SAM3 weights remain unverified. No prebuilt EXE or validated SAM3 CPU backend is supplied. Use the local GPU self-test and real checkpoint acceptance steps in GPU_CONDA_GUIDE.md.

## Reproduction

```text
python -m pip install -r requirements-dev.txt
python scripts/fetch_validation_assets.py --models --text --directory /local/validation_assets
python scripts/run_full_validation.py --assets /local/validation_assets --output validation/local_full_results.xml
```

The complete runner rejects missing external assets and skipped tests. Ordinary pytest without them can skip optional integrations. Defined regression scenarios cannot establish that every possible image, plugin or future dependency combination is defect-free.

## Evidence

- v15_full_results.xml, v15_features.xml and v15_full_results.models.json
- v15_examples_SAM1.json and v15_examples_SAM2_1.json
- installed_selftest_v15.json, installed_sam1_v15.json, installed_sam2_v15.json, installed_text_review_v15.json
- source_sha256_v15.json, installed_cpu_freeze_v15.txt and release_verification_v15.json
- gpu_detection_cpu.json, windows_dependency_resolution.txt and sam3_linux_dependency_resolution.txt
