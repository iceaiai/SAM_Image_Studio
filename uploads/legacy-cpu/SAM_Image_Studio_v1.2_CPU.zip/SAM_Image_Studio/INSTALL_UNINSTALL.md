# SAM Image Studio installation and removal

Release 1.2.0, October 15 2026

## Windows quick start

1. Extract the complete ZIP into a new writable folder.
2. If 64-bit Python 3.12 is missing, press the **Windows key** to open Start.
   Click the search box at the top, type **PowerShell**, and click
   **Windows PowerShell**. Administrator mode is not required.
3. Copy this command into PowerShell and press Enter:

```powershell
winget install --exact --id Python.Python.3.12 --architecture x64 --scope user --source winget
```

4. Close PowerShell and reopen it. Check the installed version:

```powershell
py -3.12 --version
```

5. Double-click **Install_CPU.bat** in the extracted folder. Wait until the
   installation self-test passes, then double-click **Start_GUI.bat**.

You can also double-click **Install_Python_3_12.bat** to run the same WinGet
command. Existing Python versions can stay installed. If WinGet is unavailable,
use the official Windows installer (64-bit) at
https://www.python.org/downloads/release/python-31210/ and keep Python Launcher
enabled. Reopen PowerShell after installation.

## Updating from earlier releases

Install this release in a new folder. Do not copy an old .venv into the new
release. Cached model weights remain in the application data folder and can be
reused without downloading again. Open the original images to restore their
existing SAM_Annotations projects. Version 1.2 reads projects from 1.0 and 1.1,
including legacy cleaned pixels. It saves native schema 2 and converts old
cleaning footprints into visible objects. Back up project JSON files if you need
to return to an earlier application, which cannot read the new schema.

In Segment mode, **Prompted object, whole image** is the default and uses your
points or shape to infer one object. **Inside ROI only** clips an area prompt.
Point-only prompts never become a one-pixel ROI. **Automatic grid, unannotated
only** is a separate explicit choice. Normal prompted inference accepts newer
point clicks while a preview is running and updates using the latest prompt set.

For vertices, choose Edit mode or press Ctrl+E, then drag an existing handle.
The Edit toolbar's Vertex radius and Edit > Vertex deletion radius set the same
image-pixel radius (default 20). Each Delete removes one nearest
remaining vertex in that radius, from the selected object only. No other object
is modified, regardless of radius. Handles are three times larger and mask
outlines twice as thick. Smooth Edges retains editable cubic curves.

Close polygons by clicking within 3 original image pixels of the start, or use
Enter/double-click. Hand moves the image; Reset magnification or F restores fit.

Clean mode adds Delete for cleaning to an object's right-click menu. Every
removed/filled region remains a visible object. Show cleaning regions toggles
display; deleting a cleaning object restores pixels while keeping other cleaning
edits. For patch fill, draw manual background regions in a dedicated group of
any name and explicitly choose that Background group.

Save masks retains binary grayscale and adds weighted grayscale at overlaps.
The mapping JSON records the equal gray contribution per object. PNG/TIFF can
make all non-object pixels transparent. Mask transparency independently controls
mask opacity or blending over either the original image or image after cleaning.
The formal manual describes COCO cleaning extensions and exact restoration.

## 中文快速安装

此包包含完整 GUI 源码和 Windows 批处理安装方式，默认 CPU，无需 NVIDIA 显卡。
需要 64 位 Python 3.12；本版固定依赖组合以优先保证可重复安装。
模型首次使用时下载，也可以选择与架构匹配的本地 .pt 或 .pth 文件。

1. 从 Python 官方网站 https://www.python.org/downloads/ 安装 64 位 Python 3.12，
   保留 Python Launcher。已有 Python 3.12 或 Conda 环境可直接使用。
2. 完整解压到可写目录，例如 C:\Tools\SAM_Image_Studio，不要直接在 ZIP 中运行。
3. 双击 Install_CPU.bat。脚本创建本目录的 .venv，安装 CPU PyTorch 和依赖，
   然后运行实际导入、Qt 窗口、自动保存和 COCO 自检。失败时会停止并显示错误。
4. 成功后双击 Start_GUI.bat。以后启动不需要重复安装。
5. File > Open images，选择 examples 文件夹内的 synthetic_particles.ome.tif。
6. Load model > SAM2.1 > Tiny > CPU。留空本地权重路径即可下载官方模型。
7. 选择 Segment，用 Point 左键点击颗粒，查看预览后 Accept masks。

需要联网安装依赖和首次下载模型。CPU 推理速度取决于机器和图像尺寸。
建议至少 16 GB 内存、6 GB 可用磁盘。大模型和大堆栈需要更多内存。
关闭模型任务后再退出，Cancel 会在当前模型调用完成后停止。

本次真实测试环境是 Linux x86-64 和 CPU。Windows 批处理及依赖已检查，
但未在原生 Windows 上运行验收；包内没有已构建、已验证的 Windows EXE。
Build_Windows_Portable.bat 提供原生 Windows 构建入口。

## Windows source installation

Supported release runtime: 64-bit CPython 3.12. Use a writable extracted directory.
The batch installer prefers the Python Launcher command py -3.12 and falls back
to a compatible python command. It never requires administrator rights.

Equivalent terminal commands from the release folder:

    py -3.12 scripts\install_environment.py --backend cpu
    .venv\Scripts\python.exe -m samstudio

The installer pins the application libraries and installs PyTorch 2.7.1 /
torchvision 0.22.1 from the CPU wheel index. It verifies the bundled SAM2 backend,
installs the application, runs pip check and performs a basic installation self-test.
This basic self-test does not download any model.

Do not move or rename the application folder after installing its virtual
environment. If moving it, uninstall the environment, move the source folder,
then rerun installation. Keep image projects when doing so.

## Linux installation

Use Python 3.12 and the system desktop libraries required by Qt.
For example, Ubuntu/Debian machines may need libgl1, libegl1, libxkbcommon-x11-0
and libxcb-cursor0. Install these through the system package manager if Qt reports
a missing platform library.

    bash install_cpu.sh
    bash start_gui.sh

If python3 is another version, use:

    python3.12 scripts/install_environment.py --backend cpu
    .venv/bin/python -m samstudio

The CPU runtime and offscreen Qt workflows were tested on Linux. An interactive
desktop session, window manager and display scaling should still receive a local
acceptance check. macOS launch scripts are supplied but macOS was not tested.

## Python and Anaconda

Create the environment using the supplied environment definition:

    conda env create -f environment-cpu.yml
    conda activate sam-image-studio
    python scripts/install_environment.py --current --backend cpu
    python -m samstudio

Alternatively create a Python 3.12 virtual environment yourself, activate it,
then run the same --current command. The installer rejects --current in a bare
system interpreter. Conda's environment solver itself was not exercised here.

For controlled updates, copy the release and environment definition first.
Update dependency pins in a separate environment, run the test suite and real SAM
self-tests, then use that environment. Keep the verified installation for rollback.
Avoid an unreviewed bulk upgrade in the only working environment.

## Model installation and local weights

CPU starting choices:

| Model | Default tested checkpoint | Approximate download |
| --- | --- | --- |
| SAM1 ViT-B | sam_vit_b_01ec64.pth | 358 MiB |
| SAM2.1 Tiny | sam2.1_hiera_tiny.pt | 149 MiB |
| LaMa | big-lama.pt | 197 MiB |

Use Models > Model manager to select a family, exact architecture and CPU/CUDA.
Empty checkpoint field downloads the catalog entry into the application data
folder. A local .pt or .pth must contain that model architecture's compatible
weights. Renaming an unrelated .pt file does not convert it into SAM.

SAM1/ViT-B, SAM2.1/Tiny and LaMa downloads use recorded SHA256 checksums.
Other catalog checkpoints have completed-download checks but no independently
pinned digest in this release. An incompatible load reports an error and retains
the previously loaded model.

Files ending in .part are incomplete downloads. Retry resumes them. A checksum
failure discards the partial file. If a cached file fails its checksum, remove that
single cached checkpoint and retry, or choose a valid local file.

Real model installation check on Windows:

    .venv\Scripts\python.exe -m samstudio.selftest --model sam2 --report sam2_check.json

On Linux:

    .venv/bin/python -m samstudio.selftest --model sam2 --report sam2_check.json

Use --model sam1 for SAM1. Add --checkpoint /path/to/model.pt to use a local file.
The model check actually loads weights and produces a nonempty segmentation mask.
Without --image, it uses a synthetic particle. It reports a failure with a nonzero
exit code if inference cannot run.

## Optional NVIDIA environment

Keep the verified CPU environment intact. With Python 3.12 and a compatible
NVIDIA driver installed:

    py -3.12 scripts\install_environment.py --backend cuda
    Start_GUI_GPU.bat

Linux equivalent:

    python3.12 scripts/install_environment.py --backend cuda
    .venv-gpu/bin/python -m samstudio

This creates .venv-gpu and uses PyTorch's CUDA 12.6 wheels. GPU execution was not
verified on the build machine. Run the self-test with --device cuda and then a
real checkpoint check before using that environment.

## Optional experimental SAM3

The adapter targets the original SAM3 image model and sam3.pt. It supports the
native interactive predictor and optional text prompts. The default CPU install
does not install SAM3. SAM3 is disabled for CPU in this release.

Use a separate Linux/WSL environment with NVIDIA CUDA. The upstream project
currently documents Python 3.12+, PyTorch 2.7+ and CUDA 12.6+, with its current
installation example using PyTorch 2.10.0 and CUDA 12.8 wheels.
The optional requirements use a pinned upstream commit and NumPy 1.26 because
SAM3 currently declares NumPy <2. They are intentionally separate from the
verified CPU lock file.

From a newly activated Python 3.12 Conda/virtual environment, with Git available:

    python -m pip install torch==2.10.0 torchvision==0.25.0 --index-url https://download.pytorch.org/whl/cu128
    python -m pip install --find-links vendor -r requirements-sam3-experimental.txt
    python -m pip install --no-deps vendor/sam_2-1.0-py3-none-any.whl
    python -m pip install --no-deps .
    python -m pip check
    python -m samstudio.selftest --device cuda
    python -m samstudio

Obtain approved checkpoint access at https://huggingface.co/facebook/sam3 and
authenticate with the Hugging Face CLI, or select an authorized local sam3.pt.
Real SAM3 loading, inference and this optional environment were not verified
without the required hardware and checkpoint access. Treat SAM3 as experimental
until those checks pass locally. SAM3.1 video tracking is outside this release.

## Native portable Windows executable

On a native 64-bit Windows machine, after a successful CPU installation:

    Build_Windows_Portable.bat

The recipe uses PyInstaller to produce an onedir portable package:

    dist\SAM_Image_Studio\SAM_Image_Studio.exe

Copy the entire dist\SAM_Image_Studio folder, including its _internal directory.
The target machine then needs no Python installation. Models still download on
demand into the user's application data folder. This is a build recipe, not a
claim that an EXE was built or tested in the supplied Linux environment.

Before distributing the built EXE, run it on a clean Windows account and check:
open a PNG/TIFF and stack, load real SAM1 and SAM2.1 CPU weights, preview/accept
an object, close/reopen, edit vertices, fill/smooth, export COCO/PNG/TIFF/BMP,
plot statistics and inspect display scaling. Retain dependency license notices.

## Uninstall and preserve work

Close the GUI first. Double-click Uninstall.bat or run:

    py -3.12 scripts\uninstall_environment.py

Linux:

    bash uninstall.sh

The uninstaller removes only this release's marked .venv/.venv-gpu and marked
build/dist folders. It preserves source images, SAM_Annotations, exported data,
cached model weights and user settings. It refuses to delete unmarked folders.
Back up projects before manually deleting the extracted release directory.

For Conda:

    conda deactivate
    conda env remove -n sam-image-studio

Application data locations:

| Platform | Default data folder |
| --- | --- |
| Windows | %LOCALAPPDATA%\SAMImageStudio |
| Linux/macOS | ~/.local/share/sam-image-studio |

The folder contains models, settings.ini and samstudio.log. It can also contain
fallback projects if the image folder was not writable. Back up any projects
before removing this folder. SAM_STUDIO_DATA_DIR overrides this location.
The normal autosave folder is SAM_Annotations beside the source images, or the
folder chosen in File > Choose project folder.

## Troubleshooting

- Installation fails: retain the terminal error, check network/proxy/Python version,
  and rerun the installer. It preserves existing projects and resumes package installation.
- Qt platform plugin error: check required desktop libraries and launch from the
  supplied environment. Avoid mixing PyQt and PySide packages in that environment.
- Model cannot load: confirm exact family/variant and complete checkpoint. Try
  SAM2.1 Tiny on CPU. Failed loading keeps the previous usable model.
- Empty automatic-grid output: lower the confidence/minimum-area threshold or use
  positive points in Prompted object mode. Automatic sampling can miss small objects.
- The first CPU preview may take several seconds to compute its embedding. The GUI
  accepts additional prompt clicks during prompted inference and coalesces them.
  Use Cancel to stop after the current model operation. Model loading is a separate
  operation and does not accept image edits until it finishes.
- No visible changes after Accept: protected accepted pixels remain unchanged.
  To edit an existing mask use its explicit Refine selected object action.
- Autosave failure: choose a writable project folder. Unsaved changes stay in
  memory, and closing/image switching is blocked if they cannot be saved.
- Pixel size unavailable: use Statistics > Edit image calibration. TIFF print DPI,
  undefined units and nonuniform axes are not guessed as microscopy calibration.
- Report a reproducible issue with the error text, log, diagnostics versions,
  image format, steps and a non-sensitive sample if available.
