# SAM Image Studio 1.2.0 test report

**212 passed, 0 failed, 0 errors, 0 skipped.** The final complete run took 85.24 seconds on Linux x86-64, CPython 3.12.14, PySide6 6.8.3 and PyTorch 2.7.1+cpu. This is scenario validation, not a guarantee for every image or operating system.

## Requested behavior and evidence

| Requested behavior | Validation |
| --- | --- |
| Weighted grayscale and original binary output | Exact 1/2/3/4-object sums, BMP/PNG/TIFF pixels, per-object scaling and recorded weight mappings. Binary union remains 255. |
| Polygon closure | Native Qt clicks close within 3 image pixels at 0.5×, 1×, 2× and 12×. A click outside the radius leaves the polygon open. |
| A selected background group of any name | Manual group selection, arbitrary names and irregular-source filling. Pixels outside the selected ellipse never contaminate a fill. SAM objects are not eligible manual sources. |
| Hand and Reset | Native Qt drag changes the offset; Reset restores the exact default fit scale. |
| Zoomed point input | Manual/Segment clicks at 2×, 10× and 50× stay points. Real SAM1 and SAM2.1 at 40× match native predictor output and recover accepted masks as cleaning objects. |
| Edit mode, larger vertices and radius | Edit is a separate mode. Radius is user-set, image-based and visible only after Qt completes Edit layout. Handles are 3× larger; outline width is doubled. Existing move/delete regressions retain handle count and selected-object isolation. |
| Readable selected menu options | Qt delegate exposes a trailing check only for the selected row, while currentText/currentData stay unchanged. Actual GUI screenshots were inspected. |
| Transparent background and mask opacity | All outside-object pixels are zero-alpha for binary, weighted, group-color and object-color renders with either overlay source. PNG alpha is decoded from the saved file. Cleaned source is rejected before cleaning exists. |
| Object context cleaning | Actual Qt context menus expose Delete for cleaning only in Clean mode. Converted objects retain identity, remain visible and can be hidden or deleted to restore pixels. Cleaning regions cannot be refined as foreground masks. |
| Cleaning objects, undo and recovery | Overlapping removals/fills replay deterministically. Deleting one leaves other edits applied. Partial/all restoration, exact undo/redo, locked regions, old-project migration and corrupt-state rejection are tested. |
| JSON and COCO | Native schema 2 preserves cleaning objects and restores schema 1 projects. COCO separate cleaning records retain exact RLE, methods, original dtype/pixels and restoration history. Background/cleaning regions stay outside standard training annotations and measurements. |
| Larger undo/redo buttons | Qt checks 44-pixel icons and 72-pixel click targets. |
| Earlier crash regressions | Four fresh GUI processes exercise native CPU initialization, preexisting points, subsequent live clicks, inference, acceptance, recovery, histogram painting and resizing with real weights. |

## Genuine checkpoints

| Model | SHA256 | Observed checks |
| --- | --- | --- |
| SAM1 ViT-B | `ec2df62732614e57411cdcf32a23ffdf28910380d03139ee0f4fcbe91eb8c912` | Real native point/box masks; point area 2367; ROI clipping; protected pixels; grid; failed-load rollback; Qt acceptance and 40× point/cleaning recovery. |
| SAM2.1 Tiny | `7402e0d864fa82708a20fbd15bc84245c2f26dff0eb43a4b5b93452deb34be69` | Real native point/box masks; point area 2488; ROI clipping; protected pixels; grid; failed-load rollback; Qt acceptance and 40× point/cleaning recovery. |
| LaMa TorchScript | `7ba7aa7ac37a4d41fdbbeba3a2af7ead18058552997e3a3cd1a3b2210c9e6b4c` | Actual estimated fill pixels. Every outside-target pixel stayed exact. |

Model scores are predictions, not measured segmentation accuracy. Timings depend on this machine and caching.

## Test modules

| Module | Passed cases |
| --- | ---: |
| test_core | 27 |
| test_exports_io | 40 |
| test_extra_regressions | 8 |
| test_gui | 18 |
| test_gui_fill_and_export | 5 |
| test_install_safety | 3 |
| test_microscopy_readers | 5 |
| test_real_models | 19 |
| test_recovery_download | 8 |
| test_v11_regressions | 28 |
| test_v12_regressions | 51 |

## Packaged application checks

The 1.2.0 wheel's Python files match the tested source byte for byte. After installing the wheel, its installation self-test passed from a separate directory. Two additional fresh processes loaded real SAM1 and SAM2.1 from the installed package, added points, accepted a mask, restored autosave and painted/resized the histogram. Neither process preimported PyTorch. Both completed with no captured GUI errors. These checks are additional to the 212 pytest cases.

The formal manual was rendered and inspected page by page. The editable 20-slide PPT was rendered and inspected; its native tables, chart and original embedded chart workbook passed structural checks. PowerPoint desktop opening was not performed.

## Reproduce

From the installed CPU environment in the release folder:

```text
python -m pip install -r requirements-dev.txt
python scripts/fetch_validation_assets.py --models --directory validation_assets
python scripts/run_full_validation.py --assets validation_assets --output validation/local_full_results.xml
```

The runner rejects missing assets and any skipped tests. The release omits model weights and external reader fixtures; the downloader retrieves genuine public files with recorded digests.

Evidence: validation/v12_full_results.xml, validation/v12_full_results.models.json, validation/release_verification_v12.json and validation/installed_wheel_*.json. Source paths in captured evidence describe the validation workspace.

## Limits

Native Windows desktop/EXE, macOS, NVIDIA CUDA, SAM3 real weights, original SAM2 checkpoints and larger model variants were not executed. Windows batch/portable build procedures are supplied; no prebuilt Windows EXE is included. The inherited dependency pins are unchanged.

One pycocotools/NumPy deprecation warning appeared in the complete run. It did not affect exact mask decoding or test completion.
