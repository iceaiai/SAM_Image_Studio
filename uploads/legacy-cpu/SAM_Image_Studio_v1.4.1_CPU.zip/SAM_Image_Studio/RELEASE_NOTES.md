# SAM Image Studio 1.4.1

## Base and scope

Rebuilt from the original 1.4.0 archive, not from the expanded 1.5 workflow.
The v1.4 annotation model, properties dialogs, Objects/Groups/Image files
panels and COCO export remain. This release implements only the corrected
feature list plus the integration fixes needed to make it work.

## Requested changes

- Whole-image exemplar search accepts multiple positive/negative points,
  rectangles, polygons, circles and ellipses before acceptance. Live preview
  coalesces newer prompts and protects accepted annotations. SAM1/2 use an
  application candidate/retrieval layer; SAM3 uses native concept prompts.
- Single object preserves native one-object SAM behavior. Point hides ROI-only.
- Text has a visible Run button and Enter shortcut. Aliases remain available.
- Automatic grid starts from selection/model readiness and ignores text input.
- Image-list removal saves native projects. Startup offers Yes/No reopening.
- Processing provides configurable TV Chambolle/Bregman, sparse wavelet, NLM,
  bilateral, median, Gaussian smoothing and Gaussian/Poisson/impulse noise.
  Parameter defaults reset; spatial/alpha/type integrity and Undo are retained.
- Crops store real pixels from a mask bounding rectangle plus 3 pixels of
  context. Protect them during processing, export them or paste them back.
- Plugin API v1 registers local processors and GUI actions. The separate
  developer manual includes source access and a real tiled TorchScript U-Net
  interface example. No trained denoising weights are supplied.
- In-app English PDF help covers the user functions and examples.
- NVIDIA detection generates dedicated Conda installation commands. GPU
  execution outside Conda is rejected. Optional native SAM3 targets Linux/WSL2;
  an unverified SAM3 CPU backend is not enabled.

## Recovery and compatibility

Native schema 5 adds only exemplar/crop state to this v1.4-based workflow and
reads schemas 1-4. COCO dataset export retains its v1.4 representation. Native
projects from the separate expanded 1.5 COCO-review workflow are not a migration
target for this rollback release; keep the matching original application and
projects together. Source v1.4 projects continue to load.

The release keeps a machine-readable comparison against the original archive.
See TEST_REPORT.md for actual model tests, installed-package checks and limits.
