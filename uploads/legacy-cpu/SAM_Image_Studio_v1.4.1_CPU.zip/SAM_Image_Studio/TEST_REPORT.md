# SAM Image Studio 1.4.1 - validation report

Date: October 22, 2026

## Result and corrected scope

The final complete run passed **403 tests**, including **72 new-feature cases**, with **0 failures, 0 errors and 0 skips**, in 197.469 seconds. The feature XML is a subset of that same complete run, not another independent run.

The code was restored from the original 1.4.0 archive and the corrected feature list was applied. The baseline archive digest, per-module comparison and application patch are included. Of 28 application modules, 11 remain byte-identical to 1.4.0, 8 are modified for the requested workflows/runtime verification and 9 are added. The COCO export module is byte-identical to v1.4.0. The v1.4 Objects/Groups/Image files panels and existing property/native-annotation workflow are retained. The expanded COCO editor, ID normalization, review-attribute templates and Excel lookup from the separate 1.5 workflow are not included.

## Environment and test inventory

Linux x86-64; Python 3.12.14; PySide6 6.8.3 with the Qt offscreen platform; PyTorch 2.7.1+cpu and torchvision 0.22.1+cpu. NumPy 2.3.5, SciPy 1.17.0, scikit-image 0.26.0, Transformers 4.53.3 and PyWavelets 1.10.0. Complete installed versions are recorded in installed_cpu_freeze_v141.txt.

| Module | Passed |
| --- | ---: |
| test_core | 27 |
| test_exports_io | 40 |
| test_extra_regressions | 8 |
| test_gui | 18 |
| test_gui_fill_and_export | 5 |
| test_install_safety | 3 |
| test_microscopy_readers | 5 |
| test_real_models | 28 |
| test_recovery_download | 8 |
| test_v11_regressions | 28 |
| test_v12_regressions | 51 |
| test_v13_features | 52 |
| test_v141_processing_workspace | 38 |
| test_v141_segmentation_plugins_gpu | 34 |
| test_v14_features | 58 |
| **Total** | **403** |

One NumPy deprecation warning originates in pycocotools. Exact RLE and mask round-trip checks pass.

## Segmentation and existing v1.4 behavior

Whole-image example retrieval accepts multiple positive/negative points, rectangles, circles, ellipses and polygons. Tests verify matches outside a positive prompt, negative-instance exclusion, accepted-mask protection, cached candidates isolated by loaded predictor, cancellation, autosaved examples and newer shapes arriving during a running job.

Actual SAM1 ViT-B and SAM2.1 Tiny checkpoints each retrieve three particles from a four-particle synthetic image with one positive rectangle and one negative point. Actual pooled SAM features are checked. SAM1/2 use an application candidate/retrieval layer; these tests do not establish universal microscopy concept accuracy. The SAM3 normalized geometric-prompt contract uses a test double, not real SAM3 weights.

Point hides/disables ROI-only and can switch a selected ROI-only scope to native Single object. Dedicated text Run works without drawing. Automatic grid starts when selected/ready and ignores text. Existing native single-object regression cases explicitly select Single object. Genuine baseline tests also exercise SAM, LaMa, Grounding DINO, microscopy readers, cleaning, editing, rotation, statistics, masks, overlays, savepoints and exact native/COCO recovery.

## Processing, retained crops and plugins

All ten restoration/smoothing/noise methods run on uint16 and float32 data. Region shape/type, finite results, exact outside-target pixels, RGBA alpha, seeded noise, invalid parameters and default reset behavior are checked. GUI integration constructs the actual preview dialog and tests Apply/Cancel and Undo.

Retained crops store real image pixels in a mask bounding rectangle plus 3 pixels, protect the rectangle during later processing, paste back exactly and survive native recovery. Pasted snapshots remain exportable after rotation; repasting into changed coordinates is rejected.

Plugin tests install/register/run/remove local code, support relative helpers, reject malformed output, isolate registration failures and honor cancellation. The real TinyUNet architecture is scripted, loaded with torch.jit.load and tiled over a non-tile-sized uint16 image. The example uses an **untrained interface checkpoint**, not validated scientific denoising weights. Plugin worker-to-preview-to-Apply and Undo are tested in the GUI.

Workspace removal preserves source images and saved native annotations. Removing another image keeps the active document. Startup Yes/No behavior is checked; an installed native window with No remains empty. A scope-retention test checks the v1.4 panels/data/export contract and native schema-4 recovery.

## Installed-package acceptance

All **28 application modules** and both help PDF resources match source, wheel and installed package exactly. Dependency checking reports 78 compatible packages. The following checks import from site-packages outside the source directory:

- Installation self-test: core/microscopy imports, matrix arithmetic and native NMS on CPU, exact project/RLE recovery and Qt window construction.
- Fresh SAM1 and SAM2.1 GUI processes: prompts before model loading, later live clicks, one accepted object each, native recovery and histogram paint/resize, with zero reported errors.
- Extended native GUI: actual SAM2.1 whole-image retrieval with 3 masks and a negative exclusion; dedicated text button with sample vehicle -> truck and 3 real Grounding DINO/SAM masks; Gaussian preview/Apply/Undo; actual tiled U-Net plugin preview/Apply/Undo; protected crop/paste/native recovery; bundled PDF rendering at 20 and 12 pages; saved projects after image-list removal; actual startup No. The UI heartbeat fired 1805 times during background work and errors were empty.

## Documents and packaging

The English User Manual has **20 pages** with function explanations and examples. The separate **12-page For Developer** guide includes the plugin contract, source/function access, full U-Net code and tests. All 32 pages were rendered and visually inspected. Code quotes and glyphs were checked, and both PDFs render through native Qt PDF help. Editable Markdown manuals, examples, tests, an installable wheel and installation/removal scripts accompany the source archive. Environments and model weights are excluded.

## Conda GPU setup and limits

The machine has no NVIDIA GPU. Device/driver/architecture selection and dedicated Conda command planning are tested with explicit synthetic reports. The GPU install self-test now runs a matrix product and torchvision NMS on CUDA and synchronizes the device when run on supported local hardware; outside-Conda and unavailable-device failures are covered here. This CPU validation does **not** execute those CUDA kernels.

Windows application dependency metadata resolves. The optional Linux SAM3 graph also resolves with PyTorch 2.7.1 / torchvision 0.22.1 constraints and a NumPy 1.26-compatible TIFF/codec set. The Windows build recipe evaluates with real collection helpers and includes both PDFs, but no Windows EXE is built here.

Native Windows/macOS, actual Conda creation/CUDA kernels, real SAM3 weights, original SAM2 and larger SAM variants remain unverified. No prebuilt EXE or verified SAM3 CPU backend is supplied. Follow GPU_CONDA_GUIDE.md for the automatic NVIDIA inspection/Conda setup and run local real-model acceptance on the target hardware.

## Reproduce

```text
python -m pip install -r requirements-dev.txt
python scripts/fetch_validation_assets.py --models --text --directory /local/validation_assets
python scripts/run_full_validation.py --assets /local/validation_assets --output validation/local_full_results.xml
```

The complete runner rejects missing assets and skipped tests. A plain pytest run without assets can skip optional integrations. Defined scenarios do not establish that all images, plugins, hardware or future package versions are defect-free.

## Evidence

- v141_full_results.xml, v141_features.xml, v141_full_results.models.json
- v14_baseline_comparison.json and v14_to_v141.patch
- installed_selftest_v141.json, installed_sam1_v141.json, installed_sam2_v141.json, installed_extended_v141.json
- source_sha256_v141.json, verified_checkpoint_sha256_v141.json, installed_cpu_freeze_v141.txt
- gpu_detection_cpu.json, windows_dependency_resolution.txt, sam3_linux_dependency_resolution.txt, windows_recipe_check_v141.json
- release_verification_v141.json and MANIFEST.sha256
