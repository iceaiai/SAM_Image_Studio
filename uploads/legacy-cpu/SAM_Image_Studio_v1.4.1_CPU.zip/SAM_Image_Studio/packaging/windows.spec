# Native Windows CPU build recipe. Run Build_Windows_Portable.bat on Windows.
# A successful build still requires the acceptance checks in INSTALL_UNINSTALL.md.
# Spec format and collection helpers: https://pyinstaller.org/en/stable/spec-files.html
from pathlib import Path

from PyInstaller.utils.hooks import collect_data_files, collect_submodules, copy_metadata

root = Path(SPECPATH).resolve().parent
datas = [(str(root / "third_party"), "third_party"), (str(root / "LICENSE"), ".")]
hidden = ["matplotlib.backends.backend_qtagg", "PySide6.QtSvg", "PySide6.QtPdf", "PySide6.QtPdfWidgets"]
datas += collect_data_files("samstudio", includes=["resources/*.pdf"])

# SAM2 uses Hydra YAML configuration and dynamically named model classes.
for package in ("sam2", "segment_anything"):
    datas += collect_data_files(package, include_py_files=True)
    hidden += collect_submodules(package)

# Readers and Transformers select these modules lazily at runtime.
for package in (
    "rsciio.digitalmicrograph", "rsciio.emd",
    "transformers.models.grounding_dino", "transformers.models.bert",
):
    hidden += collect_submodules(package)
for package in ("rsciio", "transformers"):
    datas += collect_data_files(package, include_py_files=True)
for distribution in (
    "transformers", "huggingface-hub", "tokenizers", "safetensors",
    "rosettasciio", "torch", "torchvision", "sam_2", "segment-anything",
):
    datas += copy_metadata(distribution, recursive=True)

a = Analysis(
    [str(root / "launch.py")],
    pathex=[str(root)],
    binaries=[],
    datas=datas,
    hiddenimports=sorted(set(hidden)),
    hookspath=[],
    hooksconfig={"matplotlib": {"backends": ["QtAgg"]}},
    runtime_hooks=[],
    excludes=["PyQt5", "PyQt6", "PySide2", "tensorflow", "sam3"],
    noarchive=False,
)
pyz = PYZ(a.pure)
exe = EXE(
    pyz, a.scripts, [], exclude_binaries=True,
    name="SAM_Image_Studio", debug=False, bootloader_ignore_signals=False,
    strip=False, upx=False, console=False,
)
coll = COLLECT(
    exe, a.binaries, a.datas,
    strip=False, upx=False, name="SAM_Image_Studio",
)
