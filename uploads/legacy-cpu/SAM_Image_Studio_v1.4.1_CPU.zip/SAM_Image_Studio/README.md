# SAM Image Studio 1.4.1

This release starts from the original 1.4.0 code and adds the corrected feature
list: whole-image positive/negative exemplar segmentation, a dedicated text Run
button, automatic-grid dispatch, workspace removal/startup confirmation, image
processing, local plugins, English PDF help and Conda-only NVIDIA setup.

The v1.4 Objects/Groups/Image files layout, annotation properties, native
saving and COCO export behavior are retained. See RELEASE_NOTES.md for scope
and TEST_REPORT.md for measured results and platform boundaries.

## Install and start

Use 64-bit Python 3.12. On Windows, extract the complete archive to a writable
folder, run Install_CPU.bat and then Start_GUI.bat. If needed,
Install_Python_3_12.bat installs the per-user Python version. On Linux,
run bash install_cpu.sh, then bash start_gui.sh.

GPU execution uses a dedicated Conda environment. Install_GPU_Conda.bat or
scripts/install_conda_gpu.py detects NVIDIA devices and chooses the runtime
from driver capability and GPU architecture. Read GPU_CONDA_GUIDE.md.
SAM3 CPU is not enabled; the optional native SAM3 recipe targets Linux/WSL2
Conda and authorized checkpoints. Model weights are downloaded separately.

## Use

1. Open one or more images and load SAM2.1 Tiny or SAM1 ViT-B on CPU.
2. Create a group, switch to Segment and choose Prompt project, whole image.
3. Mark a positive point/shape and add negative examples. Inspect the live
   preview across the image, then Accept masks. Choose Single object for
   native one-object prompting, or use an area shape for Inside ROI only.
4. Use Run text segmentation for a phrase/alias, or select Automatic grid,
   unannotated only to start a grid search with a loaded model.
5. Processing contains TV/sparse/NLM/bilateral/median denoising, Gaussian
   smoothing, retained real-background crops and adjustable synthetic noise.
   Every image change has Preview/Apply and Undo.
6. Remove selected images in the lower-right list to save native annotations
   and close those entries. Startup asks before reopening prior images.
7. Help opens the User Manual PDF. Plugin opens local processors/actions and
   the separate For Developer PDF with a working TorchScript U-Net example.

The v1.4 manual/edit/clean tools, inversion, rotation/padding, mask scaling
savepoints, smooth curves, 20-color LUT, transparent/weighted masks, overlays,
calibrated statistics and reversible cleaning remain available. Microscopy
readers retain supported physical metadata; missing calibration stays explicit.

## Files and validation

- docs/USER_MANUAL.md and docs/SAM_Image_Studio_User_Manual.pdf
- docs/FOR_DEVELOPER.md and docs/SAM_Image_Studio_For_Developer.pdf
- INSTALL_UNINSTALL.md and GPU_CONDA_GUIDE.md
- samstudio/: complete editable application source
- examples/plugins/unet_denoiser/: API v1 example and interface-test model
- tests/ and validation/: regression scenarios and release evidence
- dist/: installable wheel; scripts/ and packaging/: installers/build recipe

Keep native .sam.json projects for full editing/recovery. Exact COCO RLE masks
and cleaning extensions are available through Export. Images, projects and
model caches survive workspace removal and environment uninstall.

The full validation runner requires genuine model/reader assets and rejects
skipped tests. Follow For Developer for reproducible commands. Native Windows,
CUDA hardware and actual SAM3 weights require local acceptance if not recorded
as exercised in TEST_REPORT.md. No prebuilt EXE or model weights are bundled.
