from __future__ import annotations
import copy
from pathlib import Path
import numpy as np
from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QDialog,QVBoxLayout,QFormLayout,QComboBox,QCheckBox,QSpinBox,QDoubleSpinBox,
    QPushButton,QDialogButtonBox,QLabel,QInputDialog,QFileDialog,QLineEdit,QListWidget,QHBoxLayout,QMessageBox)
from .image_processing import METHODS,parameters,process_pixels,processing_target,apply_processing,retain_crop,paste_crop
from .dialogs import ImagePreviewDialog
from .domain import unpack_array

class ProcessingDialog(QDialog):
    def __init__(self,methods,parent=None,plugin_specs=None):
        super().__init__(parent);self.setWindowTitle('Image processing');self.resize(510,430);self.specs=plugin_specs or {};self.controls={}
        layout=QVBoxLayout(self);self.method=QComboBox();self.method.addItems(methods);layout.addWidget(self.method)
        self.form=QFormLayout();layout.addLayout(self.form)
        self.selection=QCheckBox('Process selected region / object masks only');layout.addWidget(self.selection)
        self.original=QCheckBox('Use original uncleaned pixels (current orientation)');layout.addWidget(self.original)
        note=QLabel('Parameters reset to defaults whenever this dialog opens or its method changes. Retained protected crop rectangles are excluded. Preview does not change the image.');note.setWordWrap(True);layout.addWidget(note)
        self.buttons=QDialogButtonBox(QDialogButtonBox.StandardButton.Ok|QDialogButtonBox.StandardButton.Cancel);self.buttons.button(QDialogButtonBox.StandardButton.Ok).setText('Preview');layout.addWidget(self.buttons);self.buttons.accepted.connect(self.accept);self.buttons.rejected.connect(self.reject)
        self.method.currentTextChanged.connect(self.reset_controls);self.reset_controls()
    def reset_controls(self,*a):
        while self.form.rowCount():self.form.removeRow(0)
        self.controls={};spec=METHODS.get(self.method.currentText(),self.specs.get(self.method.currentText(),{}))
        for key,definition in spec.items():
            if isinstance(definition,dict):default=definition.get('default','');low=definition.get('min',0);high=definition.get('max',1000000);step=definition.get('step',1)
            else:default,low,high,step=definition
            if isinstance(default,bool):control=QCheckBox();control.setChecked(default)
            elif isinstance(default,int):control=QSpinBox();control.setRange(int(low),int(high));control.setSingleStep(int(step));control.setValue(default)
            elif isinstance(default,float):control=QDoubleSpinBox();control.setDecimals(6);control.setRange(float(low),float(high));control.setSingleStep(float(step));control.setValue(default)
            else:control=QLineEdit(str(default))
            self.controls[key]=control;self.form.addRow(key.replace('_',' ').capitalize(),control)
    def values(self):
        return {k:w.isChecked() if isinstance(w,QCheckBox) else w.text() if isinstance(w,QLineEdit) else w.value() for k,w in self.controls.items()}

class ProcessingWorkflowMixin:
    def _init_processing_ui(self):
        menu=self.menuBar().addMenu('Processing');self.processing_menu=menu
        menu.addAction(self._action('Denoise…',lambda:self.process_image_dialog(list(METHODS)[:6])))
        menu.addAction(self._action('Smooth (Gaussian)…',lambda:self.process_image_dialog(['Gaussian smooth'])))
        menu.addAction(self._action('Crop selected region / masks…',self.crop_region_dialog));menu.addAction(self._action('Retained crops / paste back…',self.retained_crops_dialog))
        menu.addAction(self._action('Add noise…',lambda:self.process_image_dialog(['Poisson noise','Gaussian noise','Salt and pepper noise'])))
    def process_image_dialog(self,methods=None):
        if self.busy or not self.document:return
        methods=methods or list(METHODS)
        dialog=ProcessingDialog(methods,self)
        if dialog.exec()!=QDialog.DialogCode.Accepted:return
        doc=self.document
        try:
            method=dialog.method.currentText();params=parameters(method,dialog.values());region=self._processing_selection() if dialog.selection.isChecked() else None
            target=processing_target(doc,region)
            raw=(doc.frame.raw if dialog.original.isChecked() or doc.working is None else doc.working).copy()
            key=self.current_key;revision=doc.revision
            def finished(result):
                if key!=self.current_key or doc.revision!=revision:raise ValueError('The image changed during processing; run preview again.')
                preview=ImagePreviewDialog(raw,result,'Preview '+method,self)
                if preview.exec()==QDialog.DialogCode.Accepted:
                    self._commit(method,lambda:apply_processing(doc,result,target,method,params));self.cleaned_checkbox.setChecked(True)
            self._start_job('Processing image…',lambda progress,cancel:process_pixels(raw,method,params,target,progress,cancel),finished)
        except Exception as e:self.notify('Image processing',str(e))
    def _processing_selection(self):
        roi=self._selection_mask()
        if roi is not None and roi.any():return roi
        target=np.zeros(self.document.frame.shape,bool)
        for obj in self.selected_objects():
            if obj.mask is not None:target|=obj.mask
        if not target.any():raise ValueError('Select area objects or draw an area region.')
        return target
    def crop_region_dialog(self):
        if not self.document or self.busy:return
        try:
            region=self._processing_selection();name,ok=QInputDialog.getText(self,'Retain cropped pixels','Crop name (bounding box includes 3 pixels of real neighboring image)')
            if not ok:return
            self._commit('Retain crop',lambda:retain_crop(self.document,region,name or None,True,3))
            self.statusBar().showMessage('Crop retained and protected. Process the remaining image, then use Retained crops / paste back.',15000)
        except Exception as e:self.notify('Crop',str(e))
    def retained_crops_dialog(self):
        if not self.document or self.busy:return
        doc=self.document;dialog=QDialog(self);dialog.setWindowTitle('Retained crops');dialog.resize(620,420);layout=QVBoxLayout(dialog);items=QListWidget();layout.addWidget(items)
        def reload():
            items.clear()
            for c in doc.detached_crops:items.addItem(c['name']+' | '+str(c['bbox'])+' | '+('pasted' if c.get('pasted') else 'protected' if c.get('protected') else 'unprotected'))
        reload();only=QCheckBox('Paste mask pixels only (otherwise paste the complete rectangle and real background)');layout.addWidget(only);row=QHBoxLayout();layout.addLayout(row)
        def selected():
            index=items.currentRow()
            if index<0:raise ValueError('Select a crop from the list.')
            return doc.detached_crops[index]
        def action(kind):
            try:
                crop=selected()
                if kind=='paste':self._commit('Paste retained crop',lambda:paste_crop(doc,crop['id'],only.isChecked()));self.cleaned_checkbox.setChecked(True)
                elif kind=='export':
                    path,_=QFileDialog.getSaveFileName(dialog,'Export real crop pixels',crop['name']+'.tif','TIFF (*.tif *.tiff)')
                    if path:
                        import tifffile
                        tifffile.imwrite(path,unpack_array(crop['pixels']))
                elif kind=='protect':self._commit('Change crop protection',lambda:crop.update(protected=not crop.get('protected'),pasted=False))
                else:self._commit('Remove retained crop',lambda:doc.detached_crops.remove(crop))
                reload()
            except Exception as e:QMessageBox.warning(dialog,'Retained crop',str(e))
        for title,kind in [('Paste back','paste'),('Protect / release','protect'),('Export TIFF','export'),('Remove snapshot','remove')]:
            b=QPushButton(title);b.clicked.connect(lambda checked=False,k=kind:action(k));row.addWidget(b)
        buttons=QDialogButtonBox(QDialogButtonBox.StandardButton.Close);buttons.rejected.connect(dialog.reject);layout.addWidget(buttons);dialog.exec()
