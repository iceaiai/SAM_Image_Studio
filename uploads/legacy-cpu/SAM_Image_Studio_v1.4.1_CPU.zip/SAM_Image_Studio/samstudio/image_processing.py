"""Dtype-preserving spatial restoration, synthetic noise and retained crop patches."""
from __future__ import annotations
import copy,math,uuid
import numpy as np
from .domain import pack_array,unpack_array,pack_mask,unpack_mask
from .processing import cast_like,bounding_box

METHODS={
 'TV restoration':{'weight':(.08,.0001,2.,.01),'iterations':(100,1,1000,1),'tolerance':(.0002,.000001,.1,.0001)},
 'TV Bregman restoration':{'weight':(5.,.01,100.,.5),'iterations':(100,1,1000,1)},
 'Wavelet sparse restoration':{'sigma':(.04,0.,1.,.01),'levels':(2,1,6,1)},
 'Non-local means':{'strength':(.08,.001,1.,.01),'sigma':(.03,0.,1.,.01),'patch_size':(5,1,15,2),'search_distance':(6,1,25,1)},
 'Bilateral denoise':{'sigma_color':(.05,.001,1.,.01),'sigma_spatial':(3.,.1,20.,.5)},
 'Median denoise':{'kernel_size':(3,1,31,2)},
 'Gaussian smooth':{'kernel_size':(5,1,101,2),'sigma':(1.,.01,30.,.1)},
 'Gaussian noise':{'sigma':(.03,0.,1.,.01),'seed':(0,0,2147483647,1)},
 'Poisson noise':{'peak_counts':(50.,1.,1000000.,5.),'seed':(0,0,2147483647,1)},
 'Salt and pepper noise':{'amount':(.01,0.,1.,.01),'seed':(0,0,2147483647,1)},
}

def parameters(method,values=None):
    if method not in METHODS:raise ValueError('Unknown processing method.')
    result={k:v[0] for k,v in METHODS[method].items()}
    for k,v in (values or {}).items():
        if k not in result:raise ValueError('Unknown parameter: '+k)
        low,high=METHODS[method][k][1:3]
        if isinstance(v,bool) or not math.isfinite(float(v)) or not low<=v<=high:raise ValueError(f'{k} must be between {low} and {high}.')
        if isinstance(result[k],int) and int(v)!=v:raise ValueError(f'{k} must be an integer.')
        result[k]=int(v) if isinstance(result[k],int) else float(v)
    for k in ('kernel_size','patch_size'):
        if k in result and result[k]%2!=1:raise ValueError(f'{k} must be an odd integer.')
    return result

def process_pixels(raw,method,values=None,target=None,progress=None,cancel=None):
    import cv2
    from skimage import restoration
    a=np.asarray(raw)
    if a.dtype.kind not in 'buif' or not np.isfinite(a).all():raise ValueError('Processing requires finite real-valued pixels.')
    p=parameters(method,values)
    if a.ndim not in (2,3) or a.ndim==3 and a.shape[2] not in (3,4):raise ValueError('Expected grayscale, RGB or RGBA pixels.')
    mask=np.ones(a.shape[:2],bool) if target is None else np.asarray(target,bool)
    if mask.shape!=a.shape[:2] or not mask.any():raise ValueError('Choose a nonempty processing region.')
    work=a[...,:3] if a.ndim==3 else a
    if a.dtype.kind in 'bu':low=0.;high=1. if a.dtype.kind=='b' else float(np.iinfo(a.dtype).max)
    elif a.dtype.kind=='i':low=float(np.iinfo(a.dtype).min);high=float(np.iinfo(a.dtype).max)
    else:low=float(work.min());high=float(work.max())
    span=high-low if high>low else 1.
    unit=np.clip((work.astype(float)-low)/span,0,1)
    channels=[unit] if a.ndim==2 else [unit[...,c] for c in range(3)]
    outputs=[];rng=np.random.default_rng(p.get('seed',0))
    for index,x in enumerate(channels):
        if cancel and cancel.is_set():raise InterruptedError('Processing cancelled.')
        if progress:progress(f'{method}: channel {index+1}/{len(channels)}')
        if method=='TV restoration':y=restoration.denoise_tv_chambolle(x,weight=p['weight'],eps=p['tolerance'],max_num_iter=p['iterations'])
        elif method=='TV Bregman restoration':y=restoration.denoise_tv_bregman(x,weight=p['weight'],max_num_iter=p['iterations'])
        elif method=='Wavelet sparse restoration':
            import pywt
            levels=min(p['levels'],pywt.dwtn_max_level(x.shape,'db2'))
            if levels<1:raise ValueError('The image is too small for a db2 wavelet decomposition.')
            y=restoration.denoise_wavelet(x,sigma=p['sigma'],wavelet='db2',wavelet_levels=levels,method='BayesShrink',mode='soft',rescale_sigma=True)
        elif method=='Non-local means':y=restoration.denoise_nl_means(x,h=p['strength'],sigma=p['sigma'],patch_size=p['patch_size'],patch_distance=p['search_distance'],fast_mode=True,preserve_range=True)
        elif method=='Bilateral denoise':y=restoration.denoise_bilateral(x,sigma_color=p['sigma_color'],sigma_spatial=p['sigma_spatial'],channel_axis=None)
        elif method=='Median denoise':
            from scipy.ndimage import median_filter
            y=median_filter(x,size=p['kernel_size'],mode='reflect')
        elif method=='Gaussian smooth':y=cv2.GaussianBlur(x,(p['kernel_size'],)*2,p['sigma'],borderType=cv2.BORDER_REFLECT_101)
        elif method=='Gaussian noise':y=x+rng.normal(0,p['sigma'],x.shape)
        elif method=='Poisson noise':y=rng.poisson(np.clip(x,0,1)*p['peak_counts'])/p['peak_counts']
        else:
            y=x.copy();draw=rng.random(x.shape);y[draw<p['amount']/2]=0;y[(draw>=p['amount']/2)&(draw<p['amount'])]=1
        outputs.append(y)
    processed=outputs[0] if a.ndim==2 else np.stack(outputs,axis=-1)
    restored=cast_like(np.clip(processed,0,1)*span+low,a.dtype)
    output=a.copy()
    if a.ndim==3:output[...,:3][mask]=restored[mask]
    else:output[mask]=restored[mask]
    if cancel and cancel.is_set():raise InterruptedError('Processing cancelled.')
    return output

def processing_target(doc,selected=None):
    target=np.ones(doc.frame.shape,bool) if selected is None else np.asarray(selected,bool).copy()
    if target.shape!=doc.frame.shape:raise ValueError('Processing region dimensions do not match.')
    target&=~doc.removed
    for crop in doc.detached_crops:
        if crop.get('protected') and not crop.get('pasted'):
            x,y,w,h=crop['bbox'];target[y:y+h,x:x+w]=False
    if not target.any():raise ValueError('No unprotected pixels remain. Restore/fill removed regions or release retained crops.')
    return target

def apply_processing(doc,result,target,method,params):
    obj=doc.apply_image_smoothing(result,target,method,params)
    obj.name=method+' '+str(obj.cleaning['sequence']).zfill(3)
    doc.cleaning_history[-1]['operation']='image_processing'
    return obj

def retain_crop(doc,mask,name=None,protect=True,padding=3):
    if isinstance(padding,bool) or int(padding)!=padding or not 0<=padding<=100:raise ValueError('Crop padding must be 0 to 100 pixels.')
    mask=np.asarray(mask,bool)
    if mask.shape!=doc.frame.shape or not mask.any():raise ValueError('Select an area or one or more masks to crop.')
    x,y,w,h=bounding_box(mask);pad=int(padding);x2=min(doc.frame.shape[1],x+w+pad);y2=min(doc.frame.shape[0],y+h+pad);x=max(0,x-pad);y=max(0,y-pad)
    source=doc.working if doc.working is not None else doc.frame.raw
    record={'id':str(uuid.uuid4()),'name':name or f'Crop {len(doc.detached_crops)+1}', 'bbox':[x,y,x2-x,y2-y],
            'mask':pack_mask(mask[y:y2,x:x2]),'pixels':pack_array(source[y:y2,x:x2]),'protected':bool(protect),'pasted':False,
            'coordinate_shape':list(doc.frame.shape),'rotation_count':len(doc.rotation),'padding':pad}
    doc.detached_crops.append(record)
    return record

def paste_crop(doc,ident,mask_only=False):
    record=next(c for c in doc.detached_crops if c['id']==ident)
    if record['coordinate_shape']!=list(doc.frame.shape) or record['rotation_count']!=len(doc.rotation):raise ValueError('Crop coordinates no longer match the image.')
    pixels=unpack_array(record['pixels']);x,y,w,h=record['bbox'];target=np.zeros(doc.frame.shape,bool)
    target[y:y+h,x:x+w]=unpack_mask(record['mask']) if mask_only else True
    output=(doc.working if doc.working is not None else doc.frame.raw).copy()
    patch=output[y:y+h,x:x+w];local=target[y:y+h,x:x+w];patch[local]=pixels[local]
    # Pasting restores a filled pixel region, including any prior pending removal.
    if (target&doc.removed).any():doc.apply_cleaning_fill(output,target&doc.removed,'retained crop')
    apply_processing(doc,output,target,'Paste retained crop',{'crop_id':ident,'mask_only':bool(mask_only)})
    record['pasted']=True;record['protected']=False
    return output
