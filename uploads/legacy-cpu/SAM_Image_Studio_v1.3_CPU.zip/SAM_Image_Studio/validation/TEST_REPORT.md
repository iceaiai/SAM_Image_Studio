# SAM Image Studio 1.3.0 test report

**270 passed, 0 failed, 0 errors, 0 skipped.** The final complete run took
146.17 seconds on Linux x86-64, CPython 3.12.14,
PySide6 6.8.3 and PyTorch 2.7.1+cpu. This validates the recorded scenarios.

## Requested behavior and evidence

| Function | Checks |
| --- | --- |
| Pixel region inversion | All or some objects in Manual, Edit, Clean and Segment. Exact complement, holes, disconnected areas, repeated inversion, empty/point-only behavior, original-mask preservation, undo/redo and autosave corruption handling. |
| Manual and Edit | Convert the inverted region to a mask object and export exact COCO RLE. Original object identity and pixels remain unchanged. |
| Clean | An inverted background region changes only its target pixels. Undo restores the acquired image and selection. Existing overlapping cleaning-object replay and partial restoration checks remain passing. |
| Segment | Genuine SAM1 ViT-B and SAM2.1 Tiny run both point and automatic-grid inference within inverted regions, preserve accepted masks and accept clipped output. Both also segment the actual smoothed image source. Backend contract tests verify acceptance clipping independently. |
| Original/processed files | Exact TIFF pixels, dtype and calibration for either or both versions. Source-overwrite prevention. Optional source images in mask saves and correct image-source metadata. Both COCO and YOLO original-only, processed-only, both and annotations-only choices. Mixed processed/unprocessed batches reject invalid export before writing. |
| Image smoothing | Gaussian and median filters reduce impulse/noise variance across uint8, uint16, int16 and float32. Unselected pixels stay exact, RGB channels stay separate, alpha stays exact and nonfinite values stay local. Actual Qt before/after preview accepts or cancels. After smoothing, canvas picking, Edit and region inversion still use annotation objects; processing records remain selectable and restorable in Objects. Cleaning replay, undo, saved JSON and deleting the smoothing region restore previous image values. Unfilled removed pixels are excluded. |
| 20 lookup colors | Twenty unique presets, cycle behavior, object/group assignment, selected scope, lock rejection, default colors, new-object scheme, JSON recovery, real dialog controls and GUI Undo/Redo. Mask and COCO output retain exact RGB values. |
| Earlier GUI and export behavior | Native polygon clicks across zooms, Hand/Reset, zoomed points, persistent vertices, radius isolation, curves, histogram resize/repaint, check-mark combos, alpha, weighted overlaps, manual background groups and reversible cleaning remain passing. |
| Recovery and microscopy | Exact arrays and masks, atomic backup, source/frame identity, transactional failure, schemas 1/2 migration, anisotropic calibration, TIFF stacks/codecs and genuine DM3/DM4/EMD fixtures. |

The new coverage includes 52 feature cases and 6 genuine SAM integration cases.
The complete run includes four fresh GUI processes using actual weights, saved
prompts followed by additional clicks, acceptance, autosave recovery and histogram
repainting. Genuine checkpoints, rather than generated stand-ins, validate model compatibility.

## Genuine checkpoints

| Model | SHA256 |
| --- | --- |
| SAM1 ViT-B | `ec2df62732614e57411cdcf32a23ffdf28910380d03139ee0f4fcbe91eb8c912` |
| SAM2.1 Tiny | `7402e0d864fa82708a20fbd15bc84245c2f26dff0eb43a4b5b93452deb34be69` |
| LaMa TorchScript | `7ba7aa7ac37a4d41fdbbeba3a2af7ead18058552997e3a3cd1a3b2210c9e6b4c` |

Real LaMa generated replacement pixels while every pixel outside the target
remained unchanged. Timings are machine-specific. Model scores are estimates,
not ground-truth segmentation accuracy.

## Test modules

| Module | Passed cases |
| --- | ---: |
| test_core | 27 |
| test_exports_io | 40 |
| test_extra_regressions | 8 |
| test_gui | 18 |
| test_gui_fill_and_export | 5 |
| test_install_safety | 3 |
| test_microscopy_readers | 5 |
| test_real_models | 25 |
| test_recovery_download | 8 |
| test_v11_regressions | 28 |
| test_v12_regressions | 51 |
| test_v13_features | 52 |

## Packaged application checks

Every Python module in the 1.3.0 wheel matches the final source and separately
installed module bytes. The installed package passed its CPU self-test from a
directory outside the source tree. Two additional fresh processes loaded genuine
SAM1 and SAM2.1 weights from that installed package, added live points, accepted
masks, restored autosave and painted/resized histograms. Both captured zero GUI
errors. These checks are additional to the 270 pytest cases. pip check passed.

The 23-page official Word manual and 24-slide editable PowerPoint were
rendered and visually reviewed page by page. The PPT retains five native tables
and its original native chart and embedded workbook. Package, dimensions, fonts,
native chart/workbook and reimport checks passed. Native PowerPoint opening was
not performed. All GUI screenshots show actual Qt controls; particle images are
explicitly synthetic test data.

## Reproduce

```text
python -m pip install -r requirements-dev.txt
python scripts/fetch_validation_assets.py --models --directory validation_assets
python scripts/run_full_validation.py --assets validation_assets --output validation/local_full_results.xml
```

The runner rejects missing assets and any skipped test. Model weights and external
reader fixtures are omitted from the release; the downloader retrieves genuine
public files with recorded digests. Evidence is in validation/v13_full_results.xml,
validation/v13_full_results.models.json, validation/release_verification_v13.json,
validation/installed_cpu_freeze.txt and validation/installed_wheel_*.json.
Captured source paths describe the validation workspace.

## Limits

Native Windows desktop/EXE, macOS, NVIDIA CUDA, SAM3 real weights, original SAM2
checkpoints and larger model variants were not executed. Windows source install
and portable-build scripts are included. No prebuilt Windows executable is included.
Direct dependency pins are unchanged. The previous release resolved Windows
dependency wheels; this release executed the Linux CPU installation.

One pycocotools/NumPy deprecation warning appeared. Exact decoding and the complete
run passed. Large or instrument-specific data may require separate acceptance tests.
