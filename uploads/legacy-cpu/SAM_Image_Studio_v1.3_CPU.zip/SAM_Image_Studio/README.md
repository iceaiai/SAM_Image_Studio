# SAM Image Studio 1.3

A Python and PySide6 desktop GUI for microscopy annotation, SAM segmentation,
calibrated object measurements and reversible image cleaning.

The default installation uses CPU PyTorch. Start with SAM2.1 Tiny for a small model,
or SAM1 ViT-B. Both backends have passed genuine checkpoint inference and Qt
preview, acceptance, autosave and recovery tests. The release includes source,
tests, a synthetic calibrated example, Windows batch launch/install scripts and
Python/Conda instructions.

## Start

1. Extract the entire package to a writable folder.
2. Use 64-bit Python 3.12. On Windows run Install_CPU.bat, then Start_GUI.bat.
3. On Linux run bash install_cpu.sh, then bash start_gui.sh.
4. Open examples/synthetic_particles.ome.tif.
5. Choose Load model, SAM2.1, Tiny, CPU. Leave the checkpoint field empty to download.
6. Choose Segment and Point. Left-click a particle, inspect the preview and click Accept masks.
7. Give the first object a group. Reopening the same image restores its saved objects.

See INSTALL_UNINSTALL.md for installation, removal, Conda, optional CUDA, native
Windows build instructions and troubleshooting. The formal Word manual and editable
PowerPoint accompany this release.

## Features

- Pixel region inversion: select some objects or all (Ctrl+A), then Ctrl+I to
  select remaining image pixels. Manual/Edit can create an exact region object;
  Clean removes it; Segment clips point/grid inference to it. Holes and disconnected
  areas survive autosave and Undo/Redo.
- Original and processed image checkboxes in mask saves and dataset export.
  File > Save original / processed images also saves either or both as exact TIFFs.
  Dataset export supports either version, both or annotations only.
- Gaussian and median image smoothing with asynchronous preview, region scope,
  original/current input, exact dtype/alpha preservation and reversible image records.
- Default group colors or a fixed 20-color lookup table, by object/group, with
  selectable start and saved assignment for new objects. Numeric labels stay fixed.
- Manual polygon, rectangle, circle, ellipse and point annotations. Click within
  3 image pixels of the polygon start to close it, at any zoom.
- Separate Manual, Segment, Clean and Edit modes with readable selection checks.
- Hand and Reset magnification icons; undo/redo controls twice their original size.
- SAM1, SAM2 and SAM2.1 catalog with CPU/CUDA selection and compatible local .pt/.pth checkpoints.
- SAM3 native interactive/text adapter, separately installed and experimental.
- Normal point/shape SAM inference across the image, optional exact ROI clipping,
  and a separate automatic grid mode. Every mode protects accepted masks.
- Explicit refinement of an existing object, with its ID and group retained.
- Objects, Groups and Image files panels; multiple files, image stacks and microscopy datasets.
- TIFF/OME-TIFF/ImageJ, DM3, DM4 and compatible EMD readers with physical pixel calibration.
- Atomic native project JSON autosave and previous-save backup, exact masks and source/frame matching.
- Persistent vertex handles: dragging never adds points. Repeated Delete removes
  nearest vertices within a configurable radius, inside the selected object only.
  Edit mode shows a radius field (20 image pixels by default), three-times-larger
  handles and doubled mask outline width.
- Fill Holes and cubic Smooth Edges with preview, batch edits and area updates.
- Cleaning removal, restoration, neighbor interpolation, LaMa and tiled background patches.
- Visible cleaning objects retain exact regions and fill methods. In Clean mode,
  right-click an object > Delete for cleaning. Hide/show changes display; deleting
  a cleaning object restores its pixels while keeping other cleaning edits.
- Select any group of manually added area regions as the patch-fill background.
- BMP24, PNG/TIFF, object/group exports and integer label maps. Binary grayscale
  stays available; weighted grayscale adds equal intensity at overlaps. Background
  alpha and mask transparency are independent, with original/cleaned overlay sources.
- Native schema 3 and COCO extensions retain active/restored cleaning records,
  exact pixels, methods and restoration rules, separate from foreground training labels.
- Exact COCO RLE masks, explicit lossy YOLO conversion, area/ECD histograms and CSV/plot export.

## Validation boundaries

Testing ran on Linux x86-64, Python 3.12 and CPU PyTorch 2.7.1. The validation
folder contains machine-readable test results and actual checkpoint hashes.
Windows dependency wheels were checked, but native Windows installation and the
Windows executable build were not executed here. The native build recipe is included.
No prebuilt Windows EXE is included.

NVIDIA GPU execution, the optional SAM3 adapter with real weights and the larger
SAM variants require acceptance testing on the target hardware. SAM3 is never
silently presented as a verified CPU feature. SAM3 access requires the upstream
checkpoint authorization process.

The test suite validates defined scenarios. It cannot establish that all possible
images, hardware combinations and future dependency changes are free of defects.

## Project structure

| Path | Purpose |
| --- | --- |
| samstudio/main_window.py | Menus, workflow, worker jobs and autosave coordination |
| samstudio/canvas.py | Image interaction, shapes, prompts and vertex handles |
| samstudio/inference.py | Official model adapters, verified download/cache and LaMa |
| samstudio/domain.py | Exact project format, source identity and undo snapshots |
| samstudio/imageio.py | Common and microscopy image readers |
| samstudio/processing.py | Mask refinement, display conversion and cleaning |
| samstudio/exports.py | COCO, YOLO, mask images and measurement CSV |
| samstudio/dialogs.py | Model, export, refinement, calibration and plot dialogs |
| tests | Unit, real Qt and opt-in genuine checkpoint tests |
| vendor | Official SAM2 CPU Python backend and pure Python support wheels |

Source licensing and upstream references are in LICENSE and third_party/NOTICE.md.

## Updating from earlier releases

Extract 1.3 into a new folder and run Install_CPU.bat, then Start_GUI.bat.
Cached models can be reused. Open your original images to recover their existing
SAM_Annotations projects. Back up these project files before editing if you need
to return to an older release. Version 1.3 reads schema 1 and 2 projects and migrates
their cleaning footprints into visible objects. Older programs cannot read schema 3.

See RELEASE_NOTES.md for the reported fixes and validation/TEST_REPORT.md for the
270-test run, including four fresh GUI processes with real SAM weights and
40× zoom point prompts followed by cleaning-object recovery on both SAM backends.
