# SAM Image Studio 1.3.0

This release adds shared pixel region inversion, optional original/processed image copies,
Gaussian/median image smoothing and a fixed 20-color lookup table. Existing navigation,
editing, segmentation and reversible cleaning behavior remains available.

| Function | Released behavior |
| --- | --- |
| Region inversion | Ctrl+A selects all objects; Ctrl+I selects the complement of their exact masks. Manual/Edit creates a region object, Clean uses the region as target and Segment clips prompted/grid output to it. Holes and disconnected areas persist. |
| Image versions | Save the original frame, the cleaned/smoothed image, or both. TIFF copies preserve dtype and calibration. Mask saving has optional image checkboxes. Dataset exports support either, both or annotations only. |
| Smooth image pixels | Gaussian sigma 0.1–20 pixels or odd median windows 3–31 pixels, whole image or selected region, before/after preview, Apply and Undo. Exact derived pixels and parameters survive JSON recovery. |
| Lookup colors | Default group colors or 20 fixed RGB presets, selectable start, object/group assignment and saved scheme for new objects. Existing IDs and numeric labels remain fixed. |
| Overlap weights | Weighted grayscale adds equal intensity per object. Two overlapping objects have twice the base value. Weight is floor(255 / maximum overlap) per output file, recorded in the mapping JSON. Original binary grayscale remains available. |
| Polygon closure | After placing at least three vertices, click within 3 original image pixels of the start. Enter/double-click also finishes the polygon. |
| Background source | Explicitly choose one group of manually drawn area regions. Any group name works. Irregular sources sample only their selected pixels. |
| Navigation | Left Hand tool drags the image. Reset magnification icon or F restores default fit. |
| Zoomed points | Point events remain point prompts at high zoom without area-size validation. Both real SAM backends passed 40× zoom checks. |
| Vertex editing | Explicit Edit mode, three-times-larger handles, doubled mask outlines and a configurable radius field, default 20 image pixels. Moves retain handle count; Delete searches only the selected object. |
| Selected option | Readable text and a trailing check mark without changing stored option values. |
| Transparency and overlay | Independent transparent-background checkbox and mask-transparency slider, with original or cleaned overlay source. Outside-object pixels remain transparent when selected. |
| Object cleaning | Clean mode adds Delete for cleaning to an object's context menu in the canvas and object list. Its ID remains as a cleaning region. |
| Cleaning recovery | Removed/filled regions are visible objects by default. Hide/show only changes display. Deleting one restores its pixels and replays remaining overlapping edits. |
| JSON and COCO | Native schema 3 reads earlier projects and migrates cleaning footprints. JSON and separate COCO cleaning/background collections retain exact regions, pixels, methods and restoration history, including restored/deleted records. |
| Undo and redo | Toolbar icons are twice their original size, with larger click targets. Completed operations retain exact undo/redo snapshots. |

The complete recorded run passed **270 tests, 0 failures and 0 skips**, with
genuine SAM1 ViT-B, SAM2.1 Tiny and LaMa CPU checkpoints. It includes four fresh
GUI processes, zoom/closure/overlay checks, cleaning recovery and real microscopy
reader fixtures. See validation/TEST_REPORT.md for the environment and evidence.

The official Word manual contains the functional requirements and procedures.
The 24-slide PowerPoint retains editable controls and current screenshots.

Install into a new folder and run Install_CPU.bat, then Start_GUI.bat. Existing
models and source images/projects can be reused. Back up projects if you need
to return to a release older than 1.3, which cannot read schema version 3.

Native Windows desktop/EXE, NVIDIA CUDA, SAM3 and larger model variants remain
outside this Linux CPU validation. No prebuilt Windows executable is included.
