@echo off
setlocal
cd /d "%~dp0"
echo SAM Image Studio CPU installation
echo An isolated environment will be created in this folder.
py -3.12 -c "import sys; assert sys.maxsize > 2**32" >nul 2>&1
if not errorlevel 1 (
    py -3.12 scripts\install_environment.py --backend cpu
    goto done
)
python -c "import sys; assert sys.version_info[:2] == (3,12) and sys.maxsize > 2**32" >nul 2>&1
if not errorlevel 1 (
    python scripts\install_environment.py --backend cpu
    goto done
)
echo Install 64-bit Python 3.12 with the Python Launcher, then run this file again.
echo Or activate a Python 3.12 Conda environment and follow INSTALL_UNINSTALL.md.
echo Official download: https://www.python.org/downloads/
pause
exit /b 1
:done
set "SAM_STUDIO_INSTALL_STATUS=%errorlevel%"
if not "%SAM_STUDIO_INSTALL_STATUS%"=="0" echo Installation failed. See the error above.
if "%SAM_STUDIO_INSTALL_STATUS%"=="0" echo Success. Double-click Start_GUI.bat.
pause
exit /b %SAM_STUDIO_INSTALL_STATUS%
