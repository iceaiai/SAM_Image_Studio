# Run on native Windows in the verified CPU environment.
from pathlib import Path
from PyInstaller.utils.hooks import collect_data_files, collect_submodules

root=Path(SPECPATH).parent
datas=collect_data_files("sam2")
datas+=collect_data_files("rsciio",excludes=["tests/**"])
datas += [(str(root/"third_party"),"third_party"),(str(root/"LICENSE"),".")]
hidden=collect_submodules("sam2",filter=lambda name:".tests" not in name)
hidden+=["rsciio.digitalmicrograph","rsciio.emd","rsciio.tiff","samstudio.selftest","matplotlib.backends.backend_qtagg"]
a=Analysis([str(root/"launch.py")],pathex=[str(root)],binaries=[],datas=datas,hiddenimports=hidden,
           hookspath=[],hooksconfig={"matplotlib":{"backends":["QtAgg"]}},runtime_hooks=[],
           excludes=["tkinter","PyQt5","PyQt6","PySide2","IPython","jupyter","pytest"],noarchive=False)
pyz=PYZ(a.pure)
exe=EXE(pyz,a.scripts,[],exclude_binaries=True,name="SAM_Image_Studio",debug=False,bootloader_ignore_signals=False,
        strip=False,upx=False,console=False,disable_windowed_traceback=False)
coll=COLLECT(exe,a.binaries,a.datas,strip=False,upx=False,name="SAM_Image_Studio")
