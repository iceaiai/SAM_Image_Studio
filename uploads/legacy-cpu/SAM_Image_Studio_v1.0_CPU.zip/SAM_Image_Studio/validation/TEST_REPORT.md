# SAM Image Studio 1.0 validation report

The final complete run passed 125 tests, with zero failures, zero errors
and zero skipped tests. Runtime: Linux x86-64, Python 3.12.14, PySide6 6.8.3,
PyTorch 2.7.1+cpu. Qt tests operate real offscreen widgets with mouse/keyboard events.

## Genuine model tests

| Backend | Checkpoint | Evidence |
| --- | --- | --- |
| SAM1 ViT-B | Official SAM1 weights | Positive point and box, negative-point/ROI clipping, protected whole image, wrong-weight rollback, Qt preview/accept/recovery and undo/redo |
| SAM2.1 Tiny | Official SAM2.1 weights | Same real predictor and Qt workflow checks, plus separate installed-wheel self-test |
| LaMa | Real TorchScript checkpoint | Inpainted target differs, every outside pixel is exactly preserved |

The model scores are predicted scores, not measured segmentation accuracy.
Hashes and observed timings appear in real_models.json.

## Data and interface checks

- Exact mask/array encoding, source/frame matching, backup restore and transactional corrupt-project rejection.
- Original data preservation, anisotropic area conversion and physical-unit retention including picometers.
- OME/ImageJ TIFF stacks, LZW/Zstd/Deflate and real DM3/DM4/EMD reader fixtures.
- Official pycocotools decoding of exported masks including holes and disconnected regions.
- BMP24, PNG/TIFF, alpha/transparency, per-object/per-group exports and consistent numeric ID mappings.
- Manual tools, group creation, locks, vertex dragging/deletion, safe Delete context and Escape cancellation.
- Fill Holes, Smooth Edges, neighbor/patch image fill, preview/apply and exact undo.
- Mixed calibrated/pixel histograms, selection filters and live updates.
- Completed, interrupted, resumed, oversized partial and failed-checksum download behavior.
- Clean isolated CPU installation, repeat installation and self-test settings preservation.
- Uninstallation preserves project data and refuses unmarked environments.

## Validation boundaries

No prebuilt Windows EXE is included. The source/batch install and native build recipe
are supplied. Native Windows, CUDA, real SAM3, original SAM2 checkpoints and larger
variants still require target-system acceptance. Public direct dependency Windows
wheels were resolved, which does not establish Windows runtime correctness.

The suite proves its defined assertions on the tested environment. It cannot
guarantee that every possible image or future dependency combination is bug-free.
The sole warning in the final run is a NumPy API deprecation inside pycocotools;
the exact-mask equality checks pass.

## Reproduce

Install requirements-dev.txt, then run scripts/fetch_validation_assets.py --models
and scripts/run_full_validation.py. The full runner rejects skipped tests.
The regular pytest command without external assets intentionally skips real-model
and microscopy fixture checks.
