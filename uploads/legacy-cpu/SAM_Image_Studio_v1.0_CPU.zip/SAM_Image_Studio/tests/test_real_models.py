"""Opt-in tests with genuine public checkpoints, never generated dummy weights."""
import gc
import json
import os
import time
from pathlib import Path
import numpy as np
import pytest
from PIL import Image
from samstudio.inference import CATALOG, InferenceEngine, lama_fill, file_digest, LAMA_SHA256
from samstudio.processing import shape_mask
from samstudio.domain import Document
from samstudio.imageio import load_file, LoadResult

pytestmark=pytest.mark.integration
WEIGHTS=Path(os.environ.get("SAM_STUDIO_TEST_WEIGHTS","not_provided"))
IMAGE=Path(os.environ.get("SAM_STUDIO_TEST_IMAGE","not_provided"))
REPORTS=[]


@pytest.fixture(scope="module",params=[("SAM1","ViT-B"),("SAM2.1","Tiny")])
def loaded_engine(request):
    family,variant=request.param
    spec=next(s for s in CATALOG if s.family==family and s.variant==variant)
    path=WEIGHTS/spec.filename
    if not path.is_file() or not IMAGE.is_file():
        pytest.skip("Set SAM_STUDIO_TEST_WEIGHTS and SAM_STUDIO_TEST_IMAGE to real downloaded assets.")
    started=time.perf_counter();engine=InferenceEngine();result=engine.load(spec,"cpu",path)
    assert result["device"]=="cpu" and engine.ready
    rgb=np.asarray(Image.open(IMAGE).convert("RGB").resize((600,400))).copy()
    report={"family":family,"variant":variant,"device":"cpu","checkpoint_sha256":file_digest(path),
            "load_seconds":round(time.perf_counter()-started,3)}
    REPORTS.append(report)
    yield engine,rgb,report
    engine.predictor=engine.model=engine.processor=None;gc.collect()


def test_real_positive_point_and_box(loaded_engine):
    engine,rgb,report=loaded_engine
    started=time.perf_counter()
    mask,score=engine.predict(rgb,[[167,125,1]])
    assert mask.shape==rgb.shape[:2] and mask.dtype==bool and mask.any() and np.isfinite(score)
    boxed,box_score=engine.predict(rgb,box=[100,60,220,240])
    assert boxed.any() and np.isfinite(box_score)
    report.update(prompt_seconds=round(time.perf_counter()-started,3),point_area=int(mask.sum()),point_score=score,box_area=int(boxed.sum()))


def test_real_roi_clipping_negative_point_and_existing_object_protection(loaded_engine):
    engine,rgb,report=loaded_engine
    roi=shape_mask("ellipse",[[100,60],[230,230]],rgb.shape[:2])
    protected=np.zeros(roi.shape,bool);protected[105:145,150:185]=True
    result=engine.infer(rgb,points=[[167,125,1],[210,220,0]],roi=roi,protected=protected,min_area=1)
    assert result
    assert all(not (m & ~roi).any() and not (m & protected).any() for m in result)
    report["roi_area"]=sum(int(m.sum()) for m in result)


def test_real_whole_image_grid_preserves_accepted_pixels(loaded_engine):
    engine,rgb,report=loaded_engine
    protected=np.zeros(rgb.shape[:2],bool);protected[100:170,140:200]=True;before=protected.copy()
    started=time.perf_counter()
    result=engine.infer(rgb,whole=True,protected=protected,grid=2,min_score=.2,min_area=4)
    assert result and np.array_equal(protected,before)
    assert all(not (m & protected).any() for m in result)
    report.update(whole_seconds=round(time.perf_counter()-started,3),whole_new_masks=len(result))


def test_real_mismatched_checkpoint_rejected_and_previous_model_retained(loaded_engine,tmp_path):
    engine,rgb,report=loaded_engine
    import torch
    path=tmp_path/"wrong.pt";torch.save({"unrelated":torch.zeros(1)},path)
    previous=engine.predictor
    with pytest.raises(RuntimeError,match="Cannot load"):engine.load(engine.spec,checkpoint=path)
    assert engine.predictor is previous
    assert engine.predict(rgb,[[167,125,1]])[0].any()
    report["failed_load_preserved_predictor"]=True


def test_real_qt_preview_accept_autosave_reopen(loaded_engine,window,qtbot,tmp_path):
    engine,rgb,report=loaded_engine
    path=tmp_path/"real-model-image.png";Image.fromarray(rgb).save(path)
    window._opened(LoadResult(load_file(path)));doc=window.document
    window._commit("group",lambda:doc.ensure_group("Truck objects"))
    window.engine=engine;window.auto_checkbox.setChecked(False);window.mode.setCurrentText("Segment")
    window._prompt_added(167,125,1)
    window.run_inference(force_whole=False)
    qtbot.waitUntil(lambda:not window.busy,timeout=120000)
    assert window.canvas.preview_masks and not window.errors
    window.accept_preview();assert len(doc.objects)==1 and doc.objects[0].mask.any()
    expected=doc.objects[0].mask.copy()
    restored=Document(doc.frame);assert window.stores[doc.frame.key].load(restored)[0]
    assert np.array_equal(restored.objects[0].mask,expected)
    assert restored.objects[0].provenance["model"]==engine.spec.label
    window.undo();assert not doc.objects
    window.redo();assert np.array_equal(doc.objects[0].mask,expected)
    report["qt_preview_accept_recovery"]=True


def test_real_lama_only_changes_selected_pixels():
    path=WEIGHTS/"big-lama.pt"
    if not path.is_file() or not IMAGE.is_file():pytest.skip("Provide real LaMa checkpoint and test image.")
    assert file_digest(path)==LAMA_SHA256
    rgb=np.asarray(Image.open(IMAGE).convert("RGB").resize((128,85))).copy()
    target=np.zeros(rgb.shape[:2],bool);target[25:50,30:55]=True
    started=time.perf_counter();output=lama_fill(rgb,target,path)
    assert output.shape==rgb.shape and output.dtype==rgb.dtype
    assert np.array_equal(output[~target],rgb[~target]) and np.any(output[target]!=rgb[target])
    REPORTS.append({"family":"LaMa","device":"cpu","checkpoint_sha256":LAMA_SHA256,
                    "inference_seconds":round(time.perf_counter()-started,3),"outside_region_unchanged":True})


@pytest.fixture(scope="module",autouse=True)
def save_results():
    yield
    if REPORTS:
        path=Path(os.environ.get("SAM_STUDIO_TEST_REPORT","validation/real_models.json"))
        path.parent.mkdir(parents=True,exist_ok=True)
        path.write_text(json.dumps({"real_checkpoint_tests":REPORTS,"not_verified":["NVIDIA CUDA","Native SAM3","SAM1 ViT-L/ViT-H","SAM2 Small/Base+/Large","Native Windows EXE"]},indent=2))
