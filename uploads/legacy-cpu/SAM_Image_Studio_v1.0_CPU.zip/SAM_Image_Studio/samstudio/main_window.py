from __future__ import annotations

import copy
import json
import logging
import math
import threading
import traceback
from datetime import datetime, timezone
from pathlib import Path

import cv2
import numpy as np
from PySide6.QtCore import QObject, QRunnable, QSettings, QSize, QThreadPool, QTimer, Qt, Signal
from PySide6.QtGui import QAction, QActionGroup, QColor, QIcon, QKeySequence, QPainter, QPen, QPixmap, QPolygonF
from PySide6.QtCore import QPointF
from PySide6.QtWidgets import (QApplication, QCheckBox, QColorDialog, QComboBox, QDialog,
    QDialogButtonBox, QDockWidget, QFileDialog, QFormLayout, QHBoxLayout, QInputDialog,
    QLabel, QLineEdit, QMainWindow, QMenu, QMessageBox, QPushButton, QProgressBar,
    QSlider, QSplitter, QToolBar, QTreeWidget, QTreeWidgetItem, QVBoxLayout, QWidget)

from . import __version__
from .canvas import ImageCanvas
from .dialogs import (BrightnessDialog, CalibrationDialog, InferenceOptionsDialog, ModelDialog,
                      RefinementDialog, SaveMasksDialog, StatisticsDialog, combo)
from .domain import Annotation, Document, Group, History, ProjectStore
from .exports import export_coco, export_yolo, safe_name, save_cleaned, save_masks
from .imageio import SUPPORTED_EXTENSIONS, load_files
from .inference import InferenceEngine, data_directory, lama_fill
from .processing import bounding_box, brush_mask, cast_like, display_rgb, filter_proposals, neighbor_fill, patch_fill, raster_contours, shape_mask

LOG = logging.getLogger(__name__)


class JobSignals(QObject):
    progress = Signal(str)
    done = Signal(object, object)


class Job(QRunnable):
    def __init__(self, function):
        super().__init__()
        self.function = function
        self.signals = JobSignals()
        self.cancel = threading.Event()

    def run(self):
        try:
            result = self.function(self.signals.progress.emit, self.cancel)
            self.signals.done.emit(result, None)
        except BaseException as error:
            LOG.error("Background operation failed\n%s", traceback.format_exc())
            self.signals.done.emit(None, error)


def tool_icon(kind, size=28):
    pixmap = QPixmap(size, size);pixmap.fill(Qt.GlobalColor.transparent)
    painter = QPainter(pixmap);painter.setRenderHint(QPainter.RenderHint.Antialiasing)
    painter.setPen(QPen(QColor("#384b63"), 1.8));painter.setBrush(Qt.BrushStyle.NoBrush)
    if kind == "rectangle":painter.drawRect(5,7,18,14)
    elif kind == "circle":painter.drawEllipse(5,5,18,18)
    elif kind == "ellipse":painter.drawEllipse(3,8,22,12)
    elif kind == "polygon":painter.drawPolygon(QPolygonF([QPointF(4,19),QPointF(7,6),QPointF(19,4),QPointF(24,15),QPointF(15,23)]))
    elif kind == "point":painter.drawLine(14,4,14,24);painter.drawLine(4,14,24,14)
    elif kind == "select":painter.drawPolygon(QPolygonF([QPointF(6,3),QPointF(22,15),QPointF(14,17),QPointF(12,25)]))
    elif kind == "delete":painter.drawRect(8,9,12,15);painter.drawLine(5,6,23,6);painter.drawLine(11,3,17,3)
    elif kind == "edit":painter.drawLine(5,23,22,6);painter.drawRect(3,20,5,5);painter.drawRect(20,3,5,5)
    elif kind == "pan":painter.drawLine(14,3,14,25);painter.drawLine(3,14,25,14);painter.drawEllipse(10,10,8,8)
    else:
        painter.setFont(QApplication.font());painter.drawText(pixmap.rect(),Qt.AlignmentFlag.AlignCenter,"↶" if kind=="undo" else "↷")
    painter.end()
    return QIcon(pixmap)


class MainWindow(QMainWindow):
    def __init__(self, restore_session=True):
        super().__init__()
        self.setWindowTitle(f"SAM Image Studio {__version__}")
        self.resize(1500, 960)
        self.engine = InferenceEngine()
        self.documents: dict[str, Document] = {}
        self.histories: dict[str, History] = {}
        self.stores: dict[str, ProjectStore] = {}
        self.current_key = None
        self._updating = False
        self._job = None
        self._job_callback = None
        self._close_requested = False
        self._refine_target = None
        self._preview_context = None
        self._pending_preview = False
        self.stats_dialogs = []
        self._palette = {}
        self.options = {"grid":8,"min_score":.70,"min_area":8,"max_objects":300}
        self.pool = QThreadPool(self);self.pool.setMaxThreadCount(1)
        data_directory().mkdir(parents=True,exist_ok=True)
        self.settings=QSettings(str(data_directory()/"settings.ini"),QSettings.Format.IniFormat)
        self.project_directory = self.settings.value("project_directory", "") or ""
        self.canvas=ImageCanvas(self);self.canvas.setObjectName("imageCanvas")
        self.setCentralWidget(self.canvas)
        self.canvas.selection_changed.connect(self._canvas_selected)
        self.canvas.shape_completed.connect(self._shape_completed)
        self.canvas.prompt_added.connect(self._prompt_added)
        self.canvas.geometry_changed.connect(self._geometry_changed)
        self.canvas.message.connect(lambda text:self.statusBar().showMessage(text,8000))
        self.canvas.zoom_changed.connect(lambda value:self.zoom_label.setText(f"Zoom {value*100:.0f}%"))
        self._build_actions();self._build_top();self._build_docks();self._build_status()
        self.preview_timer=QTimer(self);self.preview_timer.setSingleShot(True);self.preview_timer.setInterval(220)
        self.preview_timer.timeout.connect(self._auto_preview)
        self._refresh()
        if restore_session:
            paths=self.settings.value("last_files",[]) or []
            if isinstance(paths,str):paths=[paths]
            paths=[p for p in paths if Path(p).is_file()]
            if paths:QTimer.singleShot(100,lambda:self.open_paths(paths))

    @property
    def document(self):
        return self.documents.get(self.current_key)

    @property
    def busy(self):
        return self._job is not None

    def notify(self,title,message):
        LOG.warning("%s: %s",title,message)
        QMessageBox.warning(self,title,str(message))

    def _action(self,title,method,shortcut=None,icon=None,checkable=False):
        action=QAction(tool_icon(icon) if icon else QIcon(),title,self)
        if shortcut:action.setShortcut(QKeySequence(shortcut))
        action.setCheckable(checkable)
        action.triggered.connect(method)
        return action

    def _build_actions(self):
        self.open_action=self._action("Open images…",self.open_images,"Ctrl+O")
        self.save_action=self._action("Save masks…",self.save_mask_dialog,"Ctrl+S")
        self.undo_action=self._action("Undo",self.undo,"Ctrl+Z","undo")
        self.redo_action=self._action("Redo",self.redo,"Ctrl+Y","redo")
        self.delete_action=self._action("Delete object / selected vertex",self.delete_selected,"Delete","delete")
        self.edit_action=self._action("Edit object vertices",self.edit_object,"Ctrl+E","edit",True)
        self.remove_action=self._action("Remove selected image area",self.remove_area,"Ctrl+D")
        self.cancel_action=self._action("Cancel current drawing / preview",self.cancel_operation,"Esc")
        self.addAction(self.cancel_action)
        self.tool_actions={}
        self.tool_group=QActionGroup(self);self.tool_group.setExclusive(True)
        for kind,title in [("select","Select objects (Ctrl+click for multiple)"),("pan","Pan"),("polygon","Polygon"),("rectangle","Rectangle"),("circle","Circle"),("ellipse","Ellipse"),("point","Point / cleaning brush")]:
            action=self._action(title,lambda checked=False,k=kind:self.canvas.set_tool(k),icon=kind,checkable=True)
            self.tool_group.addAction(action);self.tool_actions[kind]=action
        self.tool_actions["select"].setChecked(True)
        self.toolbar=QToolBar("Drawing tools",self);self.toolbar.setObjectName("drawingToolbar");self.toolbar.setMovable(False);self.toolbar.setIconSize(QSize(22,22));self.addToolBar(Qt.ToolBarArea.LeftToolBarArea,self.toolbar)
        for key in ("select","pan"):self.toolbar.addAction(self.tool_actions[key])
        self.toolbar.addSeparator()
        for action in (self.undo_action,self.redo_action,self.delete_action,self.edit_action):self.toolbar.addAction(action)
        self.toolbar.addSeparator()
        for key in ("polygon","rectangle","circle","ellipse","point"):self.toolbar.addAction(self.tool_actions[key])
        file=self.menuBar().addMenu("File")
        file.addAction(self.open_action);file.addAction(self._action("Open folder…",self.open_folder));file.addAction(self._action("Open project JSON…",self.open_project));file.addSeparator()
        file.addAction(self.save_action);file.addAction(self._action("Save project now",self.save_project));file.addAction(self._action("Choose project folder…",self.choose_project_folder));file.addAction(self._action("Save cleaned image as…",self.export_cleaned));file.addSeparator()
        file.addAction(self._action("Close current image",self.close_current));file.addAction(self._action("Exit",self.close))
        edit=self.menuBar().addMenu("Edit")
        for action in (self.undo_action,self.redo_action,self.edit_action,self.delete_action):edit.addAction(action)
        edit.addSeparator();edit.addAction(self._action("Object properties…",self.object_properties));edit.addAction(self._action("Change selected objects' group…",self.change_group))
        edit.addAction(self._action("Brightness / contrast…",self.adjust_display));edit.addAction(self._action("Object color…",self.change_color));edit.addAction(self._action("Object transparency…",self.change_transparency))
        edit.addSeparator();edit.addAction(self._action("Fill holes…",lambda:self.refine_masks("holes")));edit.addAction(self._action("Smooth edges…",lambda:self.refine_masks("smooth")))
        cleaning=self.menuBar().addMenu("Cleaning");cleaning.addAction(self.remove_action)
        cleaning.addAction(self._action("Restore selected area / all edits",self.restore_area))
        for title,method in [("Fill from neighboring pixels","neighbors"),("Fill with LaMa…","lama"),("Fill with background patches","patches")]:
            cleaning.addAction(self._action(title,lambda checked=False,m=method:self.fill_removed(m)))
        cleaning.addSeparator();cleaning.addAction(self._action("Add selection as background patch",self.add_patch));cleaning.addAction(self._action("Clear background patches",self.clear_patches));cleaning.addAction(self._action("Cleaning brush radius…",self.change_brush_radius))
        models=self.menuBar().addMenu("Models");models.addAction(self._action("Model manager…",self.model_dialog));models.addAction(self._action("Segmentation options…",self.inference_options))
        exports=self.menuBar().addMenu("Export");exports.addAction(self._action("COCO segmentation dataset…",lambda:self.export_dataset("coco")));exports.addAction(self._action("YOLO segmentation dataset…",lambda:self.export_dataset("yolo")));exports.addSeparator();exports.addAction(self._action("Transparent mask images…",lambda:self.save_mask_dialog(True)))
        statistics=self.menuBar().addMenu("Statistics");statistics.addAction(self._action("Plot Object Statistics…",self.plot_statistics));statistics.addAction(self._action("Edit image calibration…",self.edit_calibration))
        view=self.menuBar().addMenu("View");view.addAction(self._action("Fit image",self.canvas.fit_image,"F"))
        for title,attribute,initial in [("Show masks","show_masks",True),("Show contours","show_contours",True),("Show prompt points","show_prompts",True)]:
            action=self._action(title,lambda checked,a=attribute:self.set_canvas_option(a,checked),checkable=True);action.setChecked(initial);view.addAction(action)
        sizes=view.addMenu("Toolbar icon size")
        for name,size in [("Small (default)",22),("Medium",30),("Large",40)]:sizes.addAction(self._action(name,lambda checked=False,n=size:self.toolbar.setIconSize(QSize(n,n))))
        self.view_menu=view
        help_menu=self.menuBar().addMenu("Help");help_menu.addAction(self._action("Quick start",self.quick_start));help_menu.addAction(self._action("Diagnostics / versions",self.diagnostics))

    def _build_top(self):
        bar=QToolBar("Workflow",self);bar.setObjectName("workflowToolbar");bar.setMovable(False);self.addToolBar(Qt.ToolBarArea.TopToolBarArea,bar)
        self.mode=combo(["Manual","Segment","Clean"],"workMode");self.mode.currentTextChanged.connect(self.mode_changed)
        self.model_button=QPushButton("Load model…");self.model_button.setObjectName("loadModelButton");self.model_button.clicked.connect(self.model_dialog)
        self.model_label=QLabel("CPU default · model not loaded")
        self.group_combo=QComboBox();self.group_combo.setObjectName("activeGroup");self.group_combo.setMinimumWidth(130);self.group_combo.currentIndexChanged.connect(self.active_group_changed)
        self.scope=combo([("Inside ROI / prompted object",False),("Whole image, unannotated only",True)],"inferenceScope")
        self.run_button=QPushButton("Run preview");self.run_button.setObjectName("runPreviewButton");self.run_button.clicked.connect(self.run_inference)
        self.accept_button=QPushButton("Accept masks");self.accept_button.setObjectName("acceptMasksButton");self.accept_button.clicked.connect(self.accept_preview)
        self.cancel_button=QPushButton("Cancel / clear");self.cancel_button.setObjectName("cancelButton");self.cancel_button.clicked.connect(self.cancel_operation)
        self.options_button=QPushButton("Options…");self.options_button.clicked.connect(self.inference_options)
        for widget in (QLabel("Mode "),self.mode,self.model_button,self.model_label,QLabel(" Group "),self.group_combo,self.scope,self.run_button,self.accept_button,self.cancel_button,self.options_button):bar.addWidget(widget)
        second=QToolBar("Image and prompts",self);second.setObjectName("imageToolbar");second.setMovable(False);self.addToolBarBreak(Qt.ToolBarArea.TopToolBarArea);self.addToolBar(Qt.ToolBarArea.TopToolBarArea,second)
        self.calibration_label=QLabel("No image")
        self.cleaned_checkbox=QCheckBox("View / infer from cleaned image");self.cleaned_checkbox.toggled.connect(lambda checked:self.set_canvas_option("use_cleaned",checked))
        self.auto_checkbox=QCheckBox("Live point preview");self.auto_checkbox.setChecked(True)
        self.text_prompt=QLineEdit();self.text_prompt.setMaximumWidth(250);self.text_prompt.setPlaceholderText("SAM3 text prompt (optional)");self.text_prompt.setVisible(False)
        for widget in (self.calibration_label,QLabel("   "),self.cleaned_checkbox,QLabel("   "),self.auto_checkbox,QLabel("   "),self.text_prompt):second.addWidget(widget)

    def _dock(self,title,name,widget):
        dock=QDockWidget(title,self);dock.setObjectName(name);dock.setWidget(widget);dock.setMinimumWidth(300)
        self.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea,dock);self.view_menu.addAction(dock.toggleViewAction());return dock

    def _build_docks(self):
        self.objects_tree=QTreeWidget();self.objects_tree.setObjectName("objectsTree");self.objects_tree.setHeaderLabels(["Object","Group","Area","Lock"]);self.objects_tree.setSelectionMode(QTreeWidget.SelectionMode.ExtendedSelection);self.objects_tree.setRootIsDecorated(False)
        self.objects_tree.itemSelectionChanged.connect(self._tree_selected);self.objects_tree.itemChanged.connect(self._object_item_changed);self.objects_tree.itemDoubleClicked.connect(lambda item,col:self.edit_object(True))
        self.objects_tree.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu);self.objects_tree.customContextMenuRequested.connect(self.object_context_menu)
        self.objects_dock=self._dock("Objects","objectsDock",self.objects_tree)
        group_widget=QWidget();layout=QVBoxLayout(group_widget);layout.setContentsMargins(5,5,5,5)
        self.groups_tree=QTreeWidget();self.groups_tree.setObjectName("groupsTree");self.groups_tree.setHeaderLabels(["Group","Count"]);self.groups_tree.setRootIsDecorated(False);self.groups_tree.itemDoubleClicked.connect(lambda item,col:self.select_group_item(item))
        layout.addWidget(self.groups_tree);row=QHBoxLayout()
        for title,callback in [("+ Group",self.new_group),("Rename",self.rename_group),("Color",self.group_color)]:
            button=QPushButton(title);button.clicked.connect(callback);row.addWidget(button)
        layout.addLayout(row);self.groups_dock=self._dock("Groups","groupsDock",group_widget)
        self.files_tree=QTreeWidget();self.files_tree.setObjectName("imageFilesTree");self.files_tree.setHeaderLabels(["Image files / datasets / frames"]);self.files_tree.setSelectionMode(QTreeWidget.SelectionMode.ExtendedSelection);self.files_tree.itemClicked.connect(self._file_clicked)
        self.files_dock=self._dock("Image files","imageFilesDock",self.files_tree)
        self.splitDockWidget(self.objects_dock,self.groups_dock,Qt.Orientation.Vertical);self.splitDockWidget(self.groups_dock,self.files_dock,Qt.Orientation.Vertical)
        self.resizeDocks([self.objects_dock,self.groups_dock,self.files_dock],[370,170,240],Qt.Orientation.Vertical)

    def _build_status(self):
        self.save_label=QLabel("Ready");self.zoom_label=QLabel("Zoom —");self.progress=QProgressBar();self.progress.setMaximumWidth(180);self.progress.setRange(0,0);self.progress.hide()
        self.statusBar().addPermanentWidget(self.save_label);self.statusBar().addPermanentWidget(self.zoom_label);self.statusBar().addPermanentWidget(self.progress)

    def _start_job(self,title,function,callback):
        if self.busy:
            self.statusBar().showMessage("Wait for the current operation or click Cancel.",5000);return False
        self._job=Job(function);self._job_callback=callback
        self._job.signals.progress.connect(self._progress_message);self._job.signals.done.connect(self._job_finished)
        self.canvas.read_only=True;self.files_tree.setEnabled(False);self.model_button.setEnabled(False);self.run_button.setEnabled(False);self.accept_button.setEnabled(False);self.progress.show()
        self.statusBar().showMessage(title);self.pool.start(self._job);return True

    def _progress_message(self,message):
        self.statusBar().showMessage(message)

    def _job_finished(self,result,error):
        job,callback=self._job,self._job_callback
        cancelled=job.cancel.is_set() if job else False
        self._job=self._job_callback=None;self.canvas.read_only=False;self.files_tree.setEnabled(True);self.model_button.setEnabled(True);self.progress.hide()
        if error is not None and not isinstance(error,InterruptedError) and not cancelled:self.notify("Operation failed",str(error))
        elif not cancelled and error is None:
            try:callback(result)
            except Exception as problem:LOG.exception("Result handling failed");self.notify("Operation failed",str(problem))
        elif cancelled:self.statusBar().showMessage("Operation cancelled. Accepted annotations were preserved.",8000)
        self._refresh()
        if self._close_requested:self.close()
        elif self._pending_preview:
            self._pending_preview=False;self.preview_timer.start()

    def _store_for(self,frame):
        preferred=Path(self.project_directory) if self.project_directory else Path(frame.source_path).parent/"SAM_Annotations"
        try:preferred.mkdir(parents=True,exist_ok=True)
        except OSError:preferred=data_directory()/"projects"
        return ProjectStore(preferred)

    def _persist(self,doc):
        try:
            path=self.stores[doc.frame.key].save(doc);self.save_label.setText("Autosaved "+datetime.now().strftime("%H:%M:%S"));self.save_label.setToolTip(str(path))
        except Exception:
            self.save_label.setText("Save failed — changes remain in memory");raise

    def _commit(self,label,function):
        if not self.document or self.busy:return False
        try:
            self.histories[self.current_key].apply(label,function)
            return True
        except Exception as error:
            LOG.exception("Edit or autosave failed");self.notify("Edit / autosave",str(error));return False
        finally:self._refresh()

    def _refresh(self):
        doc=self.document;selected=set(self.canvas.selected);self._updating=True
        self.objects_tree.clear();self.groups_tree.clear();self.group_combo.clear()
        if doc:
            for group in doc.groups:
                self.group_combo.addItem(group.name,group.id)
                item=QTreeWidgetItem([group.name,str(sum(o.group_id==group.id for o in doc.objects))]);item.setData(0,Qt.ItemDataRole.UserRole,group.id);self.groups_tree.addTopLevelItem(item)
            if doc.active_group:self.group_combo.setCurrentIndex(self.group_combo.findData(doc.active_group))
            for obj in doc.objects:
                area="Point" if obj.mask is None else f"{obj.pixel_area:,} px²"
                if obj.mask is not None and doc.calibration.valid:area=f"{doc.calibration.area(obj.pixel_area):.4g} {doc.calibration.length_unit}²"
                item=QTreeWidgetItem([obj.name,doc.get_group(obj.group_id).name,area,""])
                item.setData(0,Qt.ItemDataRole.UserRole,obj.id);item.setFlags(item.flags()|Qt.ItemFlag.ItemIsUserCheckable)
                item.setCheckState(0,Qt.CheckState.Checked if obj.visible else Qt.CheckState.Unchecked);item.setCheckState(3,Qt.CheckState.Checked if obj.locked else Qt.CheckState.Unchecked)
                item.setForeground(0,QColor(obj.color));item.setToolTip(2,f"Pixel area: {obj.pixel_area}\nPhysical area: {doc.calibration.area(obj.pixel_area) if obj.mask is not None else 'N/A'}")
                self.objects_tree.addTopLevelItem(item);item.setSelected(obj.id in selected)
            cal=doc.calibration
            self.calibration_label.setText(f"Pixel size: X {cal.pixel_size_x:g} × Y {cal.pixel_size_y:g} {cal.length_unit}/pixel" if cal.valid else "Pixel size unavailable — measurements use pixels")
            self.calibration_label.setToolTip(cal.source)
            self.setWindowTitle(f"{Path(doc.frame.source_path).name} — {doc.frame.frame_label} — SAM Image Studio {__version__}")
            self.canvas.selected &= {o.id for o in doc.objects};self.canvas.refresh()
        else:
            self.calibration_label.setText("No image");self.setWindowTitle(f"SAM Image Studio {__version__}")
        self._updating=False
        has=bool(doc)
        self.run_button.setEnabled(has and self.engine.ready and not self.busy)
        self.accept_button.setEnabled(has and bool(self.canvas.preview_masks) and not self.busy)
        self.save_action.setEnabled(has and not self.busy);self.remove_action.setEnabled(has and not self.busy)
        history=self.histories.get(self.current_key)
        self.undo_action.setEnabled(bool(history and history.undo_stack) and not self.busy);self.redo_action.setEnabled(bool(history and history.redo_stack) and not self.busy)
        self.delete_action.setEnabled(has and bool(self.canvas.selected) and not self.busy)
        self.edit_action.setEnabled(has and len(self.canvas.selected)==1 and not self.busy)
        self.text_prompt.setVisible(bool(self.engine.spec and self.engine.spec.family=="SAM3"))
        for dialog in list(self.stats_dialogs):
            dialog.documents=list(self.documents.values())
            dialog.selected_objects=set(self.canvas.selected)
            dialog.selected_images=self.selected_images()
            dialog.current=doc
            dialog.refresh()

    def open_images(self):
        if self.busy:return
        paths,_=QFileDialog.getOpenFileNames(self,"Open images / stacks","","Images (*.png *.jpg *.jpeg *.bmp *.tif *.tiff *.dm3 *.dm4 *.emd *.webp *.gif);;All files (*)")
        if paths:self.open_paths(paths)

    def open_folder(self):
        if self.busy:return
        folder=QFileDialog.getExistingDirectory(self,"Open image folder")
        if folder:self.open_paths([str(p) for p in sorted(Path(folder).iterdir()) if p.suffix.lower() in SUPPORTED_EXTENSIONS])

    def open_paths(self,paths):
        if not paths:return
        self._start_job("Opening images…",lambda progress,cancel:load_files(paths,progress,cancel),self._opened)

    def _opened(self,result):
        first=None
        for frame in result.frames:
            if first is None:first=frame.key
            if frame.key in self.documents:continue
            doc=Document(frame);store=self._store_for(frame)
            try:
                restored,message=store.load(doc)
                if message:self.statusBar().showMessage(message,8000)
            except Exception as error:result.warnings.append(f"{frame.frame_label}: {error}")
            self.documents[frame.key]=doc;self.stores[frame.key]=store;self.histories[frame.key]=History(doc,lambda d=doc:self._persist(d))
            for g in doc.groups:self._palette[g.name]=g.color
        self._rebuild_file_tree()
        if first:self.select_document(first)
        self.settings.setValue("last_files",list(dict.fromkeys(d.frame.source_path for d in self.documents.values())))
        if result.warnings:self.notify("Some files / saved annotations need attention","\n\n".join(result.warnings[:12]))

    def _rebuild_file_tree(self):
        self.files_tree.clear();parents={}
        for key,doc in self.documents.items():
            path=doc.frame.source_path
            if path not in parents:
                parent=QTreeWidgetItem([Path(path).name]);parent.setToolTip(0,path);self.files_tree.addTopLevelItem(parent);parents[path]=parent
            child=QTreeWidgetItem([doc.frame.frame_label]);child.setData(0,Qt.ItemDataRole.UserRole,key);parents[path].addChild(child);parents[path].setExpanded(True)

    def select_document(self,key):
        if self.busy or key not in self.documents:return
        if self.document and self.document.revision!=self.document.saved_revision:
            try:self._persist(self.document)
            except Exception as error:self.notify("Image switch blocked",f"Save the current work first. {error}");return
        self.current_key=key;self._refine_target=None
        self.canvas.set_document(self.document);self.edit_action.setChecked(False);self._refresh()

    def _file_clicked(self,item,column):
        key=item.data(0,Qt.ItemDataRole.UserRole)
        if key:self.select_document(key)

    def selected_images(self):
        keys=set()
        for item in self.files_tree.selectedItems():
            key=item.data(0,Qt.ItemDataRole.UserRole)
            if key:keys.add(key)
            else:
                for i in range(item.childCount()):keys.add(item.child(i).data(0,Qt.ItemDataRole.UserRole))
        return keys

    def choose_project_folder(self):
        if self.busy:return
        folder=QFileDialog.getExistingDirectory(self,"Choose a writable autosave folder")
        if folder:
            self.project_directory=folder;self.settings.setValue("project_directory",folder)
            for key,doc in self.documents.items():
                self.stores[key]=ProjectStore(Path(folder))
                try:self._persist(doc)
                except Exception as error:self.notify("Autosave folder",str(error))

    def open_project(self):
        if self.busy:return
        path,_=QFileDialog.getOpenFileName(self,"Open saved project JSON","","SAM project (*.sam.json *.json)")
        if not path:return
        try:
            state=json.loads(Path(path).read_text("utf-8"));source=state["image"]["path"]
            if not Path(source).exists():
                source,_=QFileDialog.getOpenFileName(self,"Locate the matching source image")
                if not source:return
            def loaded(result):
                matches=[f for f in result.frames if f.fingerprint==state["image"]["fingerprint"] and f.dataset==state["image"]["dataset"] and f.frame_index==state["image"]["frame_index"]]
                if not matches:raise ValueError("The selected source/dataset/frame does not match this project.")
                frame=matches[0];state["image"]["key"]=frame.key
                self._opened(result);doc=self.documents[frame.key];doc.restore(state);doc.saved_revision=-1;self.stores[frame.key]=ProjectStore(Path(path).parent);self._persist(doc);self.select_document(frame.key)
            self._start_job("Opening project…",lambda progress,cancel:load_files([source],progress,cancel),loaded)
        except Exception as error:self.notify("Open project",str(error))

    def save_project(self):
        if not self.document:return
        try:self._persist(self.document)
        except Exception as error:self.notify("Save failed",str(error))

    def close_current(self):
        if self.busy or not self.document:return
        try:self._persist(self.document)
        except Exception as error:self.notify("Save failed",str(error));return
        key=self.current_key;self.documents.pop(key);self.histories.pop(key);self.stores.pop(key);self.current_key=None
        self.canvas.set_document(None);self._rebuild_file_tree()
        if self.documents:self.select_document(next(iter(self.documents)))
        self.settings.setValue("last_files",list(dict.fromkeys(d.frame.source_path for d in self.documents.values())));self._refresh()

    def _ensure_group(self):
        doc=self.document
        if not doc:return False
        if doc.active_group and any(g.id==doc.active_group for g in doc.groups):return True
        if self._palette:
            name,color=next(iter(self._palette.items()))
            return self._commit("Select default group",lambda:doc.ensure_group(name,color))
        return self.new_group()

    def new_group(self):
        if self.busy or not self.document:return False
        name,ok=QInputDialog.getText(self,"Create group","Group name (used as the default for new objects):")
        if not ok or not name.strip():return False
        name=name.strip();color=self._palette.get(name,"#148374")
        success=self._commit("Create group",lambda:self.document.ensure_group(name,color))
        if success:self._palette[name]=color
        return success

    def active_group_changed(self,index):
        if self._updating or not self.document or self.busy:return
        value=self.group_combo.itemData(index)
        if value and value!=self.document.active_group:self._commit("Select active group",lambda:setattr(self.document,"active_group",value))

    def select_group_item(self,item):
        ident=item.data(0,Qt.ItemDataRole.UserRole)
        index=self.group_combo.findData(ident)
        if index>=0:self.group_combo.setCurrentIndex(index)

    def rename_group(self):
        if not self.document or self.busy:return
        item=self.groups_tree.currentItem()
        if not item:return
        group=self.document.get_group(item.data(0,Qt.ItemDataRole.UserRole))
        name,ok=QInputDialog.getText(self,"Rename group","New group name:",text=group.name)
        if ok and name.strip():
            if any(g.name==name.strip() and g.id!=group.id for g in self.document.groups):self.notify("Group exists","Choose another name or reassign the objects to the existing group.");return
            self._commit("Rename group",lambda:setattr(group,"name",name.strip()));self._palette[group.name]=group.color

    def group_color(self):
        if not self.document or self.busy:return
        item=self.groups_tree.currentItem()
        if not item:return
        group=self.document.get_group(item.data(0,Qt.ItemDataRole.UserRole));color=QColorDialog.getColor(QColor(group.color),self,"Group color")
        if color.isValid():
            old=group.color
            def update():
                group.color=color.name()
                for obj in self.document.objects:
                    if obj.group_id==group.id and obj.color==old:obj.color=group.color
            self._commit("Group color",update);self._palette[group.name]=group.color

    def mode_changed(self,value):
        self.canvas.mode=value;self.canvas.edit_mode=False;self.edit_action.setChecked(False)
        if value=="Segment":self.tool_actions["point"].setChecked(True);self.canvas.set_tool("point")
        elif value=="Clean":self.tool_actions["rectangle"].setChecked(True);self.canvas.set_tool("rectangle")
        else:self.canvas.set_tool("select");self.tool_actions["select"].setChecked(True)

    def _shape_completed(self,kind,points):
        if not self.document or self.busy:return
        doc=self.document
        if self.mode.currentText()=="Manual":
            if not self._ensure_group():return
            def draw():doc.add_object(kind,points,None if kind=="point" else shape_mask(kind,points,doc.frame.shape),{"method":"manual"})
            self._commit("Draw annotation",draw)
        else:
            self._refine_target=None
            self._commit("Draw region",lambda:doc.draft.update({"roi":{"kind":kind,"points":points}}))
            if self.mode.currentText()=="Segment" and self.auto_checkbox.isChecked() and self.engine.ready:self.preview_timer.start()

    def _selection_mask(self):
        doc=self.document
        if not doc:return None
        roi=doc.draft.get("roi")
        if roi:
            if roi["kind"]=="brush":
                mask=np.zeros(doc.frame.shape,np.uint8)
                points=np.rint(roi["points"]).astype(np.int32)
                cv2.polylines(mask,[points],False,1,max(1,round(self.canvas.brush_radius*2)))
                for p in (points[0],points[-1]):cv2.circle(mask,tuple(p),round(self.canvas.brush_radius),1,-1)
                return mask.astype(bool)
            return shape_mask(roi["kind"],roi["points"],doc.frame.shape)
        objects=[o.mask for o in doc.objects if o.id in self.canvas.selected and o.mask is not None]
        return np.logical_or.reduce(objects) if objects else None

    def _prompt_added(self,x,y,label):
        if not self.document or self.busy:return
        self._refine_target=None
        self._commit("Add SAM prompt",lambda:self.document.draft["points"].append([x,y,label]))
        if self.auto_checkbox.isChecked() and self.engine.ready:self.preview_timer.start()

    def _auto_preview(self):
        if not self.document or self.mode.currentText()!="Segment":return
        if self.busy:self._pending_preview=True
        else:self.run_inference()

    def _canvas_selected(self,ids):
        self._updating=True
        for i in range(self.objects_tree.topLevelItemCount()):
            item=self.objects_tree.topLevelItem(i);item.setSelected(item.data(0,Qt.ItemDataRole.UserRole) in ids)
        self._updating=False;self._refresh()

    def _tree_selected(self):
        if self._updating:return
        self.canvas.set_selected([item.data(0,Qt.ItemDataRole.UserRole) for item in self.objects_tree.selectedItems()]);self._refresh()

    def _object_item_changed(self,item,column):
        if self._updating or self.busy or not self.document:return
        ident=item.data(0,Qt.ItemDataRole.UserRole);obj=next((o for o in self.document.objects if o.id==ident),None)
        if not obj:return
        if column==0:self._commit("Object visibility",lambda:setattr(obj,"visible",item.checkState(0)==Qt.CheckState.Checked))
        elif column==3:self._commit("Object lock",lambda:setattr(obj,"locked",item.checkState(3)==Qt.CheckState.Checked))

    def selected_objects(self):
        return [o for o in self.document.objects if o.id in self.canvas.selected] if self.document else []

    def delete_selected(self):
        if self.busy or not self.document:return
        if self.canvas.delete_vertex():return
        if self.canvas.edit_mode:
            self.statusBar().showMessage("Click a polygon/contour vertex before pressing Delete. Exit vertex edit mode to delete whole objects.",8000)
            return
        selected=self.selected_objects()
        if any(o.locked for o in selected):self.notify("Locked object","Unlock the selected objects before deleting them.");return
        if selected:self._commit("Delete objects",lambda:setattr(self.document,"objects",[o for o in self.document.objects if o.id not in self.canvas.selected]))

    def edit_object(self,checked=True):
        selected=self.selected_objects()
        if len(selected)!=1 or selected[0].locked:
            self.edit_action.setChecked(False);self.notify("Edit object","Select one unlocked object.");return
        self.canvas.edit_mode=checked;self.edit_action.setChecked(checked);self.canvas.set_tool("select");self.tool_actions["select"].setChecked(True);self.canvas.update()
        if checked:self.statusBar().showMessage("Drag vertices to edit. Click a polygon vertex and press Delete to remove it. Undo restores the previous exact mask.",10000)

    def _geometry_changed(self,ident,geometry):
        if not self.document or self.busy:return
        obj=next((o for o in self.document.objects if o.id==ident),None)
        if not obj or obj.locked:return
        def change():
            if geometry["kind"]=="contours":obj.mask=raster_contours(geometry["contours"],self.document.frame.shape);obj.kind="mask";obj.points=[]
            else:
                mask=None if geometry["kind"]=="point" else shape_mask(geometry["kind"],geometry["points"],self.document.frame.shape)
                if mask is not None and not mask.any():raise ValueError("The edit would remove the object.")
                obj.kind=geometry["kind"];obj.points=geometry["points"];obj.mask=mask
            obj.provenance["last_edit"]="vertex edit"
        self._commit("Edit vertices",change)

    def undo(self):
        if self.busy or not self.document:return
        self.canvas.set_preview([]);self._refine_target=None
        try:self.histories[self.current_key].undo()
        except Exception as error:self.notify("Undo / autosave",str(error))
        self._refresh()

    def redo(self):
        if self.busy or not self.document:return
        self.canvas.set_preview([]);self._refine_target=None
        try:self.histories[self.current_key].redo()
        except Exception as error:self.notify("Redo / autosave",str(error))
        self._refresh()

    def change_group(self):
        selected=self.selected_objects()
        if not selected or self.busy:return
        if any(o.locked for o in selected):self.notify("Locked object","Unlock the selected objects first.");return
        name,ok=QInputDialog.getItem(self,"Change group","Group name",[g.name for g in self.document.groups],editable=True)
        if ok and name.strip():
            def change():
                group=self.document.ensure_group(name.strip(),self._palette.get(name.strip(),"#148374"))
                for obj in selected:obj.group_id=group.id
            self._commit("Change group",change)

    def change_color(self):
        selected=self.selected_objects()
        if not selected or self.busy:return
        color=QColorDialog.getColor(QColor(selected[0].color),self,"Object color")
        if color.isValid():self._commit("Object color",lambda:[setattr(o,"color",color.name()) for o in selected])

    def change_transparency(self):
        selected=self.selected_objects()
        if not selected or self.busy:return
        value,ok=QInputDialog.getInt(self,"Object transparency","0% = opaque; 100% = invisible",round((1-selected[0].opacity)*100),0,100)
        if ok:self._commit("Object transparency",lambda:[setattr(o,"opacity",1-value/100) for o in selected])

    def object_properties(self):
        selected=self.selected_objects()
        if len(selected)!=1 or self.busy:return
        obj=selected[0];dialog=QDialog(self);dialog.setWindowTitle("Object properties");layout=QVBoxLayout(dialog);form=QFormLayout();name=QLineEdit(obj.name);locked=QCheckBox("Protect from manual edits");locked.setChecked(obj.locked);form.addRow("Name",name);form.addRow("Lock",locked);layout.addLayout(form)
        area="Point annotation" if obj.mask is None else f"Area: {obj.pixel_area:,} pixel²"
        if obj.mask is not None and self.document.calibration.valid:area+=f"\nPhysical area: {self.document.calibration.area(obj.pixel_area):.8g} {self.document.calibration.length_unit}²"
        layout.addWidget(QLabel(area));controls=QDialogButtonBox(QDialogButtonBox.StandardButton.Ok|QDialogButtonBox.StandardButton.Cancel);controls.accepted.connect(dialog.accept);controls.rejected.connect(dialog.reject);layout.addWidget(controls)
        if dialog.exec()==QDialog.DialogCode.Accepted:
            def update():obj.name=name.text().strip() or obj.name;obj.locked=locked.isChecked()
            self._commit("Object properties",update)

    def object_context_menu(self,position):
        if self.busy:return
        menu=QMenu(self);menu.addAction(self.edit_action);menu.addAction("Properties…",self.object_properties);menu.addAction("Change group…",self.change_group);menu.addSeparator()
        menu.addAction("Infer inside selected object / ROI",self.infer_selected_roi);menu.addAction("Infer whole image, preserve all objects",lambda:self.run_inference(force_whole=True));menu.addAction("Refine selected object explicitly",self.refine_selected_inference);menu.addSeparator()
        menu.addAction("Fill holes…",lambda:self.refine_masks("holes"));menu.addAction("Smooth edges…",lambda:self.refine_masks("smooth"));menu.addSeparator();menu.addAction(self.delete_action);menu.exec(self.objects_tree.viewport().mapToGlobal(position))

    def model_dialog(self):
        if self.busy:return
        dialog=ModelDialog(self.engine,self)
        if dialog.exec()==QDialog.DialogCode.Accepted:
            spec,device,path=dialog.values()
            def loaded(result):self.model_label.setText(result["model"]+" · "+result["device"].upper());self.model_label.setToolTip(result["checkpoint"]);self.statusBar().showMessage("Model loaded. Choose Segment and draw a region or add points.",10000)
            self._start_job("Loading model…",lambda progress,cancel:self.engine.load(spec,device,path,progress,cancel),loaded)

    def inference_options(self):
        dialog=InferenceOptionsDialog(self.options,self)
        if dialog.exec()==QDialog.DialogCode.Accepted:self.options=dialog.values()

    def run_inference(self,checked=False,force_whole=None):
        if self.busy or not self.document:return
        if not self.engine.ready:self.notify("Model required","Load a SAM model using Model manager first.");return
        doc=self.document;key=self.current_key;whole=self.scope.currentData() if force_whole is None else force_whole
        try:
            if whole:self._refine_target=None
            roi=self._selection_mask() if not whole and doc.draft.get("roi") else None
            points=copy.deepcopy(doc.draft.get("points",[])) if not whole else []
            if points and not any(p[2] for p in points) and roi is None:raise ValueError("Add at least one positive (left-click) point.")
            protected=doc.protected_mask([self._refine_target] if self._refine_target and not whole else [])
            raw=doc.working if self.cleaned_checkbox.isChecked() and doc.working is not None else doc.frame.raw
            rgb=display_rgb(raw);text=self.text_prompt.text().strip() if self.engine.spec.family=="SAM3" else ""
            context={"target":self._refine_target,"method":"SAM","model":self.engine.spec.label,
                     "device":self.engine.device,"input":"cleaned" if raw is doc.working else "original",
                     "normalization":"uint8 RGB; non-uint8 0.5–99.5 percentile stretch"}
            self.canvas.set_preview([]);self._preview_context=None;self._refine_target=None
            def finished(masks):
                if self.current_key!=key:return
                self._preview_context=context
                self.canvas.set_preview(masks);self.statusBar().showMessage(f"{len(masks)} preview mask(s). Review and click Accept masks." if masks else "No eligible new masks. Accepted objects stay protected. Use explicit Refine to change an existing object.",12000)
            self._start_job("Running segmentation…",lambda progress,cancel:self.engine.infer(rgb,points,roi,protected,whole=whole,progress=progress,cancel=cancel,text_prompt=text,**self.options),finished)
        except Exception as error:self.notify("Segmentation",str(error))

    def infer_selected_roi(self):
        if not self.document:return
        objects=self.selected_objects()
        if len(objects)!=1 or objects[0].mask is None:self.notify("ROI required","Select one area object, or draw an ROI.");return
        x,y,w,h=bounding_box(objects[0].mask)
        self.document.draft["roi"]={"kind":"rectangle","points":[[x,y],[x+w,y+h]]};self.document.draft["points"]=[];self._refine_target=None;self.run_inference(force_whole=False)

    def refine_selected_inference(self):
        selected=self.selected_objects()
        if len(selected)!=1 or selected[0].mask is None or selected[0].locked:self.notify("Refine selected object","Select one unlocked area object.");return
        from scipy.ndimage import distance_transform_edt
        obj=selected[0];yy,xx=np.unravel_index(np.argmax(distance_transform_edt(obj.mask)),obj.mask.shape)
        x,y,w,h=bounding_box(obj.mask);self._refine_target=obj.id
        self.document.draft.update({"roi":{"kind":"rectangle","points":[[x,y],[x+w,y+h]]},"points":[[float(xx),float(yy),1]]})
        self.mode.setCurrentText("Segment");self.run_inference(force_whole=False)

    def accept_preview(self):
        if not self.document or self.busy or not self.canvas.preview_masks:return
        if not self._ensure_group():return
        doc=self.document;context=copy.deepcopy(self._preview_context or {});target=context.pop("target",None)
        masks=filter_proposals(self.canvas.preview_masks,doc.protected_mask([target] if target else []),min_area=1)
        if not masks:
            self.canvas.set_preview([]);self._refine_target=None;self._refresh();self.notify("Preview is no longer eligible","Accepted objects now occupy this preview. Run segmentation again.");return
        def accept():
            provenance=context or {"method":"SAM","model":self.engine.spec.label,"device":self.engine.device,
                                  "input":"original","normalization":"uint8 RGB"}
            if target:
                obj=next(o for o in doc.objects if o.id==target)
                if obj.locked:raise ValueError("Unlock the object before refining it.")
                obj.mask=masks[0];obj.kind="mask";obj.points=[];obj.provenance=provenance
            else:
                for mask in masks:doc.add_object("mask",mask=mask,provenance=provenance)
            doc.draft["roi"]=None;doc.draft["points"]=[]
        if self._commit("Accept SAM masks",accept):self.canvas.set_preview([]);self._refine_target=None;self._refresh()

    def cancel_operation(self):
        self.preview_timer.stop();self._pending_preview=False
        if self.busy:self._job.cancel.set();self.statusBar().showMessage("Stopping after the current model operation…");return
        self.canvas.set_tool(self.canvas.tool)
        self.canvas.set_preview([]);self._refine_target=None
        if self.document:self._commit("Clear prompts / region",lambda:self.document.draft.update({"points":[],"roi":None}))

    def refine_masks(self,method):
        if self.busy or not self.document:return
        ids=list(self.canvas.selected)
        if not ids:self.notify("Select objects","Select one or more objects in the Objects panel.");return
        dialog=RefinementDialog(self.document,ids,method,self)
        if dialog.exec()==QDialog.DialogCode.Accepted and dialog.results:
            def update():
                for obj in self.document.objects:
                    if obj.id in dialog.results:obj.mask=dialog.results[obj.id].copy();obj.kind="mask";obj.points=[];obj.provenance["last_refinement"]="fill holes" if method=="holes" else "smooth edges"
            self._commit("Fill holes" if method=="holes" else "Smooth edges",update)

    def edit_calibration(self):
        if not self.document or self.busy:return
        dialog=CalibrationDialog(self.document.calibration,self)
        if dialog.exec()==QDialog.DialogCode.Accepted:self._commit("Edit calibration",lambda:setattr(self.document,"calibration",dialog.value()))

    def plot_statistics(self):
        if not self.document:return
        dialog=StatisticsDialog(self.documents.values(),self.document,self.canvas.selected,self.selected_images(),self)
        self.stats_dialogs.append(dialog);dialog.finished.connect(lambda result,d=dialog:self.stats_dialogs.remove(d) if d in self.stats_dialogs else None);dialog.show()

    def set_canvas_option(self,attribute,value):
        setattr(self.canvas,attribute,value);self.canvas.refresh()

    def adjust_display(self):
        if not self.document:return
        before=(self.canvas.brightness,self.canvas.contrast);dialog=BrightnessDialog(*before,self)
        def changed(brightness,contrast):self.canvas.brightness=brightness;self.canvas.contrast=contrast;self.canvas.refresh()
        dialog.changed.connect(changed)
        if dialog.exec()!=QDialog.DialogCode.Accepted:changed(*before)

    def remove_area(self):
        if self.busy or not self.document:return
        try:
            mask=self._selection_mask()
            if mask is None or not mask.any():raise ValueError("Draw a cleaning region or select an area object first.")
            if np.iscomplexobj(self.document.frame.raw):raise ValueError("Cleaning complex-valued images is unavailable. Export an intensity image first.")
            def remove():
                doc=self.document
                if doc.working is None:doc.working=doc.frame.raw.copy()
                doc.working[mask]=0;doc.removed|=mask;doc.modified|=mask;doc.draft["roi"]=None
                doc.cleaning_history.append({"operation":"remove","pixels":int(mask.sum()),"time":datetime.now(timezone.utc).isoformat()})
            self._commit("Remove image area",remove);self.cleaned_checkbox.setChecked(True)
        except Exception as error:self.notify("Cleaning",str(error))

    def restore_area(self):
        if self.busy or not self.document:return
        try:
            mask=self._selection_mask()
            if mask is None:mask=self.document.modified.copy()
            if not mask.any():raise ValueError("There are no modified pixels to restore.")
            def restore():
                doc=self.document
                if doc.working is not None:doc.working[mask]=doc.frame.raw[mask]
                doc.removed[mask]=False;doc.modified[mask]=False;doc.draft["roi"]=None;doc.cleaning_history.append({"operation":"restore","pixels":int(mask.sum())})
                if not doc.modified.any():doc.working=None
            self._commit("Restore image area",restore)
        except Exception as error:self.notify("Restore",str(error))

    def add_patch(self):
        if not self.document or self.busy:return
        roi=self.document.draft.get("roi")
        if not roi or roi["kind"]!="rectangle":self.notify("Background patch","Draw a rectangle around an unaffected background patch first.");return
        pts=np.asarray(roi["points"]);lo=pts.min(axis=0);hi=pts.max(axis=0);box=[float(lo[0]),float(lo[1]),float(hi[0]),float(hi[1])]
        self._commit("Add background patch",lambda:self.document.draft["patches"].append(box));self.statusBar().showMessage(f"{len(self.document.draft['patches'])} background patch(es) selected.",5000)

    def clear_patches(self):
        if self.document:self._commit("Clear background patches",lambda:self.document.draft.update({"patches":[]}))

    def change_brush_radius(self):
        value,ok=QInputDialog.getInt(self,"Cleaning brush","Radius in pixels",self.canvas.brush_radius,1,500)
        if ok:self.canvas.brush_radius=value

    def fill_removed(self,method):
        if not self.document or self.busy:return
        doc=self.document;target=doc.removed.copy()
        if not target.any():self.notify("Fill region","Remove an image area first. Fill Holes in Edit instead operates on object masks.");return
        raw=(doc.working if doc.working is not None else doc.frame.raw).copy();patches=copy.deepcopy(doc.draft.get("patches",[]));key=self.current_key
        def calculate(progress,cancel):
            if method=="neighbors":return neighbor_fill(raw,target)
            if method=="patches":return patch_fill(raw,target,patches)
            rgb=display_rgb(raw);result=lama_fill(rgb,target,progress=progress,cancel=cancel)
            output=raw.copy();values=result if raw.ndim==3 else cv2.cvtColor(result,cv2.COLOR_RGB2GRAY)
            if raw.dtype!=np.uint8:
                finite=np.asarray(raw)[np.isfinite(raw)];sample=finite[::max(1,finite.size//500_000)];lo,hi=np.percentile(sample,[.5,99.5]);values=values.astype(float)/255*(hi-lo)+lo
            if raw.ndim==3 and raw.shape[-1]==4:output[target,:3]=cast_like(values[target],raw.dtype)
            else:output[target]=cast_like(values[target],raw.dtype)
            return output
        def finished(result):
            if self.current_key!=key:return
            # Show a disposable preview, then require an explicit Apply before changing saved image pixels.
            dialog=QDialog(self);dialog.setWindowTitle("Cleaning fill preview");layout=QVBoxLayout(dialog)
            from .canvas import rgb_image
            preview=QLabel();preview.setPixmap(QPixmap.fromImage(rgb_image(display_rgb(result))).scaled(780,550,Qt.AspectRatioMode.KeepAspectRatio,Qt.TransformationMode.SmoothTransformation));layout.addWidget(preview)
            layout.addWidget(QLabel("Preview of generated/estimated replacement pixels. The original image stays unchanged."));controls=QDialogButtonBox(QDialogButtonBox.StandardButton.Apply|QDialogButtonBox.StandardButton.Cancel);controls.button(QDialogButtonBox.StandardButton.Apply).clicked.connect(dialog.accept);controls.rejected.connect(dialog.reject);layout.addWidget(controls)
            if dialog.exec()==QDialog.DialogCode.Accepted:
                def apply():doc.working=result;doc.removed[target]=False;doc.modified|=target;doc.cleaning_history.append({"operation":"fill","method":method,"pixels":int(target.sum()),"time":datetime.now(timezone.utc).isoformat()})
                self._commit("Fill image region",apply);self.cleaned_checkbox.setChecked(True)
        self._start_job("Filling removed pixels…",calculate,finished)

    def save_mask_dialog(self,transparent=False):
        if not self.document or self.busy:return
        dialog=SaveMasksDialog(self.document,bool(transparent),self)
        if dialog.exec()!=QDialog.DialogCode.Accepted:return
        folder=QFileDialog.getExistingDirectory(self,"Save mask images")
        if not folder:return
        try:
            paths=save_masks(self.document,Path(folder),**dialog.values());self.statusBar().showMessage(f"Saved {len(paths)} mask image(s).",10000)
        except Exception as error:self.notify("Save masks",str(error))

    def export_dataset(self,format):
        if not self.documents or self.busy:return
        choice,ok=QInputDialog.getItem(self,"Dataset export","Image scope",["Current image","Selected images","All open images"],editable=False)
        if not ok:return
        docs=[self.document] if choice=="Current image" else [d for k,d in self.documents.items() if k in self.selected_images()] if choice=="Selected images" else list(self.documents.values())
        docs=[d for d in docs if d is not None]
        if not docs:self.notify("Dataset export","Select image entries in the Image files panel.");return
        lossy=False
        if format=="yolo":
            answer=QMessageBox.question(self,"YOLO polygons","Allow lossy conversion of holes / disconnected masks?\nChoose No to require exact compatibility. COCO preserves exact mask pixels.",QMessageBox.StandardButton.Yes|QMessageBox.StandardButton.No|QMessageBox.StandardButton.Cancel,QMessageBox.StandardButton.No)
            if answer==QMessageBox.StandardButton.Cancel:return
            lossy=answer==QMessageBox.StandardButton.Yes
        folder=QFileDialog.getExistingDirectory(self,"Choose dataset output folder")
        if not folder:return
        try:
            result=export_coco(docs,Path(folder)) if format=="coco" else export_yolo(docs,Path(folder),lossy)
            self.statusBar().showMessage(f"{format.upper()} export complete. Point annotations excluded: {result.get('skipped_points',0)}.",12000)
        except Exception as error:self.notify("Dataset export",str(error))

    def export_cleaned(self):
        if not self.document or self.busy:return
        path,_=QFileDialog.getSaveFileName(self,"Save derived cleaned image",Path(self.document.frame.source_path).stem+"_cleaned.tif","TIFF (*.tif *.tiff)")
        if path:
            try:save_cleaned(self.document,path);self.statusBar().showMessage("Saved derived TIFF and cleaning history.",10000)
            except Exception as error:self.notify("Save cleaned image",str(error))

    def quick_start(self):
        QMessageBox.information(self,"Quick start","1. Open images or a microscopy stack.\n2. Load SAM1 ViT-B on CPU using Model manager.\n3. Choose Manual to draw annotations, or Segment to use points / ROIs.\n4. Left-click adds positive points; right-click adds negative points. Review previews, then Accept masks.\n5. Whole image preserves every accepted object. Refine selected is explicit.\n6. Work autosaves after each edit. Save masks and Export create separate output files.\n7. Edit offers Fill Holes and Smooth Edges; Statistics plots object sizes.\n\nWheel = zoom, middle-drag = pan, F = fit, Ctrl+E = vertices, Ctrl+Z/Y = undo/redo.")

    def diagnostics(self):
        import importlib.metadata as metadata
        names=["PySide6","numpy","scipy","torch","torchvision","segment-anything","SAM-2","rosettasciio","tifffile"]
        values=[]
        for name in names:
            try:values.append(name+": "+metadata.version(name))
            except metadata.PackageNotFoundError:values.append(name+": not installed")
        QMessageBox.information(self,"Diagnostics",f"SAM Image Studio {__version__}\n"+"\n".join(values)+f"\n\nData / log folder: {data_directory()}\nNative SAM3 needs the optional CUDA environment.")

    def closeEvent(self,event):
        self.preview_timer.stop()
        if self.busy:
            answer=QMessageBox.question(self,"Operation running","Cancel the current operation and close when it stops?",QMessageBox.StandardButton.Yes|QMessageBox.StandardButton.No)
            if answer==QMessageBox.StandardButton.Yes:self._close_requested=True;self._job.cancel.set()
            event.ignore();return
        for doc in self.documents.values():
            if doc.revision!=doc.saved_revision:
                try:self._persist(doc)
                except Exception as error:self.notify("Close blocked",f"Some changes could not be saved. Choose a writable project folder.\n{error}");event.ignore();return
        self.settings.setValue("last_files",list(dict.fromkeys(d.frame.source_path for d in self.documents.values())));self.settings.sync();event.accept()

